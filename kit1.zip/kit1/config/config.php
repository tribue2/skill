<?php

class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        $configFile = __DIR__ . '/database.php';
        if (!is_file($configFile)) {
            throw new Exception('Lipseste fisierul config/database.php');
        }

        $db = require $configFile;
        if (!is_array($db)) {
            throw new Exception('config/database.php nu returneaza un array valid');
        }

        $host = (string) ($db['host'] ?? 'localhost');
        $dbname = (string) ($db['dbname'] ?? '');
        $username = (string) ($db['username'] ?? '');
        $password = (string) ($db['password'] ?? '');

        if ($dbname === '' || $username === '') {
            throw new Exception('Completeaza dbname si username in config/database.php');
        }

        $lastError = null;
        $hosts = array_values(array_unique([$host, 'localhost', '127.0.0.1']));

        foreach ($hosts as $tryHost) {
            try {
                $this->pdo = new PDO(
                    "mysql:host={$tryHost};dbname={$dbname};charset=utf8mb4",
                    $username,
                    $password,
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => true,
                        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci',
                    ]
                );

                $this->pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
                $this->pdo->exec("SET character_set_client = utf8mb4");
                $this->pdo->exec("SET character_set_connection = utf8mb4");
                $this->pdo->exec("SET character_set_results = utf8mb4");
                $this->pdo->exec("SET collation_connection = utf8mb4_unicode_ci");
                return;
            } catch (PDOException $e) {
                $lastError = $e;
            }
        }

        error_log('Database connection error: ' . ($lastError ? $lastError->getMessage() : 'unknown'));
        throw new Exception('Conexiunea la baza de date a esuat');
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->pdo;
    }

    public function query($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log('Database query error: ' . $e->getMessage());
            throw new Exception('Eroare la executarea query-ului: ' . $e->getMessage(), 0, $e);
        }
    }

    public function fetchAll($sql, $params = []) {
        return $this->query($sql, $params)->fetchAll();
    }

    public function fetchOne($sql, $params = []) {
        return $this->query($sql, $params)->fetch();
    }

    public function insert($table, $data) {
        $columns = implode(',', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";

        $this->query($sql, $data);
        return $this->pdo->lastInsertId();
    }

    public function update($table, $data, $where, $whereParams = []) {
        $set = [];
        foreach ($data as $key => $value) {
            $set[] = "$key = :$key";
        }
        $setClause = implode(', ', $set);

        $sql = "UPDATE $table SET $setClause WHERE $where";
        $params = array_merge($data, $whereParams);

        return $this->query($sql, $params)->rowCount();
    }

    public function delete($table, $where, $params = []) {
        $sql = "DELETE FROM $table WHERE $where";
        return $this->query($sql, $params)->rowCount();
    }
}

function getDB() {
    return Database::getInstance();
}
