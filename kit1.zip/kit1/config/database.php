<?php

return [
    'host' => 'localhost',
    'dbname' => 'iaxweeuj_terminal',
    'username' => 'iaxweeuj_terminal',
    'password' => 'QbUv.XC$b_;=r[Iw',
];
