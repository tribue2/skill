<?php
if (session_status() === PHP_SESSION_NONE) {
  $sessionLifetime = 30 * 24 * 3600;
  session_set_cookie_params([
    'lifetime' => $sessionLifetime,
    'path' => '/',
    'domain' => '',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax'
  ]);
  ini_set('session.gc_maxlifetime', (string) $sessionLifetime);
}
