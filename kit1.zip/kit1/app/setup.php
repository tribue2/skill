<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Configurare Terminal</title>
    <link rel="stylesheet" href="css/terminal.css?v=34">
</head>
<body>
<div class="setup-page">
    <form class="setup-card" id="setupForm">
        <h1>Configurare terminal PC</h1>
        <p>Daca ai instalat ITL Bridge pe acest PC, foloseste legatura automata. Altfel introdu codul de pairing din admin.</p>
        <div class="setup-alert error" id="setupError" style="display:none;"></div>
        <p style="margin:0 0 14px;">
            <a class="setup-btn" href="bridge-link.php" style="display:inline-block;text-decoration:none;text-align:center;">Preia de pe ITL Bridge</a>
        </p>
        <label for="serverUrl">URL server</label>
        <input type="url" id="serverUrl" value="" placeholder="https://iqwin.ro">
        <label for="pairCode">Cod pairing</label>
        <input type="text" id="pairCode" maxlength="12" placeholder="ABCD1234" required>
        <button type="submit" class="setup-btn">Conecteaza terminalul</button>
    </form>
</div>

<script>
(function () {
    const form = document.getElementById('setupForm');
    const errorBox = document.getElementById('setupError');
    const serverInput = document.getElementById('serverUrl');
    const pairInput = document.getElementById('pairCode');

    serverInput.value = window.location.origin + window.location.pathname.replace(/\/app\/setup\.php.*$/, '');

    form.addEventListener('submit', async function (event) {
        event.preventDefault();
        errorBox.style.display = 'none';

        const base = serverInput.value.replace(/\/$/, '');
        const pairCode = pairInput.value.trim().toUpperCase();

        try {
            const response = await fetch(base + '/api/terminal/pair.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ pair_code: pairCode })
            });

            const raw = await response.text();
            let data = null;
            try {
                data = raw ? JSON.parse(raw) : null;
            } catch (parseError) {
                throw new Error('Serverul nu a raspuns corect. Verifica api/terminal/pair.php pe server.');
            }

            if (!data || !response.ok || !data.ok) {
                throw new Error((data && data.message) ? data.message : 'Pairing esuat');
            }

            localStorage.setItem('skill_terminal_credentials', JSON.stringify(data.terminal));
            localStorage.setItem('skill_terminal_server', base);
            window.location.href = 'index.php';
        } catch (error) {
            errorBox.textContent = error.message;
            errorBox.style.display = 'block';
        }
    });
})();
</script>
</body>
</html>
