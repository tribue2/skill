(function () {
    const storageKey = 'skill_terminal_credentials';
    const serverKey = 'skill_terminal_server';
    const slotIcons = ['fa-fire', 'fa-puzzle-piece', 'fa-sack-dollar', 'fa-plane', 'fa-star', 'fa-bolt', 'fa-lemon', 'fa-shapes', 'fa-gem'];
    const coverTiles = {
        'verga-gold': '../images/vergagold.webp',
        'boss-crown': '../images/bosscrown.webp',
        'dodge-bomb': '../images/dodgebomb.webp',
        'logic-and-zeus': '../images/firescatter.webp',
        '40-burn-hot': '../images/wildclover.webp',
        'intelligent-book': '../images/intelligentbook.webp'
    };

    function getCoverImage(game) {
        const slug = String(game.slug || '').toLowerCase();
        const iconKey = String(game.icon_key || '').toLowerCase();
        if (coverTiles[slug]) return coverTiles[slug];
        if (coverTiles[iconKey]) return coverTiles[iconKey];
        if (/verga\s*gold|golden\s*brain|brain\s*way/i.test(String(game.title || ''))) return coverTiles['verga-gold'];
        if (/boss\s*crown|millionaire\s*crown/i.test(String(game.title || ''))) return coverTiles['boss-crown'];
        if (/dodge\s*bomb/i.test(String(game.title || ''))) return coverTiles['dodge-bomb'];
        if (/logic\s*and\s*zeus|fire\s*scatter/i.test(String(game.title || ''))) return coverTiles['logic-and-zeus'];
        if (/40\s*burn\s*hot|wild\s*clover/i.test(String(game.title || ''))) return coverTiles['40-burn-hot'];
        if (/intelligent\s*book|cartea\s*inteligent|book\s*of\s*knowledge/i.test(String(game.title || ''))) return coverTiles['intelligent-book'];
        return null;
    }

    function applyPhotoTile(tile, game, coverSrc, title) {
        const slug = String(game.slug || game.icon_key || '').toLowerCase();
        tile.className += ' is-photo-tile';
        if (slug === 'verga-gold') {
            tile.className += ' is-cover-verga-gold';
        }
        tile.setAttribute('aria-label', title || 'Joc');
        const label = title ? escapeHtml(title) : 'Joc';
        tile.innerHTML =
            '<span class="game-cell-photo-wrap">' +
                '<img class="game-cell-photo" src="' + escapeHtml(coverSrc) + '" alt="" draggable="false">' +
                '<span class="game-cell-photo-title" aria-hidden="true">' +
                    '<span class="game-cell-photo-title-pill">' +
                        '<span class="game-cell-photo-title-glow"></span>' +
                        '<span class="game-cell-photo-title-text">' + label + '</span>' +
                    '</span>' +
                '</span>' +
            '</span>';
    }

    function buildFrozenOverlayHtml() {
        return (
            '<span class="game-cell-freeze" aria-hidden="true">' +
                '<span class="game-cell-freeze-veil"></span>' +
                '<span class="game-cell-freeze-chains">' +
                    '<i class="fas fa-link game-cell-freeze-chain game-cell-freeze-chain--tl"></i>' +
                    '<i class="fas fa-link game-cell-freeze-chain game-cell-freeze-chain--tr"></i>' +
                    '<i class="fas fa-link game-cell-freeze-chain game-cell-freeze-chain--bl"></i>' +
                    '<i class="fas fa-link game-cell-freeze-chain game-cell-freeze-chain--br"></i>' +
                    '<span class="game-cell-freeze-x"></span>' +
                '</span>' +
                '<span class="game-cell-freeze-lock-wrap">' +
                    '<i class="fas fa-lock game-cell-freeze-lock" aria-hidden="true"></i>' +
                '</span>' +
                '<span class="game-cell-freeze-label">Inghetat</span>' +
            '</span>'
        );
    }

    function appendFrozenOverlay(tile) {
        tile.insertAdjacentHTML('beforeend', buildFrozenOverlayHtml());
    }

    function apiBase() {
        const stored = localStorage.getItem(serverKey);
        if (stored) {
            return stored.replace(/\/$/, '') + '/api/terminal';
        }
        return window.TERMINAL_API_BASE || '../api/terminal';
    }

    const state = {
        credentials: null,
        terminal: null,
        games: [],
        refreshSeconds: 15,
        heartbeatTimer: null,
        creditsPollTimer: null,
        creditsPollBusy: false,
        creditsPollGen: 0,
        lastCreditBumpAt: 0,
        lastLocalCreditBumpAt: 0,
        localBridgePort: 0,
        skipLocalBalance: false,
        localBalanceFails: 0,
        heartbeatGen: 0,
        bootstrapTimer: null,
        contestPollTimer: null,
        clockTimer: null,
        currentSessionId: null,
        currentGameId: null,
        credits: 0,
        creditBusy: false,
        marqueeSignature: '',
        gamesSignature: '',
        gameLaunching: false,
        launchSelectedSlot: null,
        operator: null,
        operatorPeriod: '1d',
        operatorBusy: false,
        operatorField: 'username',
        operatorShift: false,
        reportLoading: false,
        stackerBusy: false,
        contestEnabled: false,
        contest: null,
        lastContestRevision: '',
        lastMpPollBumpRevision: ''
    };

    const creditQuickAmounts = [5, 10, 20, 50, 100, 500];
    const creditOutAmounts = [10, 50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
    const MAX_TERMINAL_LEI = 1000;
    const MAX_WITHDRAWAL_LEI = 1000;
    let selectedOutRon = null;
    let selectedForcedRon = null;
    const GAME_LAUNCH_DURATION_MS = 2500;
    let launchSound = null;

    function getLaunchSound() {
        if (!launchSound) {
            launchSound = new Audio('../sounds/expand.mp3');
            launchSound.preload = 'auto';
            launchSound.playbackRate = 2;
        }
        return launchSound;
    }

    function playLaunchSound() {
        if (isSoundMuted()) return;
        try {
            const audio = getLaunchSound();
            audio.playbackRate = 2;
            audio.currentTime = 0;
            const playPromise = audio.play();
            if (playPromise && typeof playPromise.catch === 'function') {
                playPromise.catch(function () {});
            }
        } catch (error) {
        }
    }

    function clearLaunchSelectedCard() {
        document.querySelectorAll('.game-cell.is-launch-selected').forEach(function (el) {
            el.classList.remove('is-launch-selected');
            const lightning = el.querySelector('.game-cell-lightning');
            if (lightning) lightning.remove();
        });
    }

    function ensureLaunchLightning(tile) {
        if (!tile || tile.querySelector('.game-cell-lightning')) return;
        const host = tile.querySelector('.game-cell-cover') || tile;
        const lightning = document.createElement('span');
        lightning.className = 'game-cell-lightning';
        lightning.setAttribute('aria-hidden', 'true');
        lightning.innerHTML =
            '<span class="game-cell-lightning-flash"></span>' +
            '<span class="game-cell-lightning-bolt game-cell-lightning-bolt--a"></span>' +
            '<span class="game-cell-lightning-bolt game-cell-lightning-bolt--b"></span>' +
            '<span class="game-cell-lightning-bolt game-cell-lightning-bolt--c"></span>';
        host.appendChild(lightning);
    }

    function markLaunchSelectedCard(game) {
        const grid = document.getElementById('gamesGrid');
        if (!grid || !game) return;
        clearLaunchSelectedCard();
        const tile = grid.querySelector('.game-cell.slot-' + game.slot + '.playable');
        if (tile) {
            tile.classList.add('is-launch-selected');
            ensureLaunchLightning(tile);
        }
    }

    function showGameLaunchLoader(game) {
        const grid = document.getElementById('gamesGrid');
        const loader = document.getElementById('gameGridLoader');
        state.launchSelectedSlot = game && game.slot ? game.slot : null;
        markLaunchSelectedCard(game);
        if (grid) grid.classList.add('is-game-loading');
        if (loader) loader.hidden = false;
    }

    function hideGameLaunchLoader() {
        const grid = document.getElementById('gamesGrid');
        const loader = document.getElementById('gameGridLoader');
        state.launchSelectedSlot = null;
        clearLaunchSelectedCard();
        if (grid) grid.classList.remove('is-game-loading');
        if (loader) loader.hidden = true;
    }

    function waitForLaunchDuration() {
        return new Promise(function (resolve) {
            window.setTimeout(resolve, GAME_LAUNCH_DURATION_MS);
        });
    }

    function loadCredentials() {
        try {
            const raw = localStorage.getItem(storageKey);
            return raw ? JSON.parse(raw) : null;
        } catch (error) {
            return null;
        }
    }

    function apiHeaders() {
        return {
            'Content-Type': 'application/json',
            'X-Terminal-Code': state.credentials.terminal_code,
            'X-Terminal-Secret': state.credentials.api_secret
        };
    }

    const MP_POLL_BUMP_KEY = 'iqwin-mp-poll-bump';

    function bumpMpPollForOtherTabs(revision) {
        const rev = String(revision || '');
        if (!rev || rev === state.lastMpPollBumpRevision) {
            return;
        }
        state.lastMpPollBumpRevision = rev;
        try {
            localStorage.setItem(MP_POLL_BUMP_KEY, rev + ':' + String(Date.now()));
        } catch (e) {}
    }

    function withAuthParams(url) {
        const u = new URL(url, window.location.href);
        u.searchParams.set('terminal_code', state.credentials.terminal_code);
        u.searchParams.set('api_secret', state.credentials.api_secret);
        return u.toString();
    }

    function withAuthBody(body) {
        let payload = {};
        if (body == null || body === '') {
            payload = {};
        } else if (typeof body === 'string') {
            try {
                payload = JSON.parse(body);
            } catch (error) {
                payload = {};
            }
        } else if (typeof body === 'object') {
            payload = Object.assign({}, body);
        }
        payload.terminal_code = state.credentials.terminal_code;
        payload.api_secret = state.credentials.api_secret;
        return JSON.stringify(payload);
    }

    async function apiRequest(path, options) {
        const config = Object.assign({
            credentials: 'include',
            cache: 'no-store'
        }, options || {});
        config.headers = Object.assign({}, apiHeaders(), config.headers || {});

        const method = String(config.method || 'GET').toUpperCase();
        let url = apiBase() + '/' + path;
        if (method === 'GET' || method === 'HEAD') {
            url = withAuthParams(url);
            if (String(path).indexOf('contest.php') >= 0) {
                const bustUrl = new URL(url, window.location.href);
                bustUrl.searchParams.set('_ts', String(Date.now()));
                url = bustUrl.toString();
            }
        } else {
            config.body = withAuthBody(config.body);
        }

        const response = await fetch(url, config);
        const raw = await response.text();
        let data = null;

        if (raw) {
            try {
                data = JSON.parse(raw);
            } catch (error) {
                throw new Error('Raspuns invalid de la server. Verifica upload-ul fisierelor API.');
            }
        }

        if (!data) {
            throw new Error('Serverul nu a returnat date. Verifica ca ai uploadat api/includes/terminal_api.php.');
        }

        if (!response.ok || !data.ok) {
            throw new Error(data.message || 'Eroare API');
        }
        return data;
    }

    function getGamesSignature(games) {
        return JSON.stringify((games || []).map(function (game) {
            return {
                slot: Number(game.slot) || 0,
                playable: !!game.playable,
                frozen: !!game.frozen,
                slug: String(game.slug || ''),
                title: String(game.title || ''),
                subtitle: String(game.subtitle || ''),
                status: String(game.status || ''),
                icon_key: String(game.icon_key || ''),
                id: game.id || null
            };
        }).sort(function (a, b) {
            return a.slot - b.slot;
        }));
    }

    function renderGames() {
        const grid = document.getElementById('gamesGrid');
        if (!grid) return;

        const loader = document.getElementById('gameGridLoader');
        const isLoading = grid.classList.contains('is-game-loading');

        grid.querySelectorAll('.game-cell').forEach(function (node) {
            node.remove();
        });

        const slots = Array.from({ length: 6 }, function (_, index) {
            const slotNumber = index + 1;
            const game = state.games.find(function (g) { return g.slot === slotNumber; });
            if (game) return game;
            return {
                slot: slotNumber,
                title: 'Joc ' + slotNumber,
                subtitle: 'In curand',
                status: 'coming_soon',
                playable: false
            };
        });

        grid.classList.toggle('is-photo-grid', slots.some(function (game) {
            return !!getCoverImage(game);
        }));

        slots.forEach(function (game) {
            const tile = document.createElement('button');
            tile.type = 'button';
            const frozen = !!game.frozen;
            const playable = !!game.playable && !frozen;
            const locked = !playable;
            tile.className = 'game-cell slot-' + game.slot + (playable ? ' playable' : ' locked');
            if (frozen) {
                tile.className += ' is-frozen';
            }
            tile.disabled = locked;

            const iconClass = slotIcons[(game.slot - 1) % slotIcons.length];
            const title = game.title || '';
            const subtitle = locked && game.status === 'empty' ? '' : (game.subtitle || (locked && !frozen ? 'In curand' : (frozen ? 'Indisponibil temporar' : '')));
            const coverSrc = getCoverImage(game);

            if (coverSrc) {
                applyPhotoTile(tile, game, coverSrc, title);
                if (frozen) {
                    appendFrozenOverlay(tile);
                }
            } else {
                tile.innerHTML =
                    '<div class="game-cell-icon"><i class="fas ' + iconClass + '"></i></div>' +
                    (title ? '<div class="game-cell-title">' + escapeHtml(title) + '</div>' : '') +
                    (subtitle ? '<div class="game-cell-sub">' + escapeHtml(subtitle) + '</div>' : '');
                if (frozen) {
                    appendFrozenOverlay(tile);
                }
            }

            if (playable) {
                tile.addEventListener('click', function () {
                    openGame(game);
                });
            }

            grid.appendChild(tile);
        });

        if (loader) {
            grid.appendChild(loader);
            if (isLoading) loader.hidden = false;
        }

        if (isLoading && state.launchSelectedSlot) {
            markLaunchSelectedCard({ slot: state.launchSelectedSlot });
        }

    }

    function formatMoney(value) {
        return Number(value || 0).toFixed(2).replace('.', ',') + ' RON';
    }

    function withdrawableCredits(balance) {
        const whole = Math.floor(Number(balance) || 0);
        if (!Number.isFinite(whole) || whole <= 0) {
            return 0;
        }
        return whole;
    }

    function calculateWithdrawalPayout(grossMoneyRon) {
        const gross = Math.round(Number(grossMoneyRon || 0) * 100) / 100;
        return {
            grossMoney: gross,
            taxableMoney: 0,
            taxMoney: 0,
            netMoney: gross
        };
    }

    function formatCreditsNumber(value) {
        return formatLeiAmount(value);
    }

    function creditRate() {
        const rate = Number(state.terminal && state.terminal.credit_rate);
        if (!Number.isFinite(rate) || rate <= 0) {
            return 0.1;
        }
        if (Math.abs(rate - 1) < 0.0001) {
            return 0.1;
        }
        return rate;
    }

    function creditsPerLeu() {
        const rate = creditRate();
        return rate > 0 ? Math.round(1 / rate) : 10;
    }

    function creditsForMoney(amountMoney) {
        return Math.floor(Number(amountMoney) / creditRate());
    }

    function moneyForCredits(credits) {
        return Math.round(Number(credits) * creditRate() * 100) / 100;
    }

    function formatLeiFromCredits(credits) {
        const amount = moneyForCredits(credits);
        return amount.toLocaleString('ro-RO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' LEI';
    }

    function formatLeiAmount(credits) {
        return moneyForCredits(credits).toLocaleString('ro-RO', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function maxCreditsForTerminal() {
        const rate = creditRate();
        if (!Number.isFinite(rate) || rate <= 0) {
            return MAX_TERMINAL_LEI * 10;
        }
        return Math.floor(MAX_TERMINAL_LEI / rate);
    }

    function isBalanceOverCap() {
        return Number(state.credits) > maxCreditsForTerminal() + 0.001;
    }

    function minForcedWithdrawCredits() {
        if (!isBalanceOverCap()) {
            return 0;
        }
        return Math.ceil(Number(state.credits) - maxCreditsForTerminal());
    }

    function getWithdrawOptionsRon(maxLei) {
        const maxCredits = withdrawableCredits(state.credits);
        const capLei = Number(maxLei) > 0 ? Number(maxLei) : MAX_WITHDRAWAL_LEI;
        return creditOutAmounts.filter(function (amount) {
            if (amount > capLei) {
                return false;
            }
            const credits = creditsForMoney(amount);
            return credits > 0 && credits <= maxCredits;
        });
    }

    function getForcedWithdrawOptionsRon() {
        if (!isBalanceOverCap()) {
            return [];
        }
        return getWithdrawOptionsRon(MAX_WITHDRAWAL_LEI);
    }

    function pickDefaultForcedWithdrawOption(options) {
        if (!options || !options.length) {
            return null;
        }
        return options[options.length - 1];
    }

    function applyBalanceCapFromServer(payload) {
        if (!payload || typeof payload !== 'object') {
            return;
        }
        if (typeof payload.credits_balance === 'number') {
            state.credits = Number(payload.credits_balance);
        } else if (payload.terminal && typeof payload.terminal.credits_balance === 'number') {
            state.credits = Number(payload.terminal.credits_balance);
        }
        if (state.terminal && typeof state.credits === 'number') {
            state.terminal.credits_balance = state.credits;
        }
    }

    function syncForcedWithdrawToGame() {
        const frame = document.getElementById('gameFrame');
        if (!frame || !frame.contentWindow || !isGameOpen()) {
            return;
        }
        try {
            frame.contentWindow.postMessage({
                type: 'skill-game-forced-withdraw',
                active: isBalanceOverCap(),
                minWithdrawCredits: minForcedWithdrawCredits(),
                maxTerminalLei: MAX_TERMINAL_LEI
            }, '*');
        } catch (error) {
        }
    }

    function renderForcedWithdrawGrid() {
        const grid = document.getElementById('forcedWithdrawAmountGrid');
        const sub = document.getElementById('forcedWithdrawSub');
        if (!grid) {
            return;
        }

        const options = getForcedWithdrawOptionsRon();
        const excessLei = formatLeiAmount(minForcedWithdrawCredits());
        grid.innerHTML = '';

        if (sub) {
            sub.textContent = 'Soldul depaseste plafonul de '
                + MAX_TERMINAL_LEI.toLocaleString('ro-RO')
                + ' LEI. Retrage sume fixe (max '
                + MAX_WITHDRAWAL_LEI.toLocaleString('ro-RO')
                + ' LEI o data) pana soldul scade sub plafon. Mai ai de retras: '
                + excessLei
                + ' LEI.';
        }

        if (!options.length) {
            const empty = document.createElement('p');
            empty.className = 'credit-modal-sub forced-withdraw-min';
            empty.textContent = 'Nu exista optiuni valide. Contacteaza operatorul.';
            grid.appendChild(empty);
            return;
        }

        if (selectedForcedRon != null && options.indexOf(selectedForcedRon) < 0) {
            selectedForcedRon = null;
        }

        options.forEach(function (amount) {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'credit-out-amount-btn'
                + (selectedForcedRon === amount ? ' is-active' : '');
            button.disabled = state.creditBusy;
            button.innerHTML = '<strong>' + amount + '</strong><span>RON</span>';
            button.addEventListener('click', function () {
                selectedForcedRon = amount;
                renderForcedWithdrawGrid();
                renderForcedWithdrawPreview();
            });
            grid.appendChild(button);
        });
    }

    function resolveForcedWithdrawSelection() {
        if (selectedForcedRon == null) {
            return { credits: 0, valid: false, noSelection: true };
        }
        const credits = creditsForMoney(selectedForcedRon);
        const maxCredits = withdrawableCredits(state.credits);
        if (credits <= 0 || credits > maxCredits || selectedForcedRon > MAX_WITHDRAWAL_LEI) {
            return { credits: 0, valid: false };
        }
        if (creditOutAmounts.indexOf(selectedForcedRon) < 0) {
            return { credits: 0, valid: false };
        }
        return { credits: credits, valid: true };
    }

    function renderForcedWithdrawPreview() {
        const resolved = resolveForcedWithdrawSelection();
        const summary = document.getElementById('forcedWithdrawSummary');
        const confirmBtn = document.getElementById('forcedWithdrawConfirmBtn');

        if (!resolved.valid) {
            if (summary) {
                summary.innerHTML =
                    '<span class="credit-out-summary-total">Sold curent: '
                    + escapeHtml(formatLeiAmount(state.credits))
                    + ' LEI</span>';
            }
            if (confirmBtn) {
                confirmBtn.disabled = true;
            }
            return null;
        }

        const creditsToOut = resolved.credits;
        const grossMoney = moneyForCredits(creditsToOut);
        const payout = calculateWithdrawalPayout(grossMoney);
        const remaining = Math.round((Number(state.credits) - creditsToOut) * 100) / 100;

        if (summary) {
            let html =
                '<span class="credit-out-summary-total">Sold curent: '
                + escapeHtml(formatLeiAmount(state.credits))
                + ' LEI</span>'
                + '<strong>Retragi acum: '
                + escapeHtml(formatLeiAmount(creditsToOut))
                + ' LEI</strong>'
                + '<span>= ' + escapeHtml(formatMoney(payout.grossMoney)) + '</span>';
            html += '<span>Sold ramas: ' + escapeHtml(formatLeiAmount(remaining)) + ' LEI</span>';
            if (remaining > maxCreditsForTerminal() + 0.001) {
                html += '<span class="forced-withdraw-note">Soldul ramane peste plafon. Repeta retragerea.</span>';
            }
            summary.innerHTML = html;
        }

        if (confirmBtn) {
            confirmBtn.disabled = state.creditBusy;
        }

        return creditsToOut;
    }

    function openForcedWithdrawModal() {
        if (!isBalanceOverCap()) {
            closeModal('forcedWithdrawModal');
            return;
        }
        const options = getForcedWithdrawOptionsRon();
        selectedForcedRon = pickDefaultForcedWithdrawOption(options);
        renderForcedWithdrawGrid();
        renderForcedWithdrawPreview();
        openModal('forcedWithdrawModal');
    }

    function checkForcedWithdrawal() {
        syncForcedWithdrawToGame();
        if (isBalanceOverCap()) {
            openForcedWithdrawModal();
            updateCreditButtonStates();
            return;
        }
        closeModal('forcedWithdrawModal');
        selectedForcedRon = null;
        updateCreditButtonStates();
    }

    async function submitForcedMoneyOut() {
        const resolved = resolveForcedWithdrawSelection();
        if (state.creditBusy || !resolved.valid || resolved.credits <= 0) {
            if (resolved.noSelection) {
                window.alert('Alege suma de retras.');
            }
            return;
        }

        setCreditBusy(true);
        try {
            const data = await apiRequest('credits.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({
                    action: 'money_out',
                    credits: resolved.credits,
                    forced: true
                })
            });
            applyBalanceCapFromServer(data);
            updateStatus();
            const stillOverCap = isBalanceOverCap();
            checkForcedWithdrawal();
            if (!stillOverCap) {
                closeModal('forcedWithdrawModal');
                selectedForcedRon = null;
            } else {
                const nextOptions = getForcedWithdrawOptionsRon();
                selectedForcedRon = pickDefaultForcedWithdrawOption(nextOptions);
                renderForcedWithdrawGrid();
                renderForcedWithdrawPreview();
            }
            showWithdrawResultModal({
                success: true,
                amountMoney: data.amount_money,
                balanceCredits: data.credits_balance,
                note: stillOverCap
                    ? 'Soldul ramane peste plafon. Continua retragerea pana scade sub 1.000 LEI.'
                    : ''
            });
        } catch (error) {
            showWithdrawResultModal({
                success: false,
                message: error.message || 'Nu s-a putut retrage suma.'
            });
        } finally {
            setCreditBusy(false);
            updateCreditButtonStates();
        }
    }

    function isGameOpen() {
        const overlay = document.getElementById('gameOverlay');
        return !!(overlay && overlay.classList.contains('active'));
    }

    function setCreditBusy(busy) {
        state.creditBusy = busy;
        updateCreditButtonStates();
    }

    function updateCreditButtonStates() {
        const inBtn = document.getElementById('creditInBtn');
        const outBtn = document.getElementById('creditOutBtn');
        const gameOpen = isGameOpen();
        const forced = isBalanceOverCap();
        const lobbyWaiting = isMpLobbyWaiting();

        if (inBtn) {
            inBtn.disabled = state.creditBusy || gameOpen || forced || lobbyWaiting;
            inBtn.title = lobbyWaiting
                ? 'Asteapta startul concursului Blitz'
                : (forced
                ? 'Retrage suma obligatorie inainte de a introduce bani'
                : (gameOpen ? 'Inchide jocul pentru a introduce bani' : ''));
        }
        if (outBtn) {
            outBtn.disabled = state.creditBusy || withdrawableCredits(state.credits) <= 0 || forced || lobbyWaiting;
            outBtn.title = lobbyWaiting
                ? 'Asteapta startul concursului Blitz'
                : (forced ? 'Foloseste retragerea obligatorie' : '');
        }
    }

    function updateOutButtonState() {
        updateCreditButtonStates();
    }

    function syncCreditsToOpenGame(extra) {
        const frame = document.getElementById('gameFrame');
        if (!frame || !frame.contentWindow || !isGameOpen()) return;
        try {
            const payload = {
                type: 'skill-game-credits',
                credits: state.credits,
                forcedWithdraw: isBalanceOverCap(),
                minWithdrawCredits: minForcedWithdrawCredits(),
                maxTerminalLei: MAX_TERMINAL_LEI
            };
            if (extra && typeof extra.lastWin === 'number' && extra.lastWin > 0) {
                payload.lastWin = extra.lastWin;
            }
            frame.contentWindow.postMessage(payload, '*');
            syncForcedWithdrawToGame();
        } catch (error) {
        }
    }

    function openModal(id) {
        const modal = document.getElementById(id);
        if (modal) {
            modal.hidden = false;
            modal.classList.add('active');
        }
    }

    function closeModal(id) {
        const modal = document.getElementById(id);
        if (modal) {
            modal.classList.remove('active');
            modal.hidden = true;
        }
    }

    function showTerminalNoticeModal(message, title) {
        showWithdrawResultModal({
            success: false,
            title: title || 'Atentie',
            message: message || 'Operatiunea nu a putut fi finalizata.'
        });
    }

    function showWithdrawResultModal(options) {
        const modal = document.getElementById('creditOutResultModal');
        const iconEl = document.getElementById('creditOutResultIcon');
        const titleEl = document.getElementById('creditOutResultTitle');
        const subEl = document.getElementById('creditOutResultSub');
        const amountEl = document.getElementById('creditOutResultAmount');
        const balanceEl = document.getElementById('creditOutResultBalance');
        const noteEl = document.getElementById('creditOutResultNote');
        if (!modal) {
            return;
        }

        const success = !!options.success;
        modal.classList.toggle('is-error', !success);

        if (iconEl) {
            iconEl.innerHTML = success
                ? '<i class="fa-solid fa-circle-check"></i>'
                : '<i class="fa-solid fa-circle-xmark"></i>';
        }
        if (titleEl) {
            titleEl.textContent = options.title
                || (success ? 'Retragere efectuata' : 'Retragere esuata');
        }
        if (subEl) {
            subEl.textContent = options.message
                || (success ? 'Suma a fost eliberata cu succes.' : 'Nu s-a putut finaliza retragerea.');
        }

        if (amountEl) {
            if (success && options.amountMoney != null) {
                amountEl.textContent = formatMoney(options.amountMoney);
                amountEl.hidden = false;
            } else {
                amountEl.textContent = '';
                amountEl.hidden = true;
            }
        }

        if (balanceEl) {
            if (success && options.balanceCredits != null && Number(options.balanceCredits) >= 0) {
                balanceEl.textContent = 'Sold ramas: ' + formatLeiAmount(options.balanceCredits) + ' LEI';
                balanceEl.hidden = false;
            } else {
                balanceEl.textContent = '';
                balanceEl.hidden = true;
            }
        }

        if (noteEl) {
            if (options.note) {
                noteEl.textContent = options.note;
                noteEl.hidden = false;
            } else {
                noteEl.textContent = '';
                noteEl.hidden = true;
            }
        }

        openModal('creditOutResultModal');
    }

    function closeWithdrawResultModal() {
        closeModal('creditOutResultModal');
    }

    function renderCreditQuickGrid() {
        const grid = document.getElementById('creditQuickGrid');
        if (!grid) return;

        grid.innerHTML = '';
        creditQuickAmounts.forEach(function (amount) {
            const credits = creditsForMoney(amount);
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'credit-quick-btn';
            button.innerHTML =
                '<strong>' + amount + ' RON</strong>' +
                '<span>+' + formatLeiAmount(creditsForMoney(amount)) + ' LEI</span>';
            button.addEventListener('click', function () {
                submitMoneyIn(amount);
            });
            grid.appendChild(button);
        });
    }

    function updateCreditInHint() {
        const hint = document.getElementById('creditInHint');
        if (!hint) return;
        hint.textContent = 'IN manual (butoane) sau automat prin ITL Bridge pe PC. 1 RON = 1 LEI pe sold.';
    }

    async function submitMoneyIn(amountMoney) {
        if (state.creditBusy) return;
        if (isBalanceOverCap()) {
            openForcedWithdrawModal();
            return;
        }
        if (isGameOpen()) {
            window.alert('Nu poti introduce bani in timpul jocului.');
            return;
        }
        const amount = Number(amountMoney);
        if (!Number.isFinite(amount) || amount < 1) {
            window.alert('Introdu o suma valida.');
            return;
        }

        setCreditBusy(true);
        try {
            const data = await apiRequest('credits.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({
                    action: 'money_in',
                    amount_money: amount,
                    game_overlay_open: isGameOpen()
                })
            });
            state.credits = data.credits_balance;
            if (state.terminal) state.terminal.credits_balance = data.credits_balance;
            updateStatus();
            updateOutButtonState();
            closeModal('creditInModal');
            const customInput = document.getElementById('creditCustomAmount');
            if (customInput) customInput.value = '';
        } catch (error) {
            window.alert(error.message || 'Nu s-a putut adauga suma pe sold.');
        } finally {
            setCreditBusy(false);
            updateOutButtonState();
        }
    }

    function resolveOutSelection(selection) {
        const maxCredits = withdrawableCredits(state.credits);
        if (selection == null || selection === '') {
            return { credits: 0, valid: false, noSelection: true };
        }
        const ron = Number(selection);
        if (!Number.isFinite(ron) || ron <= 0) {
            return { credits: 0, valid: false };
        }
        const credits = creditsForMoney(ron);
        if (credits <= 0) {
            return { credits: 0, valid: false };
        }
        if (credits > maxCredits) {
            return { credits: maxCredits, valid: false, tooHigh: true };
        }
        if (creditOutAmounts.indexOf(ron) < 0 || ron > MAX_WITHDRAWAL_LEI) {
            return { credits: 0, valid: false };
        }
        return { credits: credits, valid: true, useMax: false };
    }

    function renderCreditOutAmountGrid() {
        const grid = document.getElementById('creditOutAmountGrid');
        if (!grid) return;

        const maxCredits = withdrawableCredits(state.credits);
        grid.innerHTML = '';

        creditOutAmounts.forEach(function (amount) {
            const credits = creditsForMoney(amount);
            const affordable = credits > 0 && credits <= maxCredits;
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'credit-out-amount-btn'
                + (selectedOutRon === amount ? ' is-active' : '');
            button.disabled = !affordable || state.creditBusy;
            button.innerHTML = '<strong>' + amount + '</strong><span>RON</span>';
            button.addEventListener('click', function () {
                selectedOutRon = amount;
                renderCreditOutAmountGrid();
                renderCreditOutPreview();
            });
            grid.appendChild(button);
        });
    }

    function renderCreditOutPreview() {
        const resolved = resolveOutSelection(selectedOutRon);
        const maxCredits = withdrawableCredits(state.credits);
        const sub = document.getElementById('creditOutSub');
        const summary = document.getElementById('creditOutSummary');
        const confirmBtn = document.getElementById('creditOutConfirmBtn');

        if (!resolved.valid) {
            if (sub) {
                if (resolved.noSelection) {
                    sub.textContent = 'Alege suma de retras.';
                } else if (resolved.tooHigh) {
                    sub.textContent = 'Suma depaseste soldul disponibil (' + formatMoney(moneyForCredits(maxCredits)) + ').';
                } else {
                    sub.textContent = 'Selecteaza o suma valida.';
                }
            }
            if (summary) {
                summary.innerHTML =
                    '<span class="credit-out-summary-total">Sold total: ' + escapeHtml(formatLeiAmount(state.credits)) + ' LEI</span>';
            }
            if (confirmBtn) confirmBtn.disabled = state.creditBusy || true;
            return null;
        }

        const creditsToOut = resolved.credits;
        const grossMoney = moneyForCredits(creditsToOut);
        const payout = calculateWithdrawalPayout(grossMoney);

        if (sub) {
            sub.textContent = 'Confirmi retragerea a ' + selectedOutRon + ' RON?';
        }

        if (summary) {
            const remaining = Math.round((Number(state.credits) - creditsToOut) * 100) / 100;
            let html =
                '<span class="credit-out-summary-total">Sold total: ' + escapeHtml(formatLeiAmount(state.credits)) + ' LEI</span>' +
                '<strong>Retragi acum: ' + escapeHtml(formatLeiAmount(creditsToOut)) + ' LEI</strong>' +
                '<span>= ' + escapeHtml(formatMoney(payout.grossMoney)) + '</span>';
            if (remaining > 0) {
                html += '<span>Sold ramas: ' + escapeHtml(formatLeiAmount(remaining)) + ' LEI</span>';
            }
            summary.innerHTML = html;
        }
        if (confirmBtn) confirmBtn.disabled = state.creditBusy;
        return creditsToOut;
    }

    async function submitMoneyOut() {
        const resolved = resolveOutSelection(selectedOutRon);
        if (state.creditBusy || !resolved.valid || resolved.credits <= 0) {
            if (!resolved.valid) {
                if (resolved.noSelection) {
                    window.alert('Alege suma de retras.');
                } else if (resolved.tooHigh) {
                    window.alert('Suma depaseste soldul disponibil.');
                }
            }
            return;
        }
        const creditsToOut = resolved.credits;

        setCreditBusy(true);
        try {
            const data = await apiRequest('credits.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({
                    action: 'money_out',
                    credits: creditsToOut
                })
            });
            state.credits = data.credits_balance;
            if (state.terminal) state.terminal.credits_balance = data.credits_balance;
            updateStatus();
            updateOutButtonState();
            closeModal('creditOutModal');
            selectedOutRon = null;
            showWithdrawResultModal({
                success: true,
                amountMoney: data.amount_money,
                balanceCredits: data.credits_balance
            });
        } catch (error) {
            showWithdrawResultModal({
                success: false,
                message: error.message || 'Nu s-a putut retrage suma.'
            });
        } finally {
            setCreditBusy(false);
            updateOutButtonState();
        }
    }

    function openCreditInModal() {
        if (isMpLobbyWaiting()) return;
        if (isBalanceOverCap()) {
            openForcedWithdrawModal();
            return;
        }
        if (isGameOpen()) return;

        updateCreditInHint();
        renderCreditQuickGrid();
        openModal('creditInModal');
        const customInput = document.getElementById('creditCustomAmount');
        if (customInput) customInput.focus();
    }

    function openCreditOutModal() {
        if (isMpLobbyWaiting()) return;
        if (isBalanceOverCap()) {
            openForcedWithdrawModal();
            return;
        }
        if (withdrawableCredits(state.credits) <= 0) {
            window.alert('Nu ai sold intreg de retras.');
            return;
        }

        selectedOutRon = null;
        renderCreditOutAmountGrid();
        renderCreditOutPreview();
        openModal('creditOutModal');
    }

    function bindCreditControls() {
        const inBtn = document.getElementById('creditInBtn');
        const outBtn = document.getElementById('creditOutBtn');
        const inCancel = document.getElementById('creditInCancelBtn');
        const outCancel = document.getElementById('creditOutCancelBtn');
        const outConfirm = document.getElementById('creditOutConfirmBtn');
        const forcedConfirm = document.getElementById('forcedWithdrawConfirmBtn');
        const customBtn = document.getElementById('creditCustomBtn');
        const customInput = document.getElementById('creditCustomAmount');

        if (inBtn) inBtn.addEventListener('click', openCreditInModal);
        if (outBtn) outBtn.addEventListener('click', openCreditOutModal);
        if (inCancel) inCancel.addEventListener('click', function () { closeModal('creditInModal'); });
        if (outCancel) {
            outCancel.addEventListener('click', function () {
                selectedOutRon = null;
                closeModal('creditOutModal');
            });
        }
        if (outConfirm) outConfirm.addEventListener('click', submitMoneyOut);
        if (forcedConfirm) forcedConfirm.addEventListener('click', submitForcedMoneyOut);
        const resultOk = document.getElementById('creditOutResultOkBtn');
        if (resultOk) {
            resultOk.addEventListener('click', closeWithdrawResultModal);
        }
        if (customBtn) {
            customBtn.addEventListener('click', function () {
                submitMoneyIn(customInput ? customInput.value : 0);
            });
        }
        if (customInput) {
            customInput.addEventListener('keydown', function (event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    submitMoneyIn(customInput.value);
                }
            });
        }

        ['creditInModal', 'creditOutModal', 'mpEntryModal', 'mpJoinConfirmModal'].forEach(function (id) {
            const modal = document.getElementById(id);
            if (!modal) return;
            modal.addEventListener('click', function (event) {
                if (event.target === modal) closeModal(id);
            });
        });
    }

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function applyStackerUi(payload) {
        if (!payload || typeof payload !== 'object') return;

        if (state.terminal) {
            state.terminal.stacker_bills = Number(payload.stacker_bills || 0);
            state.terminal.stacker_capacity = Number(payload.stacker_capacity || 1000);
            state.terminal.stacker_pct = Number(payload.stacker_pct || 0);
            state.terminal.stacker_alert = !!payload.stacker_alert;
            state.terminal.stacker_full = !!payload.stacker_full;
            state.terminal.stacker_alert_pct = Number(payload.stacker_alert_pct || 80);
            state.terminal.stacker_last_reset_at = payload.stacker_last_reset_at || null;
        }

        const alertEl = document.getElementById('terminalStackerAlert');
        const titleEl = document.getElementById('terminalStackerAlertTitle');
        const textEl = document.getElementById('terminalStackerAlertText');
        if (!alertEl || !titleEl || !textEl) return;

        const bills = Number(payload.stacker_bills || 0);
        const capacity = Number(payload.stacker_capacity || 1000);
        const full = !!payload.stacker_full;
        const alert = !!payload.stacker_alert;

        alertEl.classList.toggle('is-full', full);
        alertEl.classList.toggle('is-alert', alert && !full);

        if (full) {
            titleEl.textContent = 'Receptor plin';
            textEl.textContent = bills + ' / ' + capacity + ' foi';
            alertEl.hidden = false;
            return;
        }

        if (alert) {
            titleEl.textContent = 'Receptor aproape plin';
            textEl.textContent = bills + ' / ' + capacity + ' foi';
            alertEl.hidden = false;
            return;
        }

        alertEl.hidden = true;
    }

    function updateStatus() {
        const creditsEl = document.getElementById('creditsValue');
        const creditsLeiEl = document.getElementById('creditsLeiValue');
        const terminalEl = document.getElementById('terminalName');
        const statusDot = document.getElementById('statusDot');

        if (creditsEl) creditsEl.textContent = formatLeiAmount(state.credits);
        if (creditsLeiEl) creditsLeiEl.textContent = 'LEI';
        if (terminalEl && state.terminal) terminalEl.textContent = state.terminal.name;
        if (statusDot && state.terminal) {
            statusDot.className = 'status-dot ' + (state.terminal.status || 'offline');
        }
        if (state.terminal) {
            applyStackerUi(state.terminal);
        }
        updateOutButtonState();
        checkForcedWithdrawal();
        syncCreditsToOpenGame();
    }

    async function resetStackerFromOperator() {
        if (state.stackerBusy) return;
        if (!window.confirm('Confirmi ca receptorul a fost golit? Contorul de foi se reseteaza la 0.')) {
            return;
        }
        state.stackerBusy = true;
        try {
            const data = await apiRequest('credits.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({
                    action: 'stacker_reset',
                    notes: 'manual_operator'
                })
            });
            applyStackerUi(data);
            window.alert('Receptor resetat: 0 / ' + (data.stacker_capacity || 1000));
        } catch (error) {
            window.alert(error.message || 'Reset receptor esuat.');
        } finally {
            state.stackerBusy = false;
        }
    }

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function buildMarqueeSegment(items) {
        return items.map(function (text) {
            return '<span class="frame-marquee-item">' + escapeHtml(text) + '</span>'
                + '<span class="frame-marquee-dot" aria-hidden="true">&#9670;</span>';
        }).join('');
    }

    let marqueeResizeObserver = null;
    let marqueeResizeTimer = null;

    function getMarqueeGapPx(viewport, blocks) {
        if (blocks && blocks.length >= 2) {
            const first = blocks[0].getBoundingClientRect();
            const second = blocks[1].getBoundingClientRect();
            return Math.max(0, second.left - first.right);
        }

        const gapValue = getComputedStyle(viewport).getPropertyValue('--marquee-gap').trim();
        const parsed = parseFloat(gapValue);
        return Number.isFinite(parsed) ? parsed : 24;
    }

    function syncMarqueeTiming() {
        const viewport = document.getElementById('terminalMarqueeViewport');
        if (!viewport) {
            return;
        }

        const blocks = viewport.querySelectorAll('.frame-marquee-content');
        const content = blocks[0];
        if (!content) {
            viewport.classList.remove('is-marquee-ready');
            return;
        }

        const width = content.getBoundingClientRect().width;
        if (width <= 0) {
            return;
        }

        const pixelsPerSecond = Math.max(8, Number(viewport.dataset.marqueePixelsPerSecond) || 42);
        const gap = getMarqueeGapPx(viewport, blocks);
        const distance = width + gap;
        const duration = Math.max(4, distance / pixelsPerSecond);

        viewport.style.setProperty('--marquee-duration', duration.toFixed(2) + 's');
        viewport.classList.add('is-marquee-ready');
    }

    function scheduleMarqueeSync() {
        requestAnimationFrame(function () {
            syncMarqueeTiming();
            requestAnimationFrame(syncMarqueeTiming);
        });

        if (document.fonts && document.fonts.ready) {
            document.fonts.ready.then(syncMarqueeTiming).catch(function () {});
        }
    }

    function bindMarqueeResizeObserver() {
        const viewport = document.getElementById('terminalMarqueeViewport');
        if (!viewport || marqueeResizeObserver || typeof ResizeObserver === 'undefined') {
            return;
        }

        marqueeResizeObserver = new ResizeObserver(function () {
            clearTimeout(marqueeResizeTimer);
            marqueeResizeTimer = setTimeout(scheduleMarqueeSync, 60);
        });
        marqueeResizeObserver.observe(viewport);
    }

    function refreshMarqueeObservers() {
        const viewport = document.getElementById('terminalMarqueeViewport');
        if (!viewport) {
            return;
        }

        bindMarqueeResizeObserver();

        if (!marqueeResizeObserver) {
            return;
        }

        viewport.querySelectorAll('.frame-marquee-content').forEach(function (block) {
            marqueeResizeObserver.observe(block);
        });
    }

    function renderMarquee(marquee) {
        const wrap = document.getElementById('terminalMarquee');
        const viewport = document.getElementById('terminalMarqueeViewport');
        if (!wrap || !viewport) {
            return;
        }

        const payload = marquee && typeof marquee === 'object' ? marquee : {};
        const items = Array.isArray(payload.items) ? payload.items.filter(Boolean) : [];
        const enabled = !!payload.enabled && items.length > 0;
        const pixelsPerSecond = Math.max(8, Number(payload.pixels_per_second) || 42);
        const signature = enabled
            ? [pixelsPerSecond].concat(items).join('\u0001')
            : '';

        if (!enabled) {
            wrap.hidden = true;
            viewport.innerHTML = '';
            viewport.classList.remove('is-marquee-ready');
            delete viewport.dataset.marqueePixelsPerSecond;
            state.marqueeSignature = '';
            return;
        }

        wrap.hidden = false;
        viewport.dataset.marqueePixelsPerSecond = String(pixelsPerSecond);

        if (signature !== state.marqueeSignature) {
            const segment = buildMarqueeSegment(items);
            viewport.classList.remove('is-marquee-ready');
            viewport.innerHTML =
                '<div class="frame-marquee-content">' + segment + '</div>'
                + '<div class="frame-marquee-content" aria-hidden="true">' + segment + '</div>';
            state.marqueeSignature = signature;
        }

        refreshMarqueeObservers();
        scheduleMarqueeSync();
    }

    let lastMpWinContestId = 0;
    let lastMpSoundContestId = 0;
    const winnerBalanceRefreshByContest = {};
    const MP_WIN_SEEN_KEY = 'iqwin_mp_win_seen';

    function loadSeenMpWinIds() {
        try {
            const raw = sessionStorage.getItem(MP_WIN_SEEN_KEY);
            if (!raw) return [];
            const parsed = JSON.parse(raw);
            return Array.isArray(parsed) ? parsed.map(function (id) { return Number(id) || 0; }).filter(Boolean) : [];
        } catch (e) {
            return [];
        }
    }

    function markMpWinSeen(contestId) {
        const id = Number(contestId) || 0;
        if (!id) return;
        const ids = loadSeenMpWinIds();
        if (ids.indexOf(id) === -1) {
            ids.push(id);
        }
        try {
            sessionStorage.setItem(MP_WIN_SEEN_KEY, JSON.stringify(ids.slice(-30)));
        } catch (e) {}
        lastMpWinContestId = id;
        lastMpSoundContestId = id;
    }

    function hasSeenMpWin(contestId) {
        const id = Number(contestId) || 0;
        if (!id) return false;
        if (id === lastMpWinContestId) return true;
        return loadSeenMpWinIds().indexOf(id) !== -1;
    }

    function sanitizeContestForNormalPlay(contest) {
        if (!contest || typeof contest !== 'object') {
            return contest;
        }
        const win = contest.recent_win;
        const winId = win ? Number(win.contest_id) || 0 : 0;
        if (!winId || !hasSeenMpWin(winId)) {
            return contest;
        }
        const next = Object.assign({}, contest);
        delete next.recent_win;
        const mode = String(next.mode || '');
        if (mode === 'won' || mode === 'forfeit' || mode === 'draw') {
            next.mode = 'ready';
            next.enabled = false;
        }
        return next;
    }

    function initMpWinMemory() {
        const ids = loadSeenMpWinIds();
        if (!ids.length) return;
        const latest = Math.max.apply(null, ids);
        if (latest > 0) {
            lastMpWinContestId = latest;
            lastMpSoundContestId = latest;
        }
    }
    let mpWinHideTimer = null;
    let mpWinCountTimer = null;
    let mpEpicAudio = null;
    let mpLobbyCountdownTimer = null;
    let mpLobbyCountdownBase = { seconds: 0, syncedAt: 0 };

    function stopMpLobbyCountdown() {
        if (mpLobbyCountdownTimer) {
            window.clearInterval(mpLobbyCountdownTimer);
            mpLobbyCountdownTimer = null;
        }
    }

    function tickMpLobbyCountdown() {
        const timerEl = document.getElementById('terminalMpLobbyTimer');
        if (!timerEl) return;
        const elapsed = Math.floor((Date.now() - mpLobbyCountdownBase.syncedAt) / 1000);
        const remaining = Math.max(0, mpLobbyCountdownBase.seconds - elapsed);
        timerEl.textContent = formatMpCountdown(remaining);
    }

    function syncMpLobbyCountdown(contest) {
        stopMpLobbyCountdown();
        if (!contest || String(contest.mode || '') !== 'lobby' || !contest.is_participant) {
            return;
        }
        mpLobbyCountdownBase = {
            seconds: Math.max(0, Math.floor(Number(contest.lobby_seconds_remaining) || 0)),
            syncedAt: Date.now()
        };
        tickMpLobbyCountdown();
        mpLobbyCountdownTimer = window.setInterval(tickMpLobbyCountdown, 1000);
    }

    function stopMpEpicSound() {
        if (!mpEpicAudio) return;
        try {
            mpEpicAudio.pause();
            mpEpicAudio.currentTime = 0;
        } catch (e) {}
        mpEpicAudio = null;
    }

    function playMpEpicSound() {
        stopMpEpicSound();
        const urls = [
            '../games/shared/sounds/jackpot.mp3',
            '/games/shared/sounds/jackpot.mp3',
            '../games/shared/sounds/hugewin.mp3'
        ];
        let idx = 0;
        function tryNext() {
            if (idx >= urls.length) return;
            const url = urls[idx];
            idx += 1;
            try {
                mpEpicAudio = new Audio(url);
                mpEpicAudio.volume = 0.92;
                mpEpicAudio.play().catch(tryNext);
                window.setTimeout(stopMpEpicSound, 12000);
            } catch (e) {
                tryNext();
            }
        }
        tryNext();
    }

    function animateTerminalMpPrize(lei, totalCredits, spinCredits, totalLei) {
        const prizeEl = document.getElementById('terminalMpWinPrize');
        const creditsEl = document.getElementById('terminalMpWinCredits');
        if (!prizeEl) return;

        if (mpWinCountTimer) window.clearInterval(mpWinCountTimer);
        const blitzLei = Math.max(0, Math.round(Number(lei) || 0));
        const spinWin = Math.max(0, Math.round(Number(spinCredits) || 0));
        const spinLei = spinWin > 0 ? moneyForCredits(spinWin) : 0;
        let totalMoney = Number(totalLei) || 0;
        if (!(totalMoney > 0)) {
            totalMoney = moneyForCredits(totalCredits);
        }
        if (!(totalMoney > 0)) {
            totalMoney = blitzLei + spinLei;
        }
        const displayTarget = Math.max(0, Math.round(totalMoney));
        let current = 0;
        const steps = 28;
        const step = Math.max(1, Math.ceil(displayTarget / steps));
        let tick = 0;

        if (creditsEl) {
            if (spinLei > 0 && blitzLei > 0) {
                creditsEl.textContent = 'Premiu Blitz: ' + blitzLei.toLocaleString('ro-RO') + ' LEI · Castig spinuri: ' + formatLeiAmount(spinWin) + ' LEI';
            } else if (spinLei > 0) {
                creditsEl.textContent = 'Castig spinuri: ' + formatLeiAmount(spinWin) + ' LEI';
            } else if (blitzLei > 0) {
                creditsEl.textContent = 'Premiu Blitz: ' + blitzLei.toLocaleString('ro-RO') + ' LEI';
            } else {
                creditsEl.textContent = 'Total pe sold: ' + formatLeiAmount(totalCredits) + ' LEI';
            }
        }

        if (!(displayTarget > 0)) {
            prizeEl.textContent = '0 LEI';
            return;
        }

        prizeEl.textContent = '0 LEI';
        mpWinCountTimer = window.setInterval(function () {
            tick += 1;
            current = Math.min(displayTarget, current + step);
            prizeEl.textContent = current.toLocaleString('ro-RO') + ' LEI';
            if (current >= displayTarget || tick > steps + 5) {
                prizeEl.textContent = displayTarget.toLocaleString('ro-RO') + ' LEI';
                window.clearInterval(mpWinCountTimer);
                mpWinCountTimer = null;
            }
        }, 40);
    }

    function showTerminalMpWin(win, isSelf) {
        const overlay = document.getElementById('terminalMpWin');
        const youEl = document.getElementById('terminalMpWinYou');
        const subEl = document.getElementById('terminalMpWinSub');
        if (!overlay || !win) return;

        const lei = Math.round(Number(win.prize_amount) || 0);
        const prizeCredits = Math.round(Number(win.credits_awarded) || 0);
        const spinCredits = Math.round(Number(win.spin_winnings_credits) || 0);
        const totalCredits = Math.round(Number(win.total_credits_awarded) || (prizeCredits + spinCredits));
        const totalLei = Number(win.total_lei_awarded) || 0;
        const winnerName = String(win.winner_name || 'Terminal').toUpperCase();

        if (youEl) {
            youEl.textContent = isSelf ? 'AI CÂȘTIGAT!' : (winnerName + ' A CÂȘTIGAT!');
        }
        const spinLei = Number(win.spin_winnings_lei) || (spinCredits > 0 ? moneyForCredits(spinCredits) : 0);
        if (subEl) {
            subEl.textContent = isSelf
                ? (spinLei > 0
                    ? ('Premiu Blitz: ' + lei.toLocaleString('ro-RO') + ' LEI · Castig din 50 spinuri: ' + spinLei.toLocaleString('ro-RO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' LEI · Total pe sold.')
                    : 'Premiul a intrat pe soldul normal.')
                : 'Premiu multiplayer acordat in shop.';
        }

        overlay.classList.remove('is-on');
        void overlay.offsetWidth;
        overlay.hidden = false;
        overlay.classList.add('is-on');
        animateTerminalMpPrize(lei, totalCredits, spinCredits, totalLei);

        if (mpWinHideTimer) window.clearTimeout(mpWinHideTimer);
        mpWinHideTimer = window.setTimeout(function () {
            overlay.hidden = true;
            overlay.classList.remove('is-on');
            stopMpEpicSound();
        }, isSelf ? 11000 : 7000);
    }

    function scheduleWinnerBalanceRefresh(contestId) {
        if (!contestId || winnerBalanceRefreshByContest[contestId]) {
            return;
        }
        winnerBalanceRefreshByContest[contestId] = true;
        let attempts = 0;
        const timer = setInterval(async function () {
            attempts += 1;
            if (attempts > 10) {
                clearInterval(timer);
                delete winnerBalanceRefreshByContest[contestId];
                return;
            }
            try {
                const data = await apiRequest('heartbeat.php', {
                    method: 'POST',
                    headers: apiHeaders(),
                    body: JSON.stringify({
                        credits_balance: state.credits,
                        app_version: '1.0.0',
                        game_overlay_open: isGameOpen()
                    })
                });
                if (data && data.contest) {
                    syncContest(data.contest);
                }
                const win = data && data.contest && data.contest.recent_win;
                if (win && win.is_self) {
                    const balance = typeof win.credits_balance === 'number'
                        ? Number(win.credits_balance)
                        : (typeof data.credits_balance === 'number' ? Number(data.credits_balance) : null);
                    if (balance !== null) {
                        state.credits = balance;
                        if (state.terminal) state.terminal.credits_balance = balance;
                        syncCreditsToOpenGame({ credits: balance });
                        updateStatus();
                    }
                    if (typeof win.credits_balance === 'number') {
                        clearInterval(timer);
                        delete winnerBalanceRefreshByContest[contestId];
                    }
                }
            } catch (error) {
            }
        }, 1500);
    }

    function handleShopMultiplayerWin(contest, options) {
        const win = contest && contest.recent_win;
        if (!win || !win.contest_id) return;
        if (win.result_type === 'forfeit' || win.is_forfeit) return;
        if (win.result_type !== 'winner' || !win.winner_terminal_id) return;

        const opts = options || {};
        const winId = Number(win.contest_id) || 0;
        const isSelf = !!win.is_self;
        const playSound = opts.playSound !== false;
        const alreadySeen = winId ? hasSeenMpWin(winId) : false;

        if (playSound && winId && !alreadySeen) {
            markMpWinSeen(winId);
            playMpEpicSound();
        }

        if (isSelf) {
            if (typeof win.credits_balance === 'number') {
                state.credits = Number(win.credits_balance);
                if (state.terminal) state.terminal.credits_balance = state.credits;
                const totalCredits = Math.round(Number(win.total_credits_awarded) || Number(win.credits_awarded) || 0);
                const syncExtra = { credits: state.credits };
                if (totalCredits > 0 && winId && !alreadySeen) {
                    syncExtra.lastWin = totalCredits;
                }
                syncCreditsToOpenGame(syncExtra);
                updateStatus();
            } else if (winId) {
                scheduleWinnerBalanceRefresh(winId);
            }
            if (alreadySeen) {
                return;
            }
            if (winId && !playSound) {
                markMpWinSeen(winId);
            }
            showTerminalMpWin(win, true);
            return;
        }

        if (opts.showOthers === true) {
            if (alreadySeen) {
                return;
            }
            if (winId) {
                markMpWinSeen(winId);
            }
            showTerminalMpWin(win, false);
        }
    }

    function applyMultiplayerWin(contest) {
        const win = contest && contest.recent_win;
        if (!win || !win.contest_id) return;
        if (win.result_type === 'forfeit' || win.is_forfeit) return;
        if (win.result_type !== 'winner' || !win.winner_terminal_id) return;

        const winId = Number(win.contest_id) || 0;
        const alreadySeen = winId ? hasSeenMpWin(winId) : false;

        handleShopMultiplayerWin(contest, {
            playSound: !alreadySeen,
            showOthers: false
        });
    }

    function getContestRevision(contest) {
        if (!contest || typeof contest !== 'object') {
            return '0';
        }
        return [
            contest.contest_revision || 0,
            contest.contest_id || 0,
            contest.mode || '',
            contest.is_participant ? 1 : 0,
            contest.lobby_invite ? 1 : 0,
            contest.participants_count || 0,
            contest.lobby_can_start ? 1 : 0
        ].join(':');
    }

    function rebroadcastOpenGameDisplay() {
        if (!window.TerminalDisplaySync || !isGameOpen() || !state.currentGameId) {
            return;
        }
        const game = (state.games || []).find(function (item) {
            return Number(item.id) === Number(state.currentGameId);
        });
        if (!game) {
            return;
        }
        window.TerminalDisplaySync.broadcastGame(game);
        const frame = document.getElementById('gameFrame');
        if (frame && window.TerminalDisplaySync.requestGameInfo) {
            window.TerminalDisplaySync.requestGameInfo(frame);
        }
    }

    function syncContest(contest, options) {
        if (!contest || typeof contest !== 'object') {
            updateMultiplayerButton(null);
            updateBlitzContestLobbyTheme(null);
            updateMpLobbyLock(null);
            return;
        }

        const opts = options || {};
        state.lastContestRevision = getContestRevision(contest);
        const wasEnabled = !!state.contestEnabled;
        const enabled = !!contest.enabled || String(contest.mode || '') === 'lobby';
        state.contestEnabled = enabled;
        state.contest = contest;
        updateMultiplayerButton(contest);
        updateMpLobbyUi(contest);
        updateBlitzContestLobbyTheme(contest);
        const recentWin = contest.recent_win;
        if (recentWin && recentWin.is_self) {
            let nextBalance = null;
            if (typeof recentWin.credits_balance === 'number') {
                nextBalance = Number(recentWin.credits_balance);
            } else if (typeof opts.creditsBalance === 'number') {
                nextBalance = Number(opts.creditsBalance);
            }
            if (nextBalance !== null) {
                state.credits = nextBalance;
                if (state.terminal) state.terminal.credits_balance = nextBalance;
                updateStatus();
                const totalCredits = Math.round(Number(recentWin.total_credits_awarded) || Number(recentWin.credits_awarded) || 0);
                const winId = Number(recentWin.contest_id) || 0;
                const syncExtra = { credits: nextBalance };
                if (totalCredits > 0 && winId && !hasSeenMpWin(winId)) {
                    syncExtra.lastWin = totalCredits;
                }
                syncCreditsToOpenGame(syncExtra);
            } else if (recentWin.contest_id) {
                scheduleWinnerBalanceRefresh(Number(recentWin.contest_id));
            }
        }

        applyMultiplayerWin(contest);
        const gameContest = sanitizeContestForNormalPlay(contest);
        syncContestToGame(gameContest);

        if (window.TerminalDisplaySync && window.TerminalDisplaySync.broadcastContest) {
            window.TerminalDisplaySync.broadcastContest(contest);
        }

        if (String(contest.mode || '') === 'lobby' || contest.lobby_open === true || contest.lobby_invite === true) {
            bumpMpPollForOtherTabs(getContestRevision(contest));
        }

        scheduleContestPoll();

        if (wasEnabled && !enabled && isGameOpen() && window.TerminalDisplaySync) {
            rebroadcastOpenGameDisplay();
            window.setTimeout(rebroadcastOpenGameDisplay, 11000);
            const frame = document.getElementById('gameFrame');
            if (frame && window.TerminalDisplaySync.requestGameInfo) {
                window.setTimeout(function () {
                    window.TerminalDisplaySync.requestGameInfo(frame);
                }, 12000);
                window.setTimeout(function () {
                    window.TerminalDisplaySync.requestGameInfo(frame);
                }, 22000);
            }
        }

        if (wasEnabled && !enabled) {
            updateStatus();
            const winId = recentWin ? Number(recentWin.contest_id) || 0 : 0;
            const totalCredits = recentWin
                ? Math.round(Number(recentWin.total_credits_awarded) || Number(recentWin.credits_awarded) || 0)
                : 0;
            const syncExtra = recentWin && recentWin.is_self && typeof recentWin.credits_balance === 'number'
                ? { credits: Number(recentWin.credits_balance) }
                : undefined;
            if (syncExtra && totalCredits > 0 && winId && !hasSeenMpWin(winId)) {
                syncExtra.lastWin = totalCredits;
            }
            syncCreditsToOpenGame(syncExtra);
            if (contest.recent_win && isGameOpen()) {
                const frame = document.getElementById('gameFrame');
                if (frame && frame.contentWindow) {
                    try {
                        frame.contentWindow.postMessage({
                            type: 'iqwin-contest-result-pause',
                            contest: contest
                        }, '*');
                    } catch (e) {}
                }
            }
        }
    }

    function isBlitzContestLobbyActive(contest) {
        if (!contest || !contest.available) {
            return false;
        }
        if (!contest.enabled || String(contest.mode || '') !== 'contest') {
            return false;
        }
        const count = Number(contest.terminals_count ?? contest.participants_count ?? 0);
        return count >= 2;
    }

    function updateBlitzContestLobbyTheme(contest) {
        document.body.classList.toggle('is-blitz-contest-live', isBlitzContestLobbyActive(contest));
    }

    function isMpParticipant(contest) {
        if (!contest || typeof contest !== 'object') {
            return false;
        }
        return contest.is_participant === true || contest.is_participant === 1;
    }

    function isMpLobbyInvite(contest) {
        if (!contest || typeof contest !== 'object') {
            return false;
        }
        if (contest.lobby_invite === true) {
            return true;
        }
        if (contest.lobby_open === true && !isMpParticipant(contest)) {
            return true;
        }
        return String(contest.mode || '') === 'lobby' && !isMpParticipant(contest);
    }

    function updateMultiplayerButton(contest) {
        const btn = document.getElementById('multiplayerBtn');
        const label = document.getElementById('multiplayerBtnLabel');
        if (!btn) return;

        const available = !!(contest && contest.available);
        const enabled = !!(contest && contest.enabled);
        const mode = contest ? String(contest.mode || '') : '';
        const lobbyInvite = isMpLobbyInvite(contest);

        if (!available) {
            btn.hidden = true;
            btn.disabled = true;
            btn.classList.remove('is-live', 'is-lobby-invite');
            if (label) label.textContent = 'MULTIPLAYER';
            return;
        }

        btn.hidden = false;
        btn.classList.remove('is-live', 'is-lobby-invite');

        if (mode === 'lobby') {
            btn.classList.add('is-live');
            if (isMpParticipant(contest)) {
                btn.disabled = true;
                if (label) label.textContent = 'ASTEPTAM...';
            } else {
                btn.classList.add('is-lobby-invite');
                btn.disabled = false;
                if (label) label.textContent = 'INTRA IN BLITZ';
            }
            btn.setAttribute('aria-label', isMpParticipant(contest) ? 'Concurs Blitz in asteptare' : 'Concurs Blitz deschis in shop');
            return;
        }

        if (lobbyInvite) {
            btn.classList.add('is-live', 'is-lobby-invite');
            btn.disabled = false;
            if (label) label.textContent = 'INTRA IN BLITZ';
            btn.setAttribute('aria-label', 'Concurs Blitz deschis in shop');
            return;
        }

        if (enabled && mode === 'contest') {
            btn.classList.add('is-live');
            btn.disabled = true;
            if (label) label.textContent = 'BLITZ ON';
            btn.setAttribute('aria-label', 'Concurs Blitz activ');
            return;
        }

        btn.classList.remove('is-live');
        btn.disabled = false;
        if (label) label.textContent = 'MULTIPLAYER';
        btn.setAttribute('aria-label', 'Porneste Multiplayer');
    }

    function formatMpLei(value) {
        const num = Number(value) || 0;
        return num.toLocaleString('ro-RO', {
            minimumFractionDigits: Number.isInteger(num) ? 0 : 2,
            maximumFractionDigits: 2
        });
    }

    function resolveMpTier(contest, fee) {
        const tiers = (contest && contest.entry_tiers) || [];
        const entryFee = Number(fee || (contest && contest.entry_fee)) || 0;
        if (contest && contest.tier && Number(contest.tier.entry_fee) === entryFee) {
            return contest.tier;
        }
        const found = tiers.find(function (t) {
            return Math.abs(Number(t.entry_fee) - entryFee) < 0.001;
        });
        if (found) return found;
        const half = entryFee;
        let spinLei = 1;
        if (Math.abs(entryFee - 50) < 0.001) spinLei = 0.5;
        else if (Math.abs(entryFee - 200) < 0.001) spinLei = 2;
        const spinReserveLei = spinLei * 50;
        return {
            entry_fee: entryFee,
            spin_lei: Number(contest && contest.spin_lei) || spinLei,
            blitz_share_lei: half,
            spin_budget_lei: spinReserveLei,
            spin_reserve_lei: spinReserveLei,
            spins: 50
        };
    }

    function mpEntryTierVariant(entryFee) {
        if (Math.abs(entryFee - 50) < 0.001) return 'bronze';
        if (Math.abs(entryFee - 100) < 0.001) return 'silver';
        return 'gold';
    }

    function buildMpTierCardHtml(tier) {
        const fee = Number(tier.entry_fee) || 0;
        const potShare = Number(tier.blitz_share_lei) || fee;
        const spinLei = Number(tier.spin_lei) || 1;
        const spinReserve = Number(tier.spin_reserve_lei) || Number(tier.spin_budget_lei) || spinLei * 50;
        const spins = Number(tier.spins) || 50;
        const variant = mpEntryTierVariant(fee);
        return (
            '<button type="button" class="mp-entry-tier-btn mp-entry-tier-btn--' + variant + '" data-fee="' + fee + '">' +
                '<span class="mp-entry-tier-left">' +
                    '<span class="mp-entry-tier-badge" aria-hidden="true"><i class="fa-solid fa-bolt"></i></span>' +
                    '<strong class="mp-entry-tier-fee">' + formatMpLei(fee) + ' LEI</strong>' +
                '</span>' +
                '<span class="mp-entry-tier-divider" aria-hidden="true"></span>' +
                '<span class="mp-entry-tier-right">' +
                    '<span class="mp-entry-tier-line">' + formatMpLei(potShare) + ' LEI in pot Blitz</span>' +
                    '<span class="mp-entry-tier-line">' + spins + ' spinuri × ' + formatMpLei(spinLei) + ' LEI (sold normal)</span>' +
                    '<span class="mp-entry-tier-line">Minim ' + formatMpLei(fee + spinReserve) + ' LEI total</span>' +
                '</span>' +
            '</button>'
        );
    }

    function buildMpTierCardStaticHtml(tier) {
        const fee = Number(tier.entry_fee) || 0;
        const potShare = Number(tier.blitz_share_lei) || fee;
        const spinLei = Number(tier.spin_lei) || 1;
        const spinReserve = Number(tier.spin_reserve_lei) || Number(tier.spin_budget_lei) || spinLei * 50;
        const spins = Number(tier.spins) || 50;
        const variant = mpEntryTierVariant(fee);
        return (
            '<div class="mp-join-tier-card mp-entry-tier-btn mp-entry-tier-btn--' + variant + ' mp-join-tier-card--static">' +
                '<span class="mp-entry-tier-left">' +
                    '<span class="mp-entry-tier-badge" aria-hidden="true"><i class="fa-solid fa-bolt"></i></span>' +
                    '<strong class="mp-entry-tier-fee">' + formatMpLei(fee) + ' LEI</strong>' +
                '</span>' +
                '<span class="mp-entry-tier-divider" aria-hidden="true"></span>' +
                '<span class="mp-entry-tier-right">' +
                    '<span class="mp-entry-tier-line">' + formatMpLei(potShare) + ' LEI in pot Blitz / jucator</span>' +
                    '<span class="mp-entry-tier-line">' + spins + ' spinuri × ' + formatMpLei(spinLei) + ' LEI (sold normal)</span>' +
                    '<span class="mp-entry-tier-line">Minim ' + formatMpLei(fee + spinReserve) + ' LEI total</span>' +
                '</span>' +
            '</div>'
        );
    }

    function buildMpJoinDetailsHtml(tier) {
        const fee = Number(tier.entry_fee) || 0;
        const estPrize = Number(tier.estimated_blitz_prize) || fee * 2;
        return (
            buildMpTierCardStaticHtml(tier) +
            '<div class="mp-join-estimate">' +
                '<span>Pot Blitz estimat (2 jucatori)</span>' +
                '<strong>' + formatMpLei(estPrize) + ' LEI</strong>' +
            '</div>'
        );
    }

    function openMpEntryModal(contest) {
        const modal = document.getElementById('mpEntryModal');
        const grid = document.getElementById('mpEntryGrid');
        const winInfo = document.getElementById('mpEntryWinInfo');
        if (!modal || !grid) return Promise.resolve(null);
        const tiers = (contest && contest.entry_tiers && contest.entry_tiers.length)
            ? contest.entry_tiers
            : [
                { entry_fee: 50, spin_lei: 0.5, blitz_share_lei: 50, spin_reserve_lei: 25, spins: 50 },
                { entry_fee: 100, spin_lei: 1, blitz_share_lei: 100, spin_reserve_lei: 50, spins: 50 },
                { entry_fee: 200, spin_lei: 2, blitz_share_lei: 200, spin_reserve_lei: 100, spins: 50 }
            ];
        grid.innerHTML = tiers.map(buildMpTierCardHtml).join('');
        if (winInfo) {
            winInfo.textContent = (contest && contest.win_info)
                || 'Castiga primul jucator care termina cele 50 spinuri. Primeste potul Blitz plus castigurile din spinuri.';
        }
        openModal('mpEntryModal');
        return new Promise(function (resolve) {
            function cleanup(result) {
                closeModal('mpEntryModal');
                grid.querySelectorAll('.mp-entry-tier-btn').forEach(function (el) {
                    el.removeEventListener('click', onPick);
                });
                const cancel = document.getElementById('mpEntryCancelBtn');
                if (cancel) cancel.removeEventListener('click', onCancel);
                resolve(result);
            }
            function onPick(event) {
                const fee = Number(event.currentTarget.getAttribute('data-fee'));
                cleanup(fee > 0 ? fee : null);
            }
            function onCancel() {
                cleanup(null);
            }
            grid.querySelectorAll('.mp-entry-tier-btn').forEach(function (el) {
                el.addEventListener('click', onPick);
            });
            const cancel = document.getElementById('mpEntryCancelBtn');
            if (cancel) cancel.addEventListener('click', onCancel);
        });
    }

    function openMpJoinConfirmModal(contest) {
        const modal = document.getElementById('mpJoinConfirmModal');
        const question = document.getElementById('mpJoinQuestion');
        const details = document.getElementById('mpJoinDetails');
        const winInfo = document.getElementById('mpJoinWinInfo');
        const confirmBtn = document.getElementById('mpJoinConfirmBtn');
        if (!modal) return Promise.resolve(false);
        const fee = Number(contest && contest.entry_fee) || 0;
        const tier = resolveMpTier(contest, fee);
        if (question) {
            question.textContent = 'Accepti sa intri cu soldul de ' + formatMpLei(fee) + ' LEI in concursul Blitz?';
        }
        if (details) {
            details.innerHTML = buildMpJoinDetailsHtml(tier);
        }
        if (winInfo) {
            winInfo.textContent = (contest && contest.win_info)
                || 'Castiga primul jucator care termina cele 50 spinuri. Primeste potul Blitz plus castigurile din spinuri.';
        }
        if (confirmBtn) confirmBtn.disabled = false;
        openModal('mpJoinConfirmModal');
        return new Promise(function (resolve) {
            function cleanup(result) {
                closeModal('mpJoinConfirmModal');
                if (confirmBtn) confirmBtn.removeEventListener('click', onConfirm);
                const cancel = document.getElementById('mpJoinCancelBtn');
                if (cancel) cancel.removeEventListener('click', onCancel);
                resolve(result);
            }
            function onConfirm() {
                cleanup(true);
            }
            function onCancel() {
                cleanup(false);
            }
            if (confirmBtn) confirmBtn.addEventListener('click', onConfirm);
            const cancel = document.getElementById('mpJoinCancelBtn');
            if (cancel) cancel.addEventListener('click', onCancel);
        });
    }

    function formatMpCountdown(totalSeconds) {
        const s = Math.max(0, Math.floor(Number(totalSeconds) || 0));
        const m = Math.floor(s / 60);
        const r = s % 60;
        return String(m).padStart(2, '0') + ':' + String(r).padStart(2, '0');
    }

    function isMpLobbyWaiting(contest) {
        const payload = contest || state.contest || {};
        return String(payload.mode || '') === 'lobby' && isMpParticipant(payload);
    }

    function updateMpLobbyLock(contest) {
        document.body.classList.toggle('is-mp-lobby-waiting', isMpLobbyWaiting(contest));
        updateCreditButtonStates();
    }

    function updateMpLobbyUi(contest) {
        const panel = document.getElementById('terminalMpLobby');
        const startBtn = document.getElementById('terminalMpLobbyStartBtn');
        const feeEl = document.getElementById('terminalMpLobbyFee');
        const tierCardEl = document.getElementById('terminalMpLobbyTierCard');
        const winInfoEl = document.getElementById('terminalMpLobbyWinInfo');
        const countEl = document.getElementById('terminalMpLobbyCount');
        const subEl = document.getElementById('terminalMpLobbySub');
        if (!panel) return;

        const mode = contest ? String(contest.mode || '') : '';
        const waiting = mode === 'lobby' && isMpParticipant(contest);
        updateMpLobbyLock(contest);

        if (!waiting) {
            stopMpLobbyCountdown();
            panel.hidden = true;
            panel.classList.remove('is-on');
            if (startBtn) {
                startBtn.hidden = true;
                startBtn.disabled = false;
                startBtn.textContent = 'Porneste';
            }
            return;
        }

        panel.hidden = false;
        panel.classList.add('is-on');

        syncMpLobbyCountdown(contest);
        const tier = resolveMpTier(contest, contest.entry_fee);
        const fee = Math.round(Number(contest.entry_fee) || 0);
        const charged = !!contest.entry_charged;
        const count = Number(contest.participants_count) || 0;
        const minCount = Number(contest.lobby_min_participants) || 2;
        const canStart = !!contest.lobby_can_start && count >= minCount;
        if (startBtn) {
            startBtn.hidden = !canStart;
            startBtn.disabled = !canStart;
        }
        if (feeEl) {
            feeEl.textContent = charged
                ? 'Intrare: ' + formatMpLei(fee) + ' LEI (scazut din sold)'
                : 'Intrare: ' + formatMpLei(fee) + ' LEI (soldul se scade la start)';
        }
        if (tierCardEl) {
            tierCardEl.innerHTML = buildMpTierCardStaticHtml(Object.assign({}, tier, { entry_fee: fee }));
        }
        if (winInfoEl) {
            winInfoEl.textContent = contest.win_info
                || 'Castiga primul jucator care termina cele 50 spinuri. Primeste potul Blitz plus castigurile din spinuri.';
        }
        if (countEl) {
            if (count < minCount) {
                const need = minCount - count;
                countEl.innerHTML = '<strong>Concurenți înscriși:</strong> ' + count + ' — așteptăm încă ' + need + ' terminal' + (need > 1 ? 'e' : '');
            } else {
                countEl.innerHTML = '<strong>Concurenți înscriși:</strong> ' + count + ' — poți apăsa Porneste sau aștepta expirarea timpului';
            }
        }
        if (subEl) {
            if (count < minCount) {
                subEl.textContent = 'Din același shop. Minim ' + minCount + ' concurenți pentru start.';
            } else {
                subEl.textContent = 'Minim ' + minCount + ' concurenți confirmați. Apasă Porneste sau așteaptă expirarea timpului.';
            }
        }
    }

    async function startMpLobbyManually() {
        const startBtn = document.getElementById('terminalMpLobbyStartBtn');
        const contest = state.contest || {};
        if (!isMpLobbyWaiting(contest)) {
            return;
        }
        if (startBtn) {
            startBtn.disabled = true;
            startBtn.textContent = 'Pornire...';
        }
        try {
            const data = await apiRequest('contest-lobby-start.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({})
            });
            if (data && data.contest) {
                syncContest(data.contest, { creditsBalance: data.credits_balance });
            }
            if (data && typeof data.credits_balance === 'number') {
                state.credits = Number(data.credits_balance);
                if (state.terminal) state.terminal.credits_balance = state.credits;
                updateStatus();
            }
            if (data && data.contest && String(data.contest.mode || '') === 'active') {
                stopMpLobbyCountdown();
            } else if (startBtn) {
                startBtn.disabled = false;
                startBtn.textContent = 'Porneste';
            }
        } catch (error) {
            if (startBtn) {
                startBtn.disabled = false;
                startBtn.textContent = 'Porneste';
            }
            showTerminalNoticeModal(error.message || 'Nu am putut porni concursul.', 'Concurs Blitz');
        }
    }

    async function startMultiplayerContest() {
        const btn = document.getElementById('multiplayerBtn');
        const contest = state.contest || {};
        const mode = String(contest.mode || '');

        if (mode === 'lobby' && !contest.is_participant) {
            const fee = Number(contest.entry_fee) || 0;
            if (!(fee > 0)) {
                showTerminalNoticeModal('Concurs invalid.', 'Concurs Blitz');
                return;
            }
            const accepted = await openMpJoinConfirmModal(contest);
            if (!accepted) return;
            if (btn) btn.disabled = true;
            try {
                const data = await apiRequest('contest-start.php', {
                    method: 'POST',
                    headers: apiHeaders(),
                    body: JSON.stringify({ entry_fee: fee })
                });
                if (data && data.contest) syncContest(data.contest);
                if (data && typeof data.credits_balance === 'number') {
                    state.credits = Number(data.credits_balance);
                    if (state.terminal) state.terminal.credits_balance = state.credits;
                    updateStatus();
                }
            } catch (error) {
                if (btn) btn.disabled = false;
                showTerminalNoticeModal(error.message || 'Nu am putut intra in concurs.', 'Sold insuficient');
            }
            return;
        }

        const entryFee = await openMpEntryModal(contest);
        if (!(entryFee > 0)) return;

        if (btn) btn.disabled = true;
        try {
            const data = await apiRequest('contest-start.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({ entry_fee: entryFee })
            });
            if (data && data.contest) {
                syncContest(data.contest);
            }
            if (data && typeof data.credits_balance === 'number') {
                state.credits = Number(data.credits_balance);
                if (state.terminal) state.terminal.credits_balance = state.credits;
                updateStatus();
            }
        } catch (error) {
            if (btn) btn.disabled = false;
            showTerminalNoticeModal(error.message || 'Nu am putut porni Multiplayer.', 'Concurs Blitz');
        }
    }

    function syncContestToGame(contest) {
        const frame = document.getElementById('gameFrame');
        if (!frame || !frame.contentWindow) return;
        try {
            frame.contentWindow.postMessage({
                type: 'iqwin-contest-state',
                contest: contest || null
            }, '*');
        } catch (e) {}
    }

    function bindMultiplayerButton() {
        const btn = document.getElementById('multiplayerBtn');
        if (!btn) return;
        btn.addEventListener('click', function () {
            if (btn.disabled || btn.hidden) return;
            startMultiplayerContest();
        });

        const lobbyStartBtn = document.getElementById('terminalMpLobbyStartBtn');
        if (lobbyStartBtn) {
            lobbyStartBtn.addEventListener('click', function () {
                if (lobbyStartBtn.disabled || lobbyStartBtn.hidden) return;
                startMpLobbyManually();
            });
        }
    }

    async function bootstrap() {
        const data = await apiRequest('bootstrap.php', { method: 'GET', headers: apiHeaders() });
        state.terminal = data.terminal;
        state.games = data.games || [];
        state.credits = data.terminal.credits_balance || 0;
        state.refreshSeconds = data.refresh_seconds || 15;
        const gamesSignature = getGamesSignature(state.games);
        if (gamesSignature !== state.gamesSignature) {
            state.gamesSignature = gamesSignature;
            renderGames();
        }
        renderMarquee(data.marquee);
        applyStackerUi(data.terminal || {});
        syncContest(data.contest);
        applyBalanceCapFromServer(data);
        updateStatus();
        void pollContestState();
    }

    function getContestPollMs() {
        const contest = state.contest || {};
        const mode = String(contest.mode || '');
        if (mode === 'lobby' && isMpParticipant(contest)) {
            return 500;
        }
        if (mode === 'contest') {
            return 500;
        }
        if (contest.available && mode !== 'contest') {
            return 500;
        }
        return 1000;
    }

    function scheduleContestPoll() {
        clearInterval(state.contestPollTimer);
        state.contestPollTimer = setInterval(pollContestState, getContestPollMs());
    }

    async function pollContestState() {
        if (!state.credentials) {
            return;
        }
        try {
            const data = await apiRequest('contest.php', { method: 'GET', headers: apiHeaders() });
            if (data && data.contest) {
                syncContest(data.contest, { creditsBalance: data.credits_balance });
            } else if (data && typeof data.credits_balance === 'number') {
                const next = Number(data.credits_balance);
                if (next !== state.credits) {
                    state.credits = next;
                    if (state.terminal) state.terminal.credits_balance = next;
                    updateStatus();
                }
            }
        } catch (error) {
        }
    }

    async function heartbeat() {
        const gen = ++state.heartbeatGen;
        try {
            const data = await apiRequest('heartbeat.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({
                    credits_balance: state.credits,
                    app_version: '1.0.0',
                    game_overlay_open: isGameOpen()
                })
            });
            if (gen !== state.heartbeatGen) {
                return;
            }
            applyBalanceCapFromServer(data);
            if (data && data.contest) {
                syncContest(data.contest, { creditsBalance: data.credits_balance });
            } else if (data && typeof data.credits_balance === 'number') {
                applyIncomingCredits(Number(data.credits_balance), false);
            }
        } catch (error) {
        }
    }

    function applyIncomingCredits(next, fromLocal) {
        if (!Number.isFinite(next)) {
            return false;
        }
        if (next === state.credits) {
            return false;
        }
        if (!fromLocal && next < state.credits && (Date.now() - state.lastLocalCreditBumpAt) < 25000) {
            return false;
        }
        if (next > state.credits) {
            state.lastCreditBumpAt = Date.now();
            if (fromLocal) {
                state.lastLocalCreditBumpAt = Date.now();
            }
        }
        state.credits = next;
        if (state.terminal) {
            state.terminal.credits_balance = next;
        }
        updateStatus();
        return true;
    }

    async function pollLocalBalance() {
        if (state.skipLocalBalance) {
            return null;
        }
        const ports = state.localBridgePort ? [state.localBridgePort] : [17891];
        for (let i = 0; i < ports.length; i += 1) {
            const port = ports[i];
            const ctrl = typeof AbortController === 'function' ? new AbortController() : null;
            const timer = ctrl ? window.setTimeout(function () { ctrl.abort(); }, 120) : null;
            try {
                const res = await fetch('http://127.0.0.1:' + port + '/balance', {
                    method: 'GET',
                    cache: 'no-store',
                    mode: 'cors',
                    signal: ctrl ? ctrl.signal : undefined
                });
                if (timer) window.clearTimeout(timer);
                if (!res.ok) {
                    continue;
                }
                const data = await res.json();
                if (data && data.ok) {
                    state.localBridgePort = port;
                    state.localBalanceFails = 0;
                    return data;
                }
            } catch (error) {
                if (timer) window.clearTimeout(timer);
            }
        }
        state.localBalanceFails += 1;
        if (state.localBalanceFails >= 6) {
            state.skipLocalBalance = true;
            window.setTimeout(function () {
                state.skipLocalBalance = false;
                state.localBalanceFails = 0;
            }, 4000);
        }
        return null;
    }

    async function pollCredits() {
        if (!state.credentials || state.creditsPollBusy) {
            return;
        }
        state.creditsPollBusy = true;
        const gen = ++state.creditsPollGen;
        try {
            const local = await pollLocalBalance();
            if (gen !== state.creditsPollGen) {
                return;
            }
            if (local) {
                if (typeof local.credits_balance === 'number') {
                    applyIncomingCredits(Number(local.credits_balance), true);
                } else if (Number(local.pending_money || 0) > 0) {
                    applyIncomingCredits(state.credits + creditsForMoney(local.pending_money), true);
                }
                return;
            }
            const data = await apiRequest('credits.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({ action: 'ping' })
            });
            if (gen !== state.creditsPollGen) {
                return;
            }
            if (!data || typeof data.credits_balance !== 'number') {
                return;
            }
            applyIncomingCredits(Number(data.credits_balance), false);
            applyStackerUi(data);
        } catch (error) {
        } finally {
            state.creditsPollBusy = false;
        }
    }

    function scheduleCreditsPoll() {
        window.clearTimeout(state.creditsPollTimer);
        state.creditsPollTimer = window.setTimeout(async function () {
            await pollCredits();
            scheduleCreditsPoll();
        }, 200);
    }

    function bindConnectButton() {
        const btn = document.getElementById('terminalConnectBtn');
        if (!btn) return;

        btn.addEventListener('click', function () {
            openOperatorAuthPopup();
        });
    }

    function bindOperatorModals() {
        const authOverlay = document.getElementById('terminalOperatorOverlay');
        const reportOverlay = document.getElementById('terminalReportOverlay');
        const authCloseBtn = document.getElementById('terminalOperatorCloseBtn');
        const authForm = document.getElementById('terminalOperatorForm');
        const logoutBtn = document.getElementById('terminalReportLogoutBtn');
        const printBtn = document.getElementById('terminalReportPrintBtn');
        const stackerResetBtn = document.getElementById('terminalStackerResetBtn');
        const usernameInput = document.getElementById('operatorUsername');
        const passwordInput = document.getElementById('operatorPassword');
        const letters = document.getElementById('terminalOperatorLetters');
        const numpad = document.getElementById('terminalOperatorNumpad');

        if (authCloseBtn) {
            authCloseBtn.addEventListener('click', closeOperatorAuthPopup);
        }

        if (authOverlay) {
            authOverlay.addEventListener('click', function (event) {
                if (event.target === authOverlay) {
                    closeOperatorAuthPopup();
                }
            });
        }

        if (reportOverlay) {
            reportOverlay.addEventListener('click', function (event) {
                if (event.target === reportOverlay) {
                    closeOperatorReportPopup();
                }
            });
        }

        if (authForm) {
            authForm.addEventListener('submit', function (event) {
                event.preventDefault();
                submitOperatorLogin();
            });
        }

        if (logoutBtn) {
            logoutBtn.addEventListener('click', function () {
                operatorLogout(true);
            });
        }

        if (printBtn) {
            printBtn.addEventListener('click', function () {
                window.print();
            });
        }

        if (stackerResetBtn) {
            stackerResetBtn.addEventListener('click', function () {
                resetStackerFromOperator();
            });
        }

        if (usernameInput) {
            usernameInput.addEventListener('pointerdown', function () {
                setOperatorActiveField(usernameInput);
            });
        }

        if (passwordInput) {
            passwordInput.addEventListener('pointerdown', function () {
                setOperatorActiveField(passwordInput);
            });
        }

        if (letters) {
            letters.querySelectorAll('.terminal-numpad-btn[data-key]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const key = button.getAttribute('data-key') || '';
                    if (key === 'shift') {
                        state.operatorShift = !state.operatorShift;
                        button.setAttribute('aria-pressed', state.operatorShift ? 'true' : 'false');
                        button.classList.toggle('is-on', state.operatorShift);
                        button.textContent = state.operatorShift ? 'abc' : 'ABC';
                        return;
                    }
                    typeOperatorChar(key);
                });
            });
        }

        if (numpad) {
            numpad.querySelectorAll('.terminal-numpad-btn[data-digit]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const digit = button.getAttribute('data-digit');
                    if (digit === 'backspace') {
                        typeOperatorBackspace();
                        return;
                    }
                    typeOperatorChar(digit || '');
                });
            });
        }
    }

    function operatorActiveInput() {
        const usernameInput = document.getElementById('operatorUsername');
        const passwordInput = document.getElementById('operatorPassword');
        return state.operatorField === 'password' ? passwordInput : usernameInput;
    }

    function setOperatorActiveField(input) {
        const usernameInput = document.getElementById('operatorUsername');
        const passwordInput = document.getElementById('operatorPassword');
        state.operatorField = input === passwordInput ? 'password' : 'username';
        if (usernameInput) {
            usernameInput.classList.toggle('is-operator-target', state.operatorField === 'username');
        }
        if (passwordInput) {
            passwordInput.classList.toggle('is-operator-target', state.operatorField === 'password');
        }
        if (input) {
            input.focus();
        }
    }

    function typeOperatorChar(raw) {
        const input = operatorActiveInput();
        if (!input || raw === '') return;
        const max = input.id === 'operatorUsername' ? 80 : 64;
        if (input.value.length >= max) return;
        let next = raw;
        if (/^[a-z]$/.test(raw)) {
            next = state.operatorShift ? raw.toUpperCase() : raw.toLowerCase();
        }
        input.value += next;
        setOperatorActiveField(input);
    }

    function typeOperatorBackspace() {
        const input = operatorActiveInput();
        if (!input) return;
        input.value = input.value.slice(0, -1);
        setOperatorActiveField(input);
    }

    function setOperatorError(message) {
        const errorNode = document.getElementById('terminalOperatorError');
        if (!errorNode) return;
        if (!message) {
            errorNode.hidden = true;
            errorNode.textContent = '';
            return;
        }
        errorNode.hidden = false;
        errorNode.textContent = message;
    }

    function fillOperatorTerminalCard(terminal) {
        const payload = terminal || state.terminal || {};
        const nameNode = document.getElementById('operatorTerminalName');
        const codeNode = document.getElementById('operatorTerminalCode');
        const stationNode = document.getElementById('operatorStationName');

        if (nameNode) nameNode.textContent = payload.name || 'Terminal';
        if (codeNode) codeNode.textContent = payload.terminal_code ? ('Cod: ' + payload.terminal_code) : '';
        if (stationNode) {
            if (payload.station_name) {
                const stationCode = payload.station_code ? (' (' + payload.station_code + ')') : '';
                stationNode.textContent = 'Statie: ' + payload.station_name + stationCode;
            } else {
                stationNode.textContent = '';
            }
        }
    }

    function openOverlay(node) {
        if (!node) return;
        node.classList.add('is-open');
        node.setAttribute('aria-hidden', 'false');
    }

    function closeOverlay(node) {
        if (!node) return;
        node.classList.remove('is-open');
        node.setAttribute('aria-hidden', 'true');
    }

    async function openOperatorAuthPopup() {
        const overlay = document.getElementById('terminalOperatorOverlay');
        const usernameInput = document.getElementById('operatorUsername');
        const passwordInput = document.getElementById('operatorPassword');
        setOperatorError('');
        fillOperatorTerminalCard(state.terminal);

        try {
            const data = await apiRequest('operator.php?action=context', {
                method: 'GET',
                headers: apiHeaders()
            });

            if (data.terminal) {
                fillOperatorTerminalCard(data.terminal);
            }

            if (data.operator) {
                state.operator = data.operator;
                closeOverlay(overlay);
                await openOperatorReportPopup(data.operator, state.operatorPeriod || '1d');
                return;
            }
        } catch (error) {
            fillOperatorTerminalCard(state.terminal);
        }

        if (usernameInput) {
            usernameInput.value = '';
        }
        if (passwordInput) {
            passwordInput.value = '';
        }

        openOverlay(overlay);
        setOperatorActiveField(usernameInput);
    }

    function closeOperatorAuthPopup() {
        closeOverlay(document.getElementById('terminalOperatorOverlay'));
        setOperatorError('');
    }

    function closeOperatorReportPopup() {
        closeOverlay(document.getElementById('terminalReportOverlay'));
    }

    async function submitOperatorLogin() {
        if (state.operatorBusy) return;

        const usernameInput = document.getElementById('operatorUsername');
        const passwordInput = document.getElementById('operatorPassword');
        const username = usernameInput ? String(usernameInput.value || '').trim() : '';
        const password = passwordInput ? String(passwordInput.value || '').trim() : '';

        if (username === '' || password === '') {
            setOperatorError('Introdu utilizatorul și parola.');
            if (username === '') {
                setOperatorActiveField(usernameInput);
            } else {
                setOperatorActiveField(passwordInput);
            }
            return;
        }

        state.operatorBusy = true;
        setOperatorError('');

        try {
            const data = await apiRequest('operator.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({
                    action: 'login',
                    username: username,
                    password: password
                })
            });

            state.operator = data.operator || null;
            closeOperatorAuthPopup();
        } catch (error) {
            setOperatorError(error.message || 'Autentificare esuata.');
            return;
        } finally {
            state.operatorBusy = false;
        }

        if (state.operator) {
            await openOperatorReportPopup(state.operator, state.operatorPeriod || '1d');
        }
    }

    async function operatorLogout(showAuthAfter) {
        try {
            await apiRequest('operator.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({ action: 'logout' })
            });
        } catch (error) {
        }

        state.operator = null;
        closeOperatorReportPopup();

        if (showAuthAfter) {
            await openOperatorAuthPopup();
        }
    }

    function renderOperatorPeriodButtons(periods, activePeriod) {
        const wrap = document.getElementById('terminalReportPeriods');
        if (!wrap) return;

        wrap.innerHTML = '';
        (periods || []).forEach(function (item) {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'terminal-report-period-btn' + (item.key === activePeriod ? ' is-active' : '');
            button.textContent = item.label;
            button.addEventListener('click', function () {
                loadOperatorReport(item.key);
            });
            wrap.appendChild(button);
        });
    }

    function renderOperatorReport(report, operator, terminal) {
        const metaNode = document.getElementById('terminalReportMeta');
        const host = document.getElementById('terminalReportRegister');

        const operatorName = operator ? (operator.display_name || operator.username || '-') : '-';
        const operatorRole = operator ? (operator.role_label || operator.role || '-') : '-';
        const terminalName = terminal ? (terminal.name || 'Terminal') : 'Terminal';
        const terminalCode = terminal && terminal.terminal_code ? (' · ' + terminal.terminal_code) : '';
        const stationName = terminal && terminal.station_name ? (' · ' + terminal.station_name) : '';
        const stacker = terminal
            ? (' · Receptor: ' + String(terminal.stacker_bills || 0) + '/' + String(terminal.stacker_capacity || 1000))
            : '';

        if (metaNode) {
            metaNode.textContent = operatorName + ' (' + operatorRole + ') · ' + terminalName + terminalCode + stationName + ' · Perioada: ' + ((report && report.period_label) || '-') + stacker;
        }

        if (!host) return;

        if (!report) {
            host.innerHTML = '<section class="terminal-reg-sheet"><p class="terminal-reg-empty">Se încarcă registrul...</p></section>';
            return;
        }

        const company = report.company || {};
        const fromLabel = report.range_from || '-';
        const toLabel = report.range_to || '-';
        const printed = report.printed_at || '';
        const sheets = report.register && report.register.length ? report.register : [{
            day_label: fromLabel,
            items: [],
            total_in: '0,00',
            total_out: '0,00',
            sold_final: '0,00'
        }];

        host.innerHTML = sheets.map(function (sheet) {
            const rows = (sheet.items || []).map(function (item) {
                return '<tr>' +
                    '<td class="terminal-reg-nr">' + escapeHtml(String(item.nr || '')) + '</td>' +
                    '<td>' + escapeHtml(item.time || '') + '</td>' +
                    '<td>' + escapeHtml(item.terminal || '') + '</td>' +
                    '<td>' + escapeHtml(item.in_text || '') + '</td>' +
                    '<td class="terminal-reg-num">' + escapeHtml(item.in_sum || '') + '</td>' +
                    '<td>' + escapeHtml(item.out_text || '') + '</td>' +
                    '<td class="terminal-reg-num">' + escapeHtml(item.out_sum || '') + '</td>' +
                    '<td class="terminal-reg-num">' + escapeHtml(item.sold || '') + '</td>' +
                '</tr>';
            }).join('');

            return '<section class="terminal-reg-sheet">' +
                '<div class="terminal-reg-head">' +
                    '<div class="terminal-reg-meta">' +
                        '<div><b>Unitatea:</b> ' + escapeHtml(company.unitate || '-') + '</div>' +
                        '<div><b>CUI:</b> ' + escapeHtml(company.cui || '-') + '</div>' +
                        '<div><b>J:</b> ' + escapeHtml(company.nr_j || '-') + '</div>' +
                        '<div><b>Sediul:</b> ' + escapeHtml(company.sediu || '-') + '</div>' +
                        '<div><b>Locația (shop):</b> ' + escapeHtml(company.location || '-') + '</div>' +
                    '</div>' +
                    '<div class="terminal-reg-brand">' +
                        '<small>IQWIN</small>' +
                        '<h3>SITUAȚIA FINANCIARĂ</h3>' +
                        '<p>TERMINAL CONECTAT</p>' +
                        '<p>Data: ' + escapeHtml(sheet.day_label || '-') + '</p>' +
                    '</div>' +
                    '<div class="terminal-reg-side">' +
                        '<strong>De la: ' + escapeHtml(fromLabel) + '</strong>' +
                        '<strong>Până la: ' + escapeHtml(toLabel) + '</strong>' +
                        '<span>Toate sumele sunt în lei</span>' +
                    '</div>' +
                '</div>' +
                '<table class="terminal-reg-table">' +
                    '<thead>' +
                        '<tr>' +
                            '<th rowspan="2">Nr. crt.</th>' +
                            '<th rowspan="2">Ora</th>' +
                            '<th rowspan="2">Terminal</th>' +
                            '<th colspan="2">ÎNCASĂRI</th>' +
                            '<th colspan="2">PLĂȚI</th>' +
                            '<th rowspan="2">SOLD ZILNIC<br>Suma (lei)</th>' +
                        '</tr>' +
                        '<tr>' +
                            '<th>De la cine / Explicație</th>' +
                            '<th>Sumă încasată (lei)</th>' +
                            '<th>Către cine / Explicație</th>' +
                            '<th>Sumă plătită (lei)</th>' +
                        '</tr>' +
                    '</thead>' +
                    '<tbody>' +
                        (rows || '<tr><td class="terminal-reg-empty" colspan="8">Nu există alimentări sau restituiri în această zi.</td></tr>') +
                    '</tbody>' +
                '</table>' +
                '<table class="terminal-reg-tot">' +
                    '<tr><td>TOTAL ÎNCASĂRI / ZI</td><td>' + escapeHtml(sheet.total_in || '0,00') + '</td></tr>' +
                    '<tr><td>TOTAL PLĂȚI / ZI</td><td>' + escapeHtml(sheet.total_out || '0,00') + '</td></tr>' +
                    '<tr><td>SOLD INIȚIAL (la începutul zilei)</td><td>' + escapeHtml(sheet.sold_initial || '0,00') + '</td></tr>' +
                    '<tr><td>SOLD FINAL (la sfârșitul zilei)</td><td>' + escapeHtml(sheet.sold_final || '0,00') + '</td></tr>' +
                '</table>' +
                '<div class="terminal-reg-sign">' +
                    '<div>Întocmit de: ' + escapeHtml(operatorName) + ' ______________</div>' +
                    '<div>Verificat de: ______________ (nume și semnătură)</div>' +
                '</div>' +
                '<div class="terminal-reg-stamp">Tipărit la: ' + escapeHtml(printed) + '</div>' +
            '</section>';
        }).join('');
    }

    async function loadOperatorReport(periodKey) {
        if (state.reportLoading) return;
        state.reportLoading = true;
        state.operatorPeriod = periodKey || '1d';

        try {
            const data = await apiRequest('operator.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({
                    action: 'report',
                    period: state.operatorPeriod
                })
            });

            state.operator = data.operator || state.operator;
            if (data.terminal) {
                state.terminal = data.terminal;
            }
            renderOperatorPeriodButtons(data.periods || [], (data.report && data.report.period) || state.operatorPeriod);
            renderOperatorReport(data.report, state.operator, data.terminal || state.terminal);
        } catch (error) {
            if (String(error.message || '').toLowerCase().indexOf('sesiune') >= 0) {
                state.operator = null;
                closeOperatorReportPopup();
                openOperatorAuthPopup();
                return;
            }
            alert(error.message || 'Nu s-a putut incarca raportul.');
        } finally {
            state.reportLoading = false;
        }
    }

    async function openOperatorReportPopup(operator, periodKey) {
        const overlay = document.getElementById('terminalReportOverlay');
        openOverlay(overlay);
        renderOperatorPeriodButtons([], periodKey || '1d');
        renderOperatorReport(null, operator, state.terminal);
        await loadOperatorReport(periodKey || '1d');
    }

    function bindHomeButton() {
        const btn = document.getElementById('terminalHomeBtn');
        if (!btn) return;

        btn.addEventListener('click', function () {
            if (isGameOpen()) {
                closeGame();
                return;
            }
            const grid = document.getElementById('gamesGrid');
            if (grid) {
                grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    }

    function bindSoundButton() {
        const btn = document.getElementById('terminalSoundBtn');
        if (!btn) return;

        let muted = sessionStorage.getItem('terminalMuted') === '1';

        function applySoundState() {
            btn.classList.toggle('is-muted', muted);
            btn.setAttribute('aria-label', muted ? 'Sunet oprit' : 'Sunet pornit');
            const onIcon = btn.querySelector('.terminal-extra-menu-icon-sound-on');
            const offIcon = btn.querySelector('.terminal-extra-menu-icon-sound-off');
            if (onIcon) onIcon.hidden = muted;
            if (offIcon) offIcon.hidden = !muted;
        }

        btn.addEventListener('click', function () {
            muted = !muted;
            sessionStorage.setItem('terminalMuted', muted ? '1' : '0');
            applySoundState();
        });

        applySoundState();
    }

    function isSoundMuted() {
        return sessionStorage.getItem('terminalMuted') === '1';
    }

    function startTimers() {
        clearInterval(state.bootstrapTimer);
        clearInterval(state.heartbeatTimer);
        window.clearTimeout(state.creditsPollTimer);
        clearInterval(state.contestPollTimer);
        clearInterval(state.clockTimer);
        state.bootstrapTimer = setInterval(bootstrap, state.refreshSeconds * 1000);
        state.heartbeatTimer = setInterval(heartbeat, 800);
        scheduleCreditsPoll();
        scheduleContestPoll();
        updateTerminalClock();
        state.clockTimer = setInterval(updateTerminalClock, 1000);
    }

    function updateTerminalClock() {
        const timeNode = document.getElementById('terminalClockTime');
        const dateMainNode = document.getElementById('terminalClockDateMain');
        const dateSubNode = document.getElementById('terminalClockDateSub');
        if (!timeNode || !dateMainNode || !dateSubNode) return;

        const now = new Date();
        timeNode.textContent = now.toLocaleTimeString('ro-RO', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });

        const weekday = now.toLocaleDateString('ro-RO', { weekday: 'short' }).replace(/\./g, '').toUpperCase();
        dateMainNode.textContent = now.toLocaleDateString('ro-RO', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        }).replace(/\./g, '').toUpperCase();
        dateSubNode.textContent = weekday + ', ' + now.getFullYear();
    }

    async function openGame(game) {
        if (state.gameLaunching) return;
        if (isMpLobbyWaiting()) {
            return;
        }
        if (isBalanceOverCap()) {
            openForcedWithdrawModal();
            return;
        }
        state.gameLaunching = true;

        const overlay = document.getElementById('gameOverlay');
        const frame = document.getElementById('gameFrame');
        const title = document.getElementById('overlayTitle');

        showGameLaunchLoader(game);
        playLaunchSound();

        try {
            const [session] = await Promise.all([
                apiRequest('session.php', {
                    method: 'POST',
                    headers: apiHeaders(),
                    body: JSON.stringify({
                        action: 'start',
                        game_id: game.id
                    })
                }),
                waitForLaunchDuration()
            ]);

            state.currentSessionId = session.session_id;
            state.currentGameId = game.id;
            state.credits = session.credits_balance;

            if (title) title.textContent = game.title;
            if (frame) {
                const join = game.game_url.indexOf('?') >= 0 ? '&' : '?';
                frame.src = game.game_url + join + 'game_id=' + encodeURIComponent(game.id) + '&session_id=' + encodeURIComponent(session.session_id);
                frame.onload = function () {
                    frame.onload = null;
                    syncCreditsToOpenGame();
                    // Retry: jocul poate incarca listener-ul dupa onload.
                    window.setTimeout(syncCreditsToOpenGame, 120);
                    window.setTimeout(syncCreditsToOpenGame, 400);
                    window.setTimeout(syncCreditsToOpenGame, 900);
                    syncContestToGame(state.contest);
                    if (window.TerminalDisplaySync && window.TerminalDisplaySync.requestGameInfo) {
                        window.TerminalDisplaySync.requestGameInfo(frame);
                    }
                };
            }

            hideGameLaunchLoader();
            if (overlay) overlay.classList.add('active');
            closeModal('creditInModal');
            closeModal('creditOutModal');
            document.body.classList.add('game-open');
            if (window.TerminalDisplaySync) {
                window.TerminalDisplaySync.broadcastGame(game);
                window.TerminalDisplaySync.requestGameInfo(frame);
                if (state.contestEnabled) {
                    window.TerminalDisplaySync.broadcastContest(state.contest || { enabled: true });
                }
            }
            updateStatus();
        } catch (error) {
            hideGameLaunchLoader();
            window.alert(error.message || 'Nu s-a putut deschide jocul.');
        } finally {
            state.gameLaunching = false;
        }
    }

    async function closeGame() {
        const overlay = document.getElementById('gameOverlay');
        const frame = document.getElementById('gameFrame');
        const sessionId = state.currentSessionId;
        const gameId = state.currentGameId;

        state.currentSessionId = null;
        state.currentGameId = null;

        if (overlay) overlay.classList.remove('active');
        if (frame) frame.src = 'about:blank';
        document.body.classList.remove('game-open');
        // Lobby pe top-display imediat (nu astepta sfarsitul request-ului de close).
        if (window.TerminalDisplaySync) {
            window.TerminalDisplaySync.broadcastLobby();
        }
        updateCreditButtonStates();

        try {
            await apiRequest('session.php', {
                method: 'POST',
                headers: apiHeaders(),
                body: JSON.stringify({
                    action: 'close',
                    session_id: sessionId || 0,
                    game_id: gameId || 0
                })
            });
        } catch (error) {
        }

        if (window.TerminalDisplaySync) {
            window.TerminalDisplaySync.broadcastLobby();
        }
    }

    async function init() {
        state.credentials = loadCredentials();
        if (!state.credentials) {
            window.location.href = 'setup.php';
            return;
        }

        const closeBtn = document.getElementById('closeGameBtn');
        if (closeBtn) closeBtn.addEventListener('click', closeGame);

        initMpWinMemory();
        bindConnectButton();
        bindMultiplayerButton();
        bindOperatorModals();
        bindHomeButton();
        bindSoundButton();
        bindCreditControls();

        document.addEventListener('selectstart', function (event) {
            const tag = event.target && event.target.tagName;
            if (tag === 'INPUT' || tag === 'TEXTAREA') return;
            event.preventDefault();
        });
        document.addEventListener('dragstart', function (event) {
            event.preventDefault();
        });
        document.addEventListener('contextmenu', function (event) {
            event.preventDefault();
        });

        window.addEventListener('message', function (event) {
            if (!event.data) return;
            if (event.data.type === 'skill-game-close') {
                closeGame();
                return;
            }
            if (event.data.type === 'skill-game-cash-out') {
                if (isBalanceOverCap()) {
                    openForcedWithdrawModal();
                } else {
                    openCreditOutModal();
                }
                return;
            }
            if (event.data.type === 'iqwin-contest-poll-now') {
                pollContestState();
                scheduleContestPoll();
                return;
            }
            if (event.data.type === 'skill-game-credits' && typeof event.data.credits === 'number') {
                state.credits = event.data.credits;
                updateStatus();
            }
            if (event.data.type === 'iqwin-game-multiplayer-request') {
                startMultiplayerContest();
                return;
            }
            if (event.data.type === 'iqwin-winner-balance-refresh' && event.data.contest_id) {
                scheduleWinnerBalanceRefresh(Number(event.data.contest_id));
                return;
            }
            if (event.data.type === 'iqwin-mp-win' && event.data.win) {
                if (typeof event.data.credits_balance === 'number') {
                    state.credits = Number(event.data.credits_balance);
                    if (state.terminal) state.terminal.credits_balance = state.credits;
                }
                handleShopMultiplayerWin(
                    { recent_win: event.data.win },
                    { playSound: event.data.play_sound !== false, showOthers: false }
                );
                updateStatus();
            }
            if ((event.data.type === 'info-html' || event.data.type === 'iqwin-top-display-info') && event.data.html && window.TerminalDisplaySync) {
                window.TerminalDisplaySync.forwardInfoHtml({
                    type: 'info-html',
                    slug: event.data.slug || '',
                    title: event.data.title || '',
                    html: event.data.html
                });
            }
        });

        if (window.TerminalDisplaySync) {
            let skipAutoTopDisplay = false;
            try {
                skipAutoTopDisplay = sessionStorage.getItem('iqwin_ext_top') === '1'
                    || new URLSearchParams(window.location.search).has('dualLauncher');
            } catch (e) {}
            if (!skipAutoTopDisplay) {
                window.TerminalDisplaySync.initTopDisplayLauncher();
            }
            window.TerminalDisplaySync.broadcastLobby();
        }

        startTimers();
        window.addEventListener('storage', function (event) {
            if (event.key !== MP_POLL_BUMP_KEY || !event.newValue) {
                return;
            }
            const rev = String(event.newValue).split(':')[0] || '';
            if (rev && rev !== state.lastContestRevision) {
                void pollContestState();
            }
        });
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) {
                void pollContestState();
            }
        });
        try {
            await bootstrap();
            await heartbeat();
            await pollContestState();
        } catch (error) {
            const msg = (error && error.message) ? String(error.message) : 'Eroare conexiune';
            const terminalEl = document.getElementById('terminalName');
            if (terminalEl) {
                terminalEl.textContent = msg.length > 42 ? 'Eroare conexiune' : msg;
                terminalEl.title = msg;
            }
            const statusDot = document.getElementById('statusDot');
            if (statusDot) {
                statusDot.className = 'status-dot offline';
            }
            try {
                renderGames();
            } catch (e) {}
            console.error(error);
        }

        if (new URLSearchParams(window.location.search).has('dualLauncher')) {
            window.setTimeout(() => {
                const root = document.documentElement;
                if (root.requestFullscreen && !document.fullscreenElement) {
                    root.requestFullscreen().catch(() => {});
                }
            }, 400);
        }
    }

    document.addEventListener('DOMContentLoaded', init);
})();
