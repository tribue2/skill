(function (global) {
    'use strict';

    function getCredentials() {
        const storage = localStorage.getItem('skill_terminal_credentials');
        const server = localStorage.getItem('skill_terminal_server');
        if (!storage || !server) {
            return null;
        }
        try {
            return {
                credentials: JSON.parse(storage),
                base: server.replace(/\/$/, '') + '/api/terminal'
            };
        } catch (error) {
            return null;
        }
    }

    function applyStart(state, data) {
        if (!state || !data) {
            return;
        }
        const startStops = Array.isArray(data.start_stops) ? data.start_stops.slice(0, 5) : [0, 0, 0, 0, 0];
        while (startStops.length < 5) {
            startStops.push(0);
        }
        state.roundStartStops = startStops.map((value) => Math.max(0, Number(value) || 0));
        state.reelScrollMult = Number(data.reel_scroll_mult || 1) || 1;
        state.autoStopMs = Number(data.auto_stop_ms || 5000) || 5000;
        state.spinT0Ms = Number(data.spin_t0_ms || 0) || 0;
        state.spinLocalT0 = performance.now();
        state.serverStops = Array.isArray(data.stops) ? data.stops.slice() : [null, null, null, null, null];
        if (Array.isArray(data.speeds) && data.speeds.length) {
            state.serverSpeeds = data.speeds.map((value) => Number(value) || 0);
        }
    }

    function localStopIndex(state, reelIndex, source, stripLength) {
        const speedApi = global.IqwinTerminalReelSpeed;
        const start = Number(state.roundStartStops?.[reelIndex] || 0);
        const elapsed = source === 'auto'
            ? Number(state.autoStopMs || 5000)
            : Math.max(0, performance.now() - Number(state.spinLocalT0 || performance.now()));
        const speed = state.serverSpeeds?.[reelIndex]
            || (speedApi ? speedApi.getReelSpinScrollSpeed(reelIndex, state.reelScrollMult || 1) : 1.5);
        return speedApi
            ? speedApi.resolveStopIndex(start, elapsed, speed, stripLength)
            : start;
    }

    async function takeStops(state, reelIndexes, source, stripLengthFor) {
        const reels = (reelIndexes || []).map((value) => Number(value)).filter((value) => value >= 0 && value <= 4);
        const resolved = {};
        const auth = getCredentials();
        if (auth && state.sessionId) {
            try {
                const response = await fetch(`${auth.base}/session.php`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Terminal-Code': auth.credentials.terminal_code,
                        'X-Terminal-Secret': auth.credentials.api_secret
                    },
                    body: JSON.stringify({
                        action: 'reel_stop',
                        game_id: state.gameId,
                        session_id: state.sessionId,
                        reels,
                        source: source || 'player'
                    })
                });
                const data = await response.json();
                if (data?.ok && Array.isArray(data.stops)) {
                    state.serverStops = data.stops.slice();
                    reels.forEach((reelIndex) => {
                        if (data.stops[reelIndex] !== null && data.stops[reelIndex] !== undefined) {
                            resolved[reelIndex] = Number(data.stops[reelIndex]);
                        }
                    });
                    if (typeof data.skill_stop_used === 'boolean') {
                        state.serverSkillStopUsed = data.skill_stop_used;
                    }
                }
            } catch (error) {
                /* fallback local physics */
            }
        }
        reels.forEach((reelIndex) => {
            if (resolved[reelIndex] === undefined) {
                const length = typeof stripLengthFor === 'function' ? stripLengthFor(reelIndex) : 1;
                resolved[reelIndex] = localStopIndex(state, reelIndex, source, length);
            }
        });
        return resolved;
    }

    global.IqwinSkillSpin = {
        applyStart,
        takeStops,
        localStopIndex
    };
})(window);
