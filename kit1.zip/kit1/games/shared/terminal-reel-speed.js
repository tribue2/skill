(() => {
    const REEL_SCROLL_SPEED = 0.13125;
    const REEL_SPEED_BASE = 11.5;
    const REEL_SPEED_STEP = 1.15;
    const STOP_TIMEOUT_MS = 5000;
    const SPEED_PROFILES = {
        normal: { reelScrollMult: 1, playStopDelayMs: 480 },
        rapid: { reelScrollMult: 1.5, playStopDelayMs: 300 },
        turbo: { reelScrollMult: 2.15, playStopDelayMs: 180 }
    };

    function getReelSpinScrollSpeed(reelIndex, reelScrollMult = 1) {
        const index = Math.max(0, Number(reelIndex) || 0);
        const mult = Number(reelScrollMult) || 1;
        return (REEL_SPEED_BASE + index * REEL_SPEED_STEP) * mult * REEL_SCROLL_SPEED;
    }

    function resolveStopIndex(startStop, elapsedMs, speed, stripLength) {
        const length = Math.max(1, Number(stripLength) || 1);
        const traveled = (Math.max(0, Number(elapsedMs) || 0) / 1000) * Number(speed || 0);
        const raw = Math.round(Number(startStop) || 0) + Math.round(traveled);
        return ((raw % length) + length) % length;
    }

    window.IqwinTerminalReelSpeed = {
        REEL_SCROLL_SPEED,
        REEL_SPEED_BASE,
        REEL_SPEED_STEP,
        STOP_TIMEOUT_MS,
        SPEED_PROFILES,
        getReelSpinScrollSpeed,
        resolveStopIndex
    };
})();
