'use strict';

const { runPairUi } = require('./pair-ui');

async function main() {
  console.log('');
  console.log('========================================');
  console.log('  IQWIN Agent - Pairing');
  console.log('========================================');
  console.log('');

  const cfg = await runPairUi({
    serverUrl: 'https://iqwin.ro'
  });

  if (!cfg || !cfg.terminal_code) {
    throw new Error('Pairing anulat sau incomplet.');
  }

  console.log('Config salvat.');
  console.log('');
  process.exit(0);
}

main().catch((error) => {
  console.error('');
  console.error('EROARE: ' + (error.message || error));
  console.error('');
  process.exit(1);
});
