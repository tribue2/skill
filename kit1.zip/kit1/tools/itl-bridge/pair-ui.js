'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = __dirname;
const CONFIG_PATH = path.join(ROOT, 'config.json');
const PAIR_IN = path.join(ROOT, '.pair-ui-in.json');
const PAIR_OUT = path.join(ROOT, '.pair-ui-out.json');
const PAIR_PS1 = path.join(ROOT, '.pair-ui-dialog.ps1');

const DEFAULT_CHANNELS = {
  '1': 1,
  '2': 5,
  '3': 10,
  '4': 50,
  '5': 100,
  '6': 200,
  '7': 500
};

function loadExisting() {
  if (!fs.existsSync(CONFIG_PATH)) return null;
  try {
    return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  } catch (error) {
    return null;
  }
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2), 'utf8');
}

function ensureStartupShortcut() {
  const startupDir = path.join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
  if (!process.env.APPDATA) return false;
  if (!fs.existsSync(startupDir)) {
    fs.mkdirSync(startupDir, { recursive: true });
  }
  const vbsPath = path.join(startupDir, 'IQWIN-Agent.vbs');
  const startBat = path.join(ROOT, 'start-kit.bat');
  const content = [
    'Set WshShell = CreateObject("WScript.Shell")',
    'WshShell.Run "cmd /c ""' + startBat.replace(/"/g, '') + '""", 0, False'
  ].join('\r\n');
  fs.writeFileSync(vbsPath, content, 'utf8');
  return true;
}

function cleanupPairTemp() {
  try { fs.unlinkSync(PAIR_IN); } catch (e) {}
  try { fs.unlinkSync(PAIR_OUT); } catch (e) {}
  try { fs.unlinkSync(PAIR_PS1); } catch (e) {}
}

function usbComScore(p) {
  const blob = String((p && p.label) || (p && p.path) || '').toLowerCase();
  if (/innovative|itl|nv9|nv10|nv11|nv200|smart.?payout|bank.?note/.test(blob)) return 100;
  if (/ftdi|prolific|wch|ch340|silicon.?labs|cp210|usb.?serial|usb.?to.?serial/.test(blob)) return 60;
  const n = Number(String((p && p.path) || '').replace(/^COM/i, '')) || 0;
  if (n === 1) return 0;
  if (n > 1) return 20;
  return 0;
}

function pickSuggestedCom(detectedPorts) {
  const ranked = (detectedPorts || []).slice().sort((a, b) => usbComScore(b) - usbComScore(a));
  if (!ranked.length || usbComScore(ranked[0]) <= 0) {
    return '';
  }
  return String(ranked[0].path || '').toUpperCase();
}

async function listComPorts() {
  try {
    const ports = await require('./serial-util').listSerialPorts();
    return (ports || []).map((p) => {
      const bits = [p.path, p.manufacturer, p.friendlyName || p.productId]
        .filter(Boolean)
        .map((x) => String(x).replace(/[^\x20-\x7E]/g, ' ').trim())
        .filter(Boolean);
      return {
        path: String(p.path || '').toUpperCase(),
        label: bits.join(' - ')
      };
    }).filter((p) => p.path);
  } catch (error) {
    return [];
  }
}

function buildComChoices(detectedPorts, suggestedCom) {
  const map = new Map();
  (detectedPorts || []).forEach((p) => {
    if (!p || !p.path) return;
    map.set(p.path.toUpperCase(), {
      path: p.path.toUpperCase(),
      label: p.label || p.path
    });
  });

  for (let i = 1; i <= 40; i += 1) {
    const name = 'COM' + i;
    if (!map.has(name)) {
      map.set(name, { path: name, label: name });
    }
  }

  const list = Array.from(map.values());
  list.sort((a, b) => {
    const na = Number(String(a.path).replace(/^COM/i, '')) || 0;
    const nb = Number(String(b.path).replace(/^COM/i, '')) || 0;
    return na - nb;
  });

  const suggested = String(suggestedCom || '').toUpperCase();
  if (suggested && !map.has(suggested)) {
    list.unshift({ path: suggested, label: suggested + ' (salvat)' });
  }

  return list;
}

async function autoDetectAcceptor(timeoutMs) {
  const limit = Math.max(2000, Number(timeoutMs) || 25000);
  const signal = { cancelled: false };
  try {
    const work = (async () => {
      const { detectAcceptors } = require('./detect-acceptors');
      const report = await detectAcceptors({ signal: signal });
      if (signal.cancelled) {
        return { ok: false, timed_out: true };
      }
      if (report && report.best) {
        return {
          ok: true,
          com_port: String(report.best.com_port || '').toUpperCase(),
          device_type: report.best.device_type === 'uba' ? 'uba' : 'itl',
          confidence: Number(report.best.confidence || 0),
          uba_parity: report.best.serial && report.best.serial.parity
            ? report.best.serial.parity
            : 'even',
          detail: report.best.detail || report.summary || ''
        };
      }
      return { ok: false };
    })();

    const timed = await Promise.race([
      work,
      new Promise((resolve) => setTimeout(() => {
        signal.cancelled = true;
        resolve({ ok: false, timed_out: true });
      }, limit))
    ]);
    return timed || { ok: false };
  } catch (error) {
    signal.cancelled = true;
    return { ok: false };
  }
}

function writeDialogScript() {
  const script = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms | Out-Null
Add-Type -AssemblyName System.Drawing | Out-Null

$inPath = $env:IQWIN_PAIR_IN
$outPath = $env:IQWIN_PAIR_OUT
if (-not $inPath -or -not (Test-Path -LiteralPath $inPath)) { throw 'Lipsa fisier input UI' }
$payload = Get-Content -LiteralPath $inPath -Raw -Encoding UTF8 | ConvertFrom-Json

$form = New-Object System.Windows.Forms.Form
$form.Text = 'IQWIN Agent - Instalare'
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.TopMost = $true
$form.ShowInTaskbar = $true
$form.ClientSize = New-Object System.Drawing.Size(560, 420)
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'Configurare terminal + acceptor'
$title.Font = New-Object System.Drawing.Font('Segoe UI', 13, [System.Drawing.FontStyle]::Bold)
$title.Location = New-Object System.Drawing.Point(18, 14)
$title.AutoSize = $true
$form.Controls.Add($title)

$hint = New-Object System.Windows.Forms.Label
$hint.Text = [string]$payload.hint
$hint.Location = New-Object System.Drawing.Point(20, 46)
$hint.Size = New-Object System.Drawing.Size(520, 48)
$hint.ForeColor = [System.Drawing.Color]::FromArgb(70,70,70)
$form.Controls.Add($hint)

$lblCode = New-Object System.Windows.Forms.Label
$lblCode.Text = '1) Cod pairing din admin IQWIN'
$lblCode.Location = New-Object System.Drawing.Point(20, 100)
$lblCode.AutoSize = $true
$form.Controls.Add($lblCode)

$txtCode = New-Object System.Windows.Forms.TextBox
$txtCode.Location = New-Object System.Drawing.Point(20, 122)
$txtCode.Size = New-Object System.Drawing.Size(510, 30)
$txtCode.Font = New-Object System.Drawing.Font('Consolas', 14, [System.Drawing.FontStyle]::Bold)
$txtCode.CharacterCasing = [System.Windows.Forms.CharacterCasing]::Upper
$txtCode.Text = [string]$payload.pair_code
$form.Controls.Add($txtCode)

$lblCom = New-Object System.Windows.Forms.Label
$lblCom.Text = '2) Port COM acceptor (alege manual daca detectia a esuat)'
$lblCom.Location = New-Object System.Drawing.Point(20, 168)
$lblCom.AutoSize = $true
$form.Controls.Add($lblCom)

$cmbCom = New-Object System.Windows.Forms.ComboBox
$cmbCom.Location = New-Object System.Drawing.Point(20, 190)
$cmbCom.Size = New-Object System.Drawing.Size(510, 30)
$cmbCom.DropDownStyle = 'DropDownList'
[void]$cmbCom.Items.Add('Fara acceptor (doar jocuri)')

$ports = @()
if ($null -ne $payload.ports) { $ports = @($payload.ports) }
$selectedComIndex = 0
$i = 1
foreach ($p in $ports) {
  $path = [string]$p.path
  $label = [string]$p.label
  if (-not $label) { $label = $path }
  [void]$cmbCom.Items.Add(($path + '  |  ' + $label))
  if ($payload.suggested_com -and ($path.ToUpper() -eq ([string]$payload.suggested_com).ToUpper())) {
    $selectedComIndex = $i
  }
  $i++
}
if ($cmbCom.Items.Count -gt 0) { $cmbCom.SelectedIndex = [Math]::Min($selectedComIndex, $cmbCom.Items.Count - 1) }
$form.Controls.Add($cmbCom)

$lblModel = New-Object System.Windows.Forms.Label
$lblModel.Text = '3) Model acceptor'
$lblModel.Location = New-Object System.Drawing.Point(20, 236)
$lblModel.AutoSize = $true
$form.Controls.Add($lblModel)

$cmbModel = New-Object System.Windows.Forms.ComboBox
$cmbModel.Location = New-Object System.Drawing.Point(20, 258)
$cmbModel.Size = New-Object System.Drawing.Size(510, 30)
$cmbModel.DropDownStyle = 'DropDownList'
[void]$cmbModel.Items.Add('ITL eSSP (NV9 / NV10 / similar)')
[void]$cmbModel.Items.Add('JCM UBA (ID-003)')
$modelIndex = 0
if (([string]$payload.suggested_type).ToLower() -eq 'uba') { $modelIndex = 1 }
$cmbModel.SelectedIndex = $modelIndex
$form.Controls.Add($cmbModel)

$lblManual = New-Object System.Windows.Forms.Label
$lblManual.Text = 'sau scrie COM manual (ex: COM3) - optional'
$lblManual.Location = New-Object System.Drawing.Point(20, 300)
$lblManual.AutoSize = $true
$form.Controls.Add($lblManual)

$txtManual = New-Object System.Windows.Forms.TextBox
$txtManual.Location = New-Object System.Drawing.Point(20, 322)
$txtManual.Size = New-Object System.Drawing.Size(200, 28)
$txtManual.CharacterCasing = [System.Windows.Forms.CharacterCasing]::Upper
$form.Controls.Add($txtManual)

function Update-ModelEnabled {
  $hasManual = -not [string]::IsNullOrWhiteSpace($txtManual.Text)
  $cmbModel.Enabled = (($cmbCom.SelectedIndex -gt 0) -or $hasManual)
}
Update-ModelEnabled
$cmbCom.Add_SelectedIndexChanged({ Update-ModelEnabled })
$txtManual.Add_TextChanged({ Update-ModelEnabled })

$btnOk = New-Object System.Windows.Forms.Button
$btnOk.Text = 'Salveaza si continua'
$btnOk.Location = New-Object System.Drawing.Point(280, 360)
$btnOk.Size = New-Object System.Drawing.Size(150, 34)
$btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $btnOk
$form.Controls.Add($btnOk)

$btnCancel = New-Object System.Windows.Forms.Button
$btnCancel.Text = 'Anuleaza'
$btnCancel.Location = New-Object System.Drawing.Point(440, 360)
$btnCancel.Size = New-Object System.Drawing.Size(90, 34)
$btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $btnCancel
$form.Controls.Add($btnCancel)

[void]$form.Add_Shown({ $form.Activate(); $txtCode.Focus() })
$result = $form.ShowDialog()

if ($result -ne [System.Windows.Forms.DialogResult]::OK) {
  @{ ok = $false; cancelled = $true } | ConvertTo-Json -Compress | Set-Content -LiteralPath $outPath -Encoding UTF8
  exit 1
}

$code = ($txtCode.Text).Trim().ToUpperInvariant()
$manual = ($txtManual.Text).Trim().ToUpperInvariant() -replace '\\s',''
$acceptorEnabled = $false
$comPort = ''
$deviceType = 'itl'

if ($manual -match '^COM\\d{1,3}$') {
  $acceptorEnabled = $true
  $comPort = $manual
} elseif ($cmbCom.SelectedIndex -gt 0) {
  $acceptorEnabled = $true
  $idx = $cmbCom.SelectedIndex - 1
  if ($ports.Count -gt $idx) {
    $comPort = [string]$ports[$idx].path
  }
}

if ($cmbModel.SelectedIndex -eq 1) { $deviceType = 'uba' } else { $deviceType = 'itl' }
if (-not $acceptorEnabled) { $deviceType = 'itl' }

@{
  ok = $true
  cancelled = $false
  pair_code = $code
  acceptor_enabled = $acceptorEnabled
  com_port = $comPort
  device_type = $deviceType
} | ConvertTo-Json -Compress | Set-Content -LiteralPath $outPath -Encoding UTF8
exit 0
`.replace(/^\n/, '');

  fs.writeFileSync(PAIR_PS1, script, 'utf8');
}

function askConsoleFallback(payload) {
  const readline = require('readline');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const ask = (q) => new Promise((resolve) => rl.question(q, (ans) => resolve(String(ans || '').trim())));

  return (async () => {
    console.log('');
    console.log('Fereastra grafica nu a putut porni. Continuam in consola.');
    console.log(payload.hint || '');
    const pairCode = (await ask('Cod pairing: ')).toUpperCase();
    console.log('Porturi disponibile:');
    (payload.ports || []).slice(0, 20).forEach((p) => console.log('  - ' + p.path));
    const com = (await ask('COM (ex COM3) sau Enter pentru fara acceptor: ')).toUpperCase().replace(/\s/g, '');
    let deviceType = 'itl';
    let acceptorEnabled = false;
    let comPort = '';
    if (/^COM\d{1,3}$/.test(com)) {
      acceptorEnabled = true;
      comPort = com;
      const model = (await ask('Model [1=ITL eSSP, 2=JCM UBA] (default 1): ')).trim();
      deviceType = model === '2' ? 'uba' : 'itl';
    }
    rl.close();
    return {
      pair_code: pairCode,
      acceptor_enabled: acceptorEnabled,
      com_port: comPort,
      device_type: deviceType
    };
  })();
}

async function askInstallGui(payload) {
  cleanupPairTemp();
  fs.writeFileSync(PAIR_IN, JSON.stringify(payload || {}, null, 0), 'utf8');
  writeDialogScript();

  const result = spawnSync(
    'powershell.exe',
    [
      '-NoProfile',
      '-ExecutionPolicy',
      'Bypass',
      '-STA',
      '-File',
      PAIR_PS1
    ],
    {
      encoding: 'utf8',
      windowsHide: false,
      env: Object.assign({}, process.env, {
        IQWIN_PAIR_IN: PAIR_IN,
        IQWIN_PAIR_OUT: PAIR_OUT
      })
    }
  );

  let data = null;
  try {
    if (fs.existsSync(PAIR_OUT)) {
      const raw = fs.readFileSync(PAIR_OUT, 'utf8').replace(/^\uFEFF/, '');
      data = JSON.parse(raw);
    }
  } catch (error) {
    data = null;
  }

  const stderr = String(result.stderr || '').trim();
  const stdout = String(result.stdout || '').trim();
  cleanupPairTemp();

  if (data && data.ok) {
    return {
      pair_code: String(data.pair_code || '').trim().toUpperCase(),
      acceptor_enabled: !!data.acceptor_enabled,
      com_port: String(data.com_port || '').trim().toUpperCase(),
      device_type: String(data.device_type || 'itl').toLowerCase() === 'uba' ? 'uba' : 'itl'
    };
  }

  if (data && data.cancelled) {
    throw new Error('Instalare anulata.');
  }

  console.error('UI grafic indisponibil.');
  if (stderr) console.error(stderr.split(/\r?\n/).slice(0, 4).join(' | '));
  if (stdout) console.error(stdout.split(/\r?\n/).slice(0, 4).join(' | '));
  if (result.error) console.error(String(result.error.message || result.error));
  return askConsoleFallback(payload);
}

async function pairTerminal(serverUrl, pairCode) {
  const url = serverUrl.replace(/\/$/, '') + '/api/terminal/pair.php';
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ pair_code: String(pairCode || '').trim().toUpperCase() })
  });
  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch (error) {
    throw new Error('Serverul nu a raspuns corect la pairing.');
  }
  if (!response.ok || !data || !data.ok || !data.terminal) {
    throw new Error((data && data.message) || ('Pairing esuat HTTP ' + response.status));
  }
  return data.terminal;
}

async function runPairUi(options) {
  const opts = options || {};
  const existing = loadExisting();
  const serverUrl = String(opts.serverUrl || (existing && existing.server_url) || 'https://iqwin.ro').replace(/\/$/, '');

  console.log('Caut porturi COM...');
  const detectedPorts = await listComPorts();
  console.log(detectedPorts.length
    ? ('Porturi USB/Serial vazute: ' + detectedPorts.map((p) => p.path).join(', '))
    : 'Niciun port listat de Windows (poti alege COM manual).');

  console.log('Incerc detectie automata (max 25s)...');
  const detected = await autoDetectAcceptor(25000);
  if (detected.ok) {
    console.log('Detectat: ' + detected.device_type + ' pe ' + detected.com_port);
  } else if (detected.timed_out) {
    console.log('Detectie automata: timeout - selecteaza manual in fereastra.');
  } else {
    console.log('Detectie automata: nereusita - selecteaza manual in fereastra.');
  }

  let suggestedCom = detected.ok ? detected.com_port : '';
  let suggestedType = 'itl';
  if (detected.ok && detected.device_type === 'uba' && Number(detected.confidence || 0) >= 90) {
    suggestedType = 'uba';
  }
  if (!suggestedCom && existing && existing.com_port) {
    suggestedCom = String(existing.com_port).toUpperCase();
  }
  if (!suggestedCom) {
    suggestedCom = pickSuggestedCom(detectedPorts);
  }

  const ports = buildComChoices(detectedPorts, suggestedCom);

  const hint = detected.ok
    ? ('Detectat: ' + String(detected.device_type).toUpperCase() + ' pe ' + detected.com_port + '. Confirma sau schimba.')
    : 'Selecteaza COM + model (ITL sau JCM UBA). Daca nu e in lista, scrie manual ex: COM3.';

  console.log('Deschid fereastra: cod pairing + COM + model...');
  const choice = await askInstallGui({
    hint,
    pair_code: '',
    ports,
    suggested_com: suggestedCom,
    suggested_type: suggestedType
  });

  if (!choice.pair_code) {
    throw new Error('Codul de pairing este obligatoriu.');
  }

  if (choice.acceptor_enabled && !/^COM\d{1,3}$/i.test(choice.com_port)) {
    throw new Error('Selecteaza sau scrie un port COM valid (ex: COM3).');
  }

  console.log('Se face pairing...');
  const terminal = await pairTerminal(serverUrl, choice.pair_code);
  console.log('Pairing OK: ' + (terminal.name || terminal.terminal_code));

  const cfg = {
    server_url: serverUrl,
    terminal_code: terminal.terminal_code,
    api_secret: terminal.api_secret,
    terminal_name: terminal.name || '',
    device_type: choice.acceptor_enabled ? choice.device_type : 'itl',
    com_port: choice.acceptor_enabled ? choice.com_port.toUpperCase() : '',
    acceptor_enabled: !!choice.acceptor_enabled,
    baud_rate: Number((existing && existing.baud_rate) || 9600),
    poll_ms: Number((existing && existing.poll_ms) || 200),
    local_port: Number((existing && existing.local_port) || 17891),
    fixed_key: String((existing && existing.fixed_key) || '0123456701234567'),
    simulate: false,
    channels: (existing && existing.channels) || DEFAULT_CHANNELS
  };

  if (cfg.acceptor_enabled && cfg.device_type === 'uba') {
    cfg.uba_parity = (detected.ok && detected.uba_parity) || (existing && existing.uba_parity) || 'even';
  }

  saveConfig(cfg);
  ensureStartupShortcut();

  if (cfg.acceptor_enabled) {
    console.log('Acceptor setat: ' + cfg.device_type + ' pe ' + cfg.com_port);
  } else {
    console.log('Fara acceptor - continui cu jocurile.');
  }

  return cfg;
}

module.exports = {
  runPairUi,
  pairTerminal,
  autoDetectAcceptor,
  saveConfig,
  loadExisting,
  ensureStartupShortcut,
  askInstallGui,
  listComPorts
};
