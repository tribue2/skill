<?php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/session_config.php';

function termEscape(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function termJson(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function termSetting(string $key, ?string $default = null): ?string
{
    static $cache = [];

    if ($key === '__clear__') {
        $cache = [];
        return null;
    }

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    try {
        $row = getDB()->fetchOne('SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1', [$key]);
        $cache[$key] = $row ? (string) $row['setting_value'] : $default;
        return $cache[$key];
    } catch (Exception $e) {
        return $default;
    }
}

function termSettingClearCache(): void
{
    termSetting('__clear__');
}

function termPlatformName(): string
{
    return termSetting('platform_name', 'Skill Games Terminal') ?? 'Skill Games Terminal';
}

function termTerminalMarqueePixelsPerSecond(): int
{
    $pixelsPerSecond = (int) (termSetting('terminal_marquee_pixels_per_second', '0') ?? 0);
    if ($pixelsPerSecond > 0) {
        return max(8, min(120, $pixelsPerSecond));
    }

    $legacySeconds = max(12, (int) (termSetting('terminal_marquee_speed_seconds', '48') ?? 48));

    return max(8, min(120, (int) round(1680 / $legacySeconds)));
}

function termTerminalMarqueePayload(): array
{
    $enabled = (termSetting('terminal_marquee_enabled', '1') ?? '1') === '1';
    $pixelsPerSecond = termTerminalMarqueePixelsPerSecond();

    if (!$enabled) {
        return [
            'enabled' => false,
            'pixels_per_second' => $pixelsPerSecond,
            'items' => [],
        ];
    }

    try {
        $rows = getDB()->fetchAll(
            'SELECT text FROM terminal_marquee WHERE is_active = 1 ORDER BY sort_order ASC, id ASC'
        );
    } catch (Exception $e) {
        $rows = [];
    }

    $items = [];
    if (is_array($rows)) {
        foreach ($rows as $row) {
            $text = trim((string) ($row['text'] ?? ''));
            if ($text !== '') {
                $items[] = $text;
            }
        }
    }

    return [
        'enabled' => $enabled && $items !== [],
        'pixels_per_second' => $pixelsPerSecond,
        'items' => $items,
    ];
}

function termSettingUpsert(string $key, string $value): void
{
    $existing = getDB()->fetchOne('SELECT id FROM settings WHERE setting_key = ? LIMIT 1', [$key]);
    if ($existing) {
        getDB()->update('settings', ['setting_value' => $value], 'setting_key = :setting_key', ['setting_key' => $key]);
    } else {
        getDB()->insert('settings', [
            'setting_key' => $key,
            'setting_value' => $value,
        ]);
    }
    termSettingClearCache();
}

function termTelegramConfig(): array
{
    return [
        'enabled' => (termSetting('telegram_enabled', '0') ?? '0') === '1',
        'bot_token' => trim((string) (termSetting('telegram_bot_token', '') ?? '')),
        'chat_id' => trim((string) (termSetting('telegram_chat_id', '') ?? '')),
    ];
}

function termTelegramRequest(string $token, string $method, array $payload = []): array
{
    $token = trim($token);
    if ($token === '' || !preg_match('/^\d+:[A-Za-z0-9_-]+$/', $token)) {
        return [null, 'Token bot invalid.'];
    }

    $url = 'https://api.telegram.org/bot' . $token . '/' . $method;
    $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($body === false) {
        return [null, 'Mesaj invalid.'];
    }

    $raw = null;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 15,
        ]);
        $raw = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        curl_close($ch);
        if ($raw === false || $errno) {
            return [null, $error !== '' ? $error : 'Conexiune Telegram eșuată.'];
        }
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/json\r\n",
                'content' => $body,
                'timeout' => 15,
                'ignore_errors' => true,
            ],
        ]);
        $raw = @file_get_contents($url, false, $context);
        if ($raw === false) {
            return [null, 'Conexiune Telegram eșuată.'];
        }
    }

    $data = json_decode((string) $raw, true);
    if (!is_array($data)) {
        return [null, 'Răspuns Telegram invalid.'];
    }
    if (empty($data['ok'])) {
        return [null, trim((string) ($data['description'] ?? 'Telegram a refuzat cererea.'))];
    }

    return [$data, ''];
}

function termTelegramSend(string $text, ?string $token = null, ?string $chatId = null): array
{
    $cfg = termTelegramConfig();
    $token = trim((string) ($token ?? $cfg['bot_token']));
    $chatId = trim((string) ($chatId ?? $cfg['chat_id']));
    $text = trim($text);
    if ($text === '') {
        return [false, 'Mesaj gol.'];
    }
    if ($token === '' || $chatId === '') {
        return [false, 'Completează token și chat ID.'];
    }

    [$data, $error] = termTelegramRequest($token, 'sendMessage', [
        'chat_id' => $chatId,
        'text' => $text,
        'disable_web_page_preview' => true,
    ]);
    if ($error !== '') {
        return [false, $error];
    }

    return [true, 'Mesaj trimis pe Telegram.'];
}

function termTelegramChatIdsForUsers(array $userIds): array
{
    $ids = [];
    foreach ($userIds as $userId) {
        $userId = (int) $userId;
        if ($userId > 0) {
            $ids[$userId] = $userId;
        }
    }
    if ($ids === []) {
        return [];
    }

    try {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $rows = getDB()->fetchAll(
            "SELECT telegram_chat_id
             FROM users
             WHERE id IN ($placeholders)
               AND telegram_enabled = 1
               AND telegram_chat_id IS NOT NULL
               AND telegram_chat_id <> ''",
            array_values($ids)
        );
    } catch (Throwable $e) {
        return [];
    }

    $chatIds = [];
    foreach (is_array($rows) ? $rows : [] as $row) {
        $chatId = trim((string) ($row['telegram_chat_id'] ?? ''));
        if ($chatId !== '' && preg_match('/^-?\d{5,20}$/', $chatId)) {
            $chatIds[$chatId] = $chatId;
        }
    }

    return array_values($chatIds);
}

function termTelegramNotifyAlert(string $title, string $body, array $extraUserIds = []): void
{
    $cfg = termTelegramConfig();
    if (!$cfg['enabled'] || $cfg['bot_token'] === '') {
        return;
    }

    $title = trim($title);
    $body = trim($body);
    $text = $title !== '' ? ($title . "\n" . $body) : $body;
    if ($text === '') {
        return;
    }

    $chatIds = [];
    $adminChat = trim((string) ($cfg['chat_id'] ?? ''));
    if ($adminChat !== '') {
        $chatIds[$adminChat] = $adminChat;
    }
    foreach (termTelegramChatIdsForUsers($extraUserIds) as $chatId) {
        $chatIds[$chatId] = $chatId;
    }
    if ($chatIds === []) {
        return;
    }

    try {
        foreach ($chatIds as $chatId) {
            termTelegramSend($text, $cfg['bot_token'], $chatId);
        }
    } catch (Throwable $e) {
        error_log('termTelegramNotifyAlert: ' . $e->getMessage());
    }
}

function termTelegramDiscoverChatId(string $token, array $options = []): array
{
    [$data, $error] = termTelegramRequest($token, 'getUpdates', ['limit' => 50]);
    if ($error !== '') {
        return ['', $error];
    }

    $updates = $data['result'] ?? [];
    if (!is_array($updates)) {
        $updates = [];
    }

    $preferPrivate = !empty($options['private']);
    $preferGroup = !empty($options['group']);
    $requireCode = !empty($options['require_code']);
    $exclude = [];
    foreach ((array) ($options['exclude'] ?? []) as $id) {
        $id = trim((string) $id);
        if ($id !== '') {
            $exclude[$id] = true;
        }
    }
    $needle = strtolower(trim((string) ($options['code'] ?? '')));
    if ($requireCode && $needle === '') {
        return ['', 'Cod invalid.'];
    }

    if ($updates === []) {
        if ($needle !== '') {
            return ['', 'Trimite botului: ' . $needle];
        }
        if ($preferGroup) {
            return ['', 'În grup: adaugă botul, trimite /start, apoi încearcă din nou.'];
        }
        return ['', 'Trimite /start botului pe Telegram, apoi încearcă din nou.'];
    }

    $pick = static function (array $chat, ?array $message) use ($preferPrivate, $preferGroup, $exclude, $needle, $requireCode): ?string {
        $id = trim((string) ($chat['id'] ?? ''));
        if ($id === '' || isset($exclude[$id])) {
            return null;
        }

        $type = (string) ($chat['type'] ?? '');
        if ($preferPrivate && $type !== 'private') {
            return null;
        }
        if ($preferGroup && !in_array($type, ['group', 'supergroup'], true)) {
            return null;
        }

        if ($needle !== '') {
            $text = strtolower(trim((string) ($message['text'] ?? '')));
            if ($text === '' || strpos($text, $needle) === false) {
                return null;
            }
        } elseif ($requireCode) {
            return null;
        }

        return $id;
    };

    for ($i = count($updates) - 1; $i >= 0; $i--) {
        $update = $updates[$i];
        if (!is_array($update)) {
            continue;
        }

        $message = $update['message'] ?? ($update['channel_post'] ?? null);
        if (is_array($message) && is_array($message['chat'] ?? null)) {
            $id = $pick($message['chat'], $message);
            if ($id !== null) {
                return [$id, ''];
            }
        }

        $memberChat = $update['my_chat_member']['chat'] ?? ($update['chat_member']['chat'] ?? null);
        if (is_array($memberChat) && $needle === '' && !$requireCode) {
            $id = $pick($memberChat, null);
            if ($id !== null) {
                return [$id, ''];
            }
        }
    }

    if ($needle !== '') {
        return ['', 'Trimite botului: ' . $needle];
    }
    if ($preferGroup) {
        return ['', 'În grup: adaugă botul, trimite /start, apoi încearcă din nou.'];
    }

    return ['', 'Nu am găsit chat. Trimite /start botului, apoi încearcă din nou.'];
}

function termTelegramDiscoverAdminChatId(string $token): array
{
    [$groupId, $groupError] = termTelegramDiscoverChatId($token, ['group' => true]);
    if ($groupId !== '') {
        return [$groupId, ''];
    }

    return ['', $groupError !== '' ? $groupError : 'În grup: adaugă botul, trimite /start, apoi încearcă din nou.'];
}

function termTelegramExcludedAdminChatIds(): array
{
    $exclude = [];
    $adminChat = trim((string) (termTelegramConfig()['chat_id'] ?? ''));
    if ($adminChat !== '') {
        $exclude[$adminChat] = $adminChat;
    }

    try {
        $rows = getDB()->fetchAll(
            "SELECT telegram_chat_id
             FROM users
             WHERE role = 'boss'
               AND telegram_chat_id IS NOT NULL
               AND telegram_chat_id <> ''"
        );
        foreach (is_array($rows) ? $rows : [] as $row) {
            $id = trim((string) ($row['telegram_chat_id'] ?? ''));
            if ($id !== '') {
                $exclude[$id] = $id;
            }
        }
    } catch (Throwable $e) {
    }

    return array_values($exclude);
}

function termTelegramDiscoverManagerChatId(string $token, int $userId): array
{
    $userId = max(0, $userId);
    if ($userId <= 0) {
        return ['', 'Utilizator invalid.'];
    }

    $settingKey = 'telegram_link_' . $userId;
    $now = time();
    $code = '';
    $raw = trim((string) (termSetting($settingKey, '') ?? ''));
    if ($raw !== '' && strpos($raw, '|') !== false) {
        [$savedCode, $untilRaw] = array_pad(explode('|', $raw, 2), 2, '0');
        $savedCode = strtolower(trim((string) $savedCode));
        $until = (int) $untilRaw;
        if ($until > $now && preg_match('/^m[0-9]+[a-f0-9]{6}$/', $savedCode)) {
            $code = $savedCode;
        }
    }
    if ($code === '') {
        $code = 'm' . $userId . substr(bin2hex(random_bytes(3)), 0, 6);
        termSettingUpsert($settingKey, $code . '|' . ($now + 900));
    }

    [$chatId, $error] = termTelegramDiscoverChatId($token, [
        'private' => true,
        'require_code' => true,
        'exclude' => termTelegramExcludedAdminChatIds(),
        'code' => $code,
    ]);

    if ($chatId !== '') {
        termSettingUpsert($settingKey, '');
        return [$chatId, ''];
    }

    return ['', $error !== '' ? $error : ('Trimite botului: ' . $code)];
}

function termRoleLabel(string $role): string
{
    $labels = [
        'boss' => 'Boss',
        'colaborator' => 'Colaborator',
        'manager' => 'Manager',
        'statie' => 'Shop',
        'desfasurator' => 'Desfășurător',
        'casier' => 'Operator terminal',
    ];

    return $labels[$role] ?? $role;
}

function termEnsureCasierRole(): void
{
    static $ready = false;
    if ($ready) {
        return;
    }

    try {
        getDB()->query(
            "ALTER TABLE users
             MODIFY COLUMN role enum('boss','colaborator','manager','statie','desfasurator','casier') NOT NULL"
        );
    } catch (Throwable $e) {
    }

    $ready = true;
}

function termRoleDescription(string $role): string
{
    $descriptions = [
        'boss' => 'Acces complet: jocuri, terminale, shop-uri, utilizatori, incasari si rapoarte.',
        'colaborator' => 'Acces larg ca la boss, fara unele actiuni critice de sistem.',
        'manager' => 'Gestioneaza terminalele si shop-urile la care e asignat; vede incasari si rapoarte.',
        'statie' => 'Operator la locatie: urmareste incasari, sesiuni si terminalele asignate.',
        'desfasurator' => 'Numara banii fizici din aparate (IN/OUT real) si le compara cu ce arata sistemul in pagina Desfasurari.',
    ];

    return $descriptions[$role] ?? '';
}

function termRoleGuideItems(): array
{
    return [
        'boss' => termRoleDescription('boss'),
        'colaborator' => termRoleDescription('colaborator'),
        'manager' => termRoleDescription('manager'),
        'statie' => termRoleDescription('statie'),
        'desfasurator' => termRoleDescription('desfasurator'),
    ];
}

function termGameStatusLabel(string $status): string
{
    $labels = [
        'active' => 'Activ',
        'paused' => 'Pauza',
        'coming_soon' => 'In curand',
    ];

    return $labels[$status] ?? $status;
}

function termGameCoverImage(array $game): ?string
{
    $covers = [
        'verga-gold' => '../images/vergagold.webp',
        'boss-crown' => '../images/bosscrown.webp',
        'dodge-bomb' => '../images/dodgebomb.webp',
        'logic-and-zeus' => '../images/firescatter.webp',
        '40-burn-hot' => '../images/wildclover.webp',
        'intelligent-book' => '../images/intelligentbook.webp',
    ];

    $slug = strtolower((string) ($game['slug'] ?? ''));
    $iconKey = strtolower((string) ($game['icon_key'] ?? ''));
    $title = (string) ($game['title'] ?? '');

    if (isset($covers[$slug])) {
        return $covers[$slug];
    }
    if (isset($covers[$iconKey])) {
        return $covers[$iconKey];
    }
    if (preg_match('/verga\s*gold|golden\s*brain|brain\s*way/i', $title)) {
        return $covers['verga-gold'];
    }
    if (preg_match('/boss\s*crown|millionaire\s*crown/i', $title)) {
        return $covers['boss-crown'];
    }
    if (preg_match('/dodge\s*bomb/i', $title)) {
        return $covers['dodge-bomb'];
    }
    if (preg_match('/logic\s*and\s*zeus|fire\s*scatter/i', $title)) {
        return $covers['logic-and-zeus'];
    }
    if (preg_match('/40\s*burn\s*hot|wild\s*clover/i', $title)) {
        return $covers['40-burn-hot'];
    }
    if (preg_match('/intelligent\s*book|cartea\s*inteligent|book\s*of\s*knowledge/i', $title)) {
        return $covers['intelligent-book'];
    }

    return null;
}

function termGameCoverWildIcon(array $game): ?string
{
    $icons = [
        'verga-gold' => '../games/verga-gold/symbols/timona.webp',
        'boss-crown' => '../games/boss-crown/symbols/coroana.webp',
        'dodge-bomb' => '../games/dodge-bomb/symbols/bomb.webp',
        'logic-and-zeus' => '../games/logic-and-zeus/symbols/scatter.webp',
        '40-burn-hot' => '../games/40-burn-hot/symbols/stea.webp',
        'intelligent-book' => '../games/intelligent-book/symbols/book.webp',
    ];

    $slug = strtolower((string) ($game['slug'] ?? ''));
    $iconKey = strtolower((string) ($game['icon_key'] ?? ''));
    $title = (string) ($game['title'] ?? '');

    if (isset($icons[$slug])) {
        return $icons[$slug];
    }
    if (isset($icons[$iconKey])) {
        return $icons[$iconKey];
    }
    if (preg_match('/boss\s*crown|millionaire\s*crown/i', $title)) {
        return $icons['boss-crown'];
    }
    if (preg_match('/verga\s*gold|golden\s*brain|brain\s*way/i', $title)) {
        return $icons['verga-gold'];
    }
    if (preg_match('/dodge\s*bomb/i', $title)) {
        return $icons['dodge-bomb'];
    }
    if (preg_match('/logic\s*and\s*zeus|fire\s*scatter/i', $title)) {
        return $icons['logic-and-zeus'];
    }
    if (preg_match('/40\s*burn\s*hot|wild\s*clover/i', $title)) {
        return $icons['40-burn-hot'];
    }
    if (preg_match('/intelligent\s*book|cartea\s*inteligent|book\s*of\s*knowledge/i', $title)) {
        return $icons['intelligent-book'];
    }

    return null;
}

function termTerminalStatusLabel(string $status): string
{
    $labels = [
        'offline' => 'Offline',
        'online' => 'Online',
        'maintenance' => 'Mentenanta',
        'blocked' => 'Blocat',
    ];

    return $labels[$status] ?? $status;
}

function termGenerateCode(int $length = 8): string
{
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $code = '';

    for ($i = 0; $i < $length; $i++) {
        $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    }

    return $code;
}

function termGenerateSecret(int $bytes = 32): string
{
    return bin2hex(random_bytes($bytes));
}

function termNormalizePairCode(string $code): string
{
    return strtoupper(preg_replace('/\s+/', '', trim($code)));
}

function termValidatePairCode(string $code): ?string
{
    if ($code === '') {
        return 'Codul de pairing este obligatoriu.';
    }

    if (strlen($code) < 4 || strlen($code) > 12) {
        return 'Codul trebuie sa aiba intre 4 si 12 caractere.';
    }

    if (!preg_match('/^[A-Z0-9]+$/', $code)) {
        return 'Codul poate contine doar litere si cifre.';
    }

    return null;
}

function termSaveTerminalPairCode(int $terminalId, string $rawCode, int $createdBy): ?string
{
    $pairCode = termNormalizePairCode($rawCode);
    $validationError = termValidatePairCode($pairCode);
    if ($validationError !== null) {
        return $validationError;
    }

    $expiresAt = '2099-12-31 23:59:59';

    $codeOwner = getDB()->fetchOne(
        'SELECT id, terminal_id FROM terminal_pairing_codes WHERE pair_code = ? LIMIT 1',
        [$pairCode]
    );

    if ($codeOwner && (int) $codeOwner['terminal_id'] !== $terminalId) {
        return 'Codul este deja folosit la alt terminal.';
    }

    $terminalRow = getDB()->fetchOne(
        'SELECT id FROM terminal_pairing_codes WHERE terminal_id = ? ORDER BY id DESC LIMIT 1',
        [$terminalId]
    );

    if ($terminalRow) {
        getDB()->query(
            'UPDATE terminal_pairing_codes SET pair_code = ?, expires_at = ?, created_by = ? WHERE id = ?',
            [$pairCode, $expiresAt, $createdBy, (int) $terminalRow['id']]
        );

        return null;
    }

    getDB()->insert('terminal_pairing_codes', [
        'terminal_id' => $terminalId,
        'pair_code' => $pairCode,
        'expires_at' => $expiresAt,
        'created_by' => $createdBy,
    ]);

    return null;
}

function termFetchLatestPairCodesMap(array $terminalIds): array
{
    if ($terminalIds === []) {
        return [];
    }

    $placeholders = implode(',', array_fill(0, count($terminalIds), '?'));

    try {
        $rows = getDB()->fetchAll(
            "SELECT pc.terminal_id, pc.pair_code
             FROM terminal_pairing_codes pc
             INNER JOIN (
                 SELECT terminal_id, MAX(id) AS max_id
                 FROM terminal_pairing_codes
                 WHERE terminal_id IN ({$placeholders})
                 GROUP BY terminal_id
             ) latest ON latest.max_id = pc.id",
            $terminalIds
        );
    } catch (Exception $e) {
        return [];
    }

    $map = [];
    foreach ($rows as $row) {
        $map[(int) $row['terminal_id']] = $row;
    }

    return $map;
}

function termFormatMoney($value): string
{
    return number_format((float) $value, 2, '.', ' ') . ' RON';
}

function termFormatDateTime(?string $value): string
{
    if (!$value) {
        return '-';
    }

    $timestamp = strtotime($value);
    if ($timestamp === false) {
        return $value;
    }

    return date('d.m.Y H:i', $timestamp);
}

function termCanManageUsers(string $role): bool
{
    return in_array($role, ['boss', 'colaborator', 'manager'], true);
}

function termCanManageTerminals(string $role): bool
{
    return in_array($role, ['boss', 'colaborator', 'manager'], true);
}

function termCanViewTerminals(string $role): bool
{
    return in_array($role, ['boss', 'colaborator', 'manager', 'statie'], true);
}

function termCanManageGames(string $role): bool
{
    return in_array($role, ['boss', 'colaborator'], true);
}

function termCanManageStations(string $role): bool
{
    return in_array($role, ['boss', 'colaborator', 'manager'], true);
}

function termCanViewStationsMap(string $role): bool
{
    return in_array($role, ['boss', 'colaborator', 'manager'], true);
}

function termCanViewAllReports(string $role): bool
{
    return in_array($role, ['boss', 'colaborator'], true);
}

function termAdminCanViewUser(array $viewer, array $target): bool
{
    $viewerRole = $viewer['role'] ?? '';
    $targetRole = $target['role'] ?? '';
    $viewerId = (int) ($viewer['id'] ?? 0);
    $targetId = (int) ($target['id'] ?? 0);

    if ($viewerId <= 0 || $targetId <= 0) {
        return false;
    }

    if ($viewerRole === 'boss') {
        return true;
    }

    if ($viewerRole === 'colaborator') {
        return $targetRole !== 'boss';
    }

    if ($viewerRole === 'manager') {
        if ($viewerId === $targetId) {
            return true;
        }

        return in_array($targetRole, ['statie', 'desfasurator'], true)
            && (int) ($target['created_by'] ?? 0) === $viewerId;
    }

    return false;
}

function termAccessibleTerminalIds(array $user): array
{
    $role = $user['role'] ?? '';
    $userId = (int) ($user['id'] ?? 0);

    if ($userId <= 0) {
        return [];
    }

    if ($role === 'casier') {
        $parentId = (int) ($user['created_by'] ?? 0);
        if ($parentId <= 0) {
            try {
                $row = getDB()->fetchOne('SELECT created_by FROM users WHERE id = ? LIMIT 1', [$userId]);
                $parentId = (int) ($row['created_by'] ?? 0);
            } catch (Throwable $e) {
                return [];
            }
        }
        if ($parentId <= 0) {
            return [];
        }
        try {
            $parent = getDB()->fetchOne(
                'SELECT id, role, is_active, created_by FROM users WHERE id = ? LIMIT 1',
                [$parentId]
            );
        } catch (Throwable $e) {
            return [];
        }
        if (!$parent || !(int) ($parent['is_active'] ?? 0) || ($parent['role'] ?? '') !== 'statie') {
            return [];
        }

        return termAccessibleTerminalIds($parent);
    }

    if ($role === 'boss' || $role === 'colaborator') {
        $rows = getDB()->fetchAll('SELECT id FROM terminals WHERE is_active = 1 ORDER BY id ASC');
        return array_map(static fn($row) => (int) $row['id'], $rows);
    }

    if ($role === 'manager') {
        $rows = getDB()->fetchAll(
            'SELECT t.id
             FROM terminals t
             INNER JOIN stations s ON s.id = t.station_id
             WHERE t.is_active = 1
               AND s.is_active = 1
               AND s.manager_id = ?
             ORDER BY t.id ASC',
            [$userId]
        );
        return array_map(static fn($row) => (int) $row['id'], $rows);
    }

    if ($role === 'statie' || $role === 'desfasurator') {
        $assignmentRole = $role === 'statie' ? 'statie' : 'desfasurator';
        if ($role === 'statie') {
            $rows = getDB()->fetchAll(
                'SELECT DISTINCT t.id
                 FROM terminals t
                 WHERE t.is_active = 1 AND (
                     t.id IN (
                         SELECT ta.terminal_id
                         FROM terminal_assignments ta
                         WHERE ta.user_id = ? AND ta.assignment_role = ?
                     )
                     OR (
                         t.station_id IS NOT NULL
                         AND t.station_id IN (
                             SELECT DISTINCT t2.station_id
                             FROM terminal_assignments ta
                             INNER JOIN terminals t2 ON t2.id = ta.terminal_id
                             WHERE ta.user_id = ? AND ta.assignment_role = ? AND t2.station_id IS NOT NULL
                         )
                     )
                 )
                 ORDER BY t.id ASC',
                [$userId, $assignmentRole, $userId, $assignmentRole]
            );
        } else {
            $rows = getDB()->fetchAll(
                'SELECT terminal_id AS id FROM terminal_assignments WHERE user_id = ? AND assignment_role = ? ORDER BY terminal_id ASC',
                [$userId, $assignmentRole]
            );
        }
        return array_map(static fn($row) => (int) $row['id'], $rows);
    }

    return [];
}

function termAccessibleStationIds(array $user, bool $viewAllNationwide = false): array
{
    $role = $user['role'] ?? '';
    $userId = (int) ($user['id'] ?? 0);

    if ($userId <= 0) {
        return [];
    }

    if ($role === 'boss' || $role === 'colaborator') {
        $rows = getDB()->fetchAll('SELECT id FROM stations WHERE is_active = 1 ORDER BY id ASC');
        return array_map(static fn($row) => (int) $row['id'], $rows);
    }

    if ($role === 'manager') {
        if ($viewAllNationwide) {
            $rows = getDB()->fetchAll('SELECT id FROM stations ORDER BY id ASC');
            return array_map(static fn($row) => (int) $row['id'], $rows);
        }

        $rows = getDB()->fetchAll('SELECT id FROM stations WHERE is_active = 1 AND manager_id = ? ORDER BY id ASC', [$userId]);
        return array_map(static fn($row) => (int) $row['id'], $rows);
    }

    if ($role === 'statie') {
        $rows = getDB()->fetchAll(
            'SELECT DISTINCT t.station_id AS id
             FROM terminal_assignments ta
             INNER JOIN terminals t ON t.id = ta.terminal_id
             WHERE ta.user_id = ? AND ta.assignment_role = ? AND t.station_id IS NOT NULL',
            [$userId, 'statie']
        );
        return array_map(static fn($row) => (int) $row['id'], $rows);
    }

    return [];
}

function termAdminHasDashboardScope(array $user): bool
{
    return in_array($user['role'] ?? '', ['manager', 'statie', 'desfasurator'], true);
}

if (!function_exists('termMarkStaleTerminalsOffline')) {
    function termMarkStaleTerminalsOffline(int $minutes = 3): void
    {
        $minutes = max(1, $minutes);
        try {
            getDB()->query(
                "UPDATE terminals
                 SET status = 'offline'
                 WHERE status = 'online'
                   AND (last_heartbeat_at IS NULL OR last_heartbeat_at < DATE_SUB(NOW(), INTERVAL {$minutes} MINUTE))"
            );
        } catch (Throwable $e) {
            error_log('termMarkStaleTerminalsOffline: ' . $e->getMessage());
        }
    }
}

function termCanManageStation(array $user, array $station): bool
{
    $role = $user['role'] ?? '';

    if (in_array($role, ['boss', 'colaborator'], true)) {
        return true;
    }

    if ($role === 'manager') {
        return (int) ($station['manager_id'] ?? 0) === (int) ($user['id'] ?? 0);
    }

    return false;
}

function termTerminalFilterSql(array $user, string $alias = 't'): array
{
    $ids = termAccessibleTerminalIds($user);

    if ($ids === []) {
        return ['1 = 0', []];
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    return ["{$alias}.id IN ({$placeholders})", $ids];
}

function termStationFilterSql(array $user, string $alias = 's', bool $viewAllNationwide = false): array
{
    $ids = termAccessibleStationIds($user, $viewAllNationwide);

    if ($ids === []) {
        return ['1 = 0', []];
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    return ["{$alias}.id IN ({$placeholders})", $ids];
}

function termAdminPaginationMarkup(int $page, int $totalPages, int $totalItems, int $perPage, string $emptyLabel = 'Nicio inregistrare.'): string
{
    $from = $totalItems > 0 ? (($page - 1) * $perPage + 1) : 0;
    $to = min($totalItems, $page * $perPage);

    $buildUrl = static function (int $targetPage): string {
        $query = $_GET;
        $query['page'] = max(1, $targetPage);
        return '?' . http_build_query($query);
    };

    $html = '<div class="admin-pagination">';
    $html .= '<span class="admin-pagination-info">';
    if ($totalItems <= 0) {
        $html .= termEscape($emptyLabel);
    } else {
        $html .= 'Afisate ' . $from . '–' . $to . ' din ' . $totalItems;
        if ($totalPages > 1) {
            $html .= ' · Pagina ' . $page . ' din ' . $totalPages;
        }
    }
    $html .= '</span>';

    if ($totalPages > 1) {
        $html .= '<div class="admin-pagination-actions">';

        if ($page > 1) {
            $html .= '<a class="admin-btn admin-btn-secondary admin-pagination-btn" href="' . termEscape($buildUrl($page - 1)) . '"><i class="fas fa-chevron-left"></i> Inapoi</a>';
        } else {
            $html .= '<span class="admin-btn admin-btn-secondary admin-pagination-btn is-disabled" aria-disabled="true"><i class="fas fa-chevron-left"></i> Inapoi</span>';
        }

        $html .= '<div class="admin-pagination-pages" aria-label="Pagini">';
        $start = max(1, $page - 2);
        $end = min($totalPages, $page + 2);

        if ($start > 1) {
            $html .= '<a class="admin-pagination-page" href="' . termEscape($buildUrl(1)) . '">1</a>';
            if ($start > 2) {
                $html .= '<span class="admin-pagination-ellipsis">…</span>';
            }
        }

        for ($p = $start; $p <= $end; $p++) {
            if ($p === $page) {
                $html .= '<span class="admin-pagination-page is-active" aria-current="page">' . $p . '</span>';
            } else {
                $html .= '<a class="admin-pagination-page" href="' . termEscape($buildUrl($p)) . '">' . $p . '</a>';
            }
        }

        if ($end < $totalPages) {
            if ($end < $totalPages - 1) {
                $html .= '<span class="admin-pagination-ellipsis">…</span>';
            }
            $html .= '<a class="admin-pagination-page" href="' . termEscape($buildUrl($totalPages)) . '">' . $totalPages . '</a>';
        }
        $html .= '</div>';

        if ($page < $totalPages) {
            $html .= '<a class="admin-btn admin-btn-secondary admin-pagination-btn" href="' . termEscape($buildUrl($page + 1)) . '">Inainte <i class="fas fa-chevron-right"></i></a>';
        } else {
            $html .= '<span class="admin-btn admin-btn-secondary admin-pagination-btn is-disabled" aria-disabled="true">Inainte <i class="fas fa-chevron-right"></i></span>';
        }

        $html .= '</div>';
    }

    $html .= '</div>';

    return $html;
}

function termAdminReportPeriods(): array
{
    return [
        'yesterday' => 'Ieri',
        '1d' => 'Azi',
        '7d' => '7 zile',
        '30d' => '30 zile',
    ];
}

function termAdminBusinessDayHour(): int
{
    return 6;
}

function termAdminBusinessDaySqlExpr(string $column = 'tt.created_at'): string
{
    $hour = termAdminBusinessDayHour();
    return "DATE(DATE_SUB({$column}, INTERVAL {$hour} HOUR))";
}

function termAdminCurrentBusinessDaySqlExpr(): string
{
    return termAdminBusinessDaySqlExpr('NOW()');
}

function termAdminParseReportDate(?string $value): ?string
{
    $value = trim((string) ($value ?? ''));
    if ($value === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return null;
    }

    $parts = explode('-', $value);
    if (!checkdate((int) $parts[1], (int) $parts[2], (int) $parts[0])) {
        return null;
    }

    return $value;
}

function termAdminFormatReportDateLabel(?string $value): string
{
    $value = termAdminParseReportDate($value);
    if ($value === null) {
        return '';
    }

    $timestamp = strtotime($value . ' 00:00:00');
    if ($timestamp === false) {
        return $value;
    }

    return date('d.m.Y', $timestamp);
}

function termAdminParseReportMonth(?string $value): ?string
{
    $value = trim((string) ($value ?? ''));
    if ($value === '' || !preg_match('/^\d{4}-\d{2}$/', $value)) {
        return null;
    }

    $parts = explode('-', $value);
    $year = (int) $parts[0];
    $month = (int) $parts[1];
    if ($year < 2000 || $year > 2100 || !checkdate($month, 1, $year)) {
        return null;
    }

    return sprintf('%04d-%02d', $year, $month);
}

function termAdminFormatReportMonthLabel(?string $value): string
{
    $value = termAdminParseReportMonth($value);
    if ($value === null) {
        return '';
    }

    $months = [
        1 => 'Ianuarie',
        2 => 'Februarie',
        3 => 'Martie',
        4 => 'Aprilie',
        5 => 'Mai',
        6 => 'Iunie',
        7 => 'Iulie',
        8 => 'August',
        9 => 'Septembrie',
        10 => 'Octombrie',
        11 => 'Noiembrie',
        12 => 'Decembrie',
    ];
    $parts = explode('-', $value);
    $monthName = $months[(int) $parts[1]] ?? $value;

    return $monthName . ' ' . $parts[0];
}

function termAdminNormalizeReportPeriod(?string $period): string
{
    $periods = termAdminReportPeriods();
    $key = trim((string) ($period ?? '1d'));

    if ($key === 'custom' || $key === 'month') {
        return $key;
    }

    if (array_key_exists($key, $periods)) {
        return $key;
    }

    $legacy = ['all', '3m', '6m', '12m'];
    if (in_array($key, $legacy, true)) {
        return $key;
    }

    return '1d';
}

function termAdminReportPeriodContext(?array $query = null): array
{
    $query = $query ?? $_GET;
    $key = termAdminNormalizeReportPeriod($query['period'] ?? '1d');
    $from = null;
    $to = null;
    $month = null;

    if ($key === 'month') {
        $month = termAdminParseReportMonth($query['month'] ?? null);
        if ($month === null) {
            $key = '1d';
        } else {
            $from = $month . '-01';
            $lastDay = date('Y-m-t', strtotime($from . ' 00:00:00'));
            if ($lastDay === false || $lastDay === '') {
                $key = '1d';
                $from = null;
                $month = null;
            } else {
                $to = $lastDay;
            }
        }
    } elseif ($key === 'custom') {
        $from = termAdminParseReportDate($query['from'] ?? null);
        $to = termAdminParseReportDate($query['to'] ?? null);
        if ($from === null || $to === null || $from > $to) {
            $key = '7d';
            $from = null;
            $to = null;
        }
    }

    if ($key === 'month' && $from !== null && $to !== null) {
        $meta = termAdminReportPeriodMeta('custom', $from, $to);
        $meta['key'] = 'month';
        $meta['label'] = termAdminFormatReportMonthLabel($month);
    } else {
        $meta = termAdminReportPeriodMeta($key, $from, $to);
    }

    return [
        'key' => $key,
        'from' => $from,
        'to' => $to,
        'month' => $month,
        'meta' => $meta,
    ];
}

function termAdminReportPeriodMeta(string $periodKey, ?string $fromDate = null, ?string $toDate = null): array
{
    $periods = termAdminReportPeriods();
    $label = $periods[$periodKey] ?? 'Perioada';
    $bizDay = termAdminBusinessDaySqlExpr('tt.created_at');
    $bizToday = termAdminCurrentBusinessDaySqlExpr();
    $hour = termAdminBusinessDayHour();

    switch ($periodKey) {
        case 'yesterday':
            return [
                'key' => 'yesterday',
                'label' => $label,
                'transaction_sql' => "{$bizDay} = DATE_SUB({$bizToday}, INTERVAL 1 DAY)",
                'transaction_params' => [],
                'use_terminal_totals' => false,
            ];
        case '1d':
            return [
                'key' => '1d',
                'label' => $label,
                'transaction_sql' => "{$bizDay} = {$bizToday}",
                'transaction_params' => [],
                'use_terminal_totals' => false,
            ];
        case '7d':
            return [
                'key' => '7d',
                'label' => $label,
                'transaction_sql' => "{$bizDay} >= DATE_SUB({$bizToday}, INTERVAL 6 DAY)",
                'transaction_params' => [],
                'use_terminal_totals' => false,
            ];
        case '30d':
            return [
                'key' => '30d',
                'label' => $label,
                'transaction_sql' => "{$bizDay} >= DATE_SUB({$bizToday}, INTERVAL 29 DAY)",
                'transaction_params' => [],
                'use_terminal_totals' => false,
            ];
        case 'custom':
            $from = termAdminParseReportDate($fromDate);
            $to = termAdminParseReportDate($toDate);
            if ($from === null || $to === null) {
                return termAdminReportPeriodMeta('7d');
            }

            return [
                'key' => 'custom',
                'label' => termAdminFormatReportDateLabel($from) . ' - ' . termAdminFormatReportDateLabel($to),
                'transaction_sql' => "{$bizDay} BETWEEN '{$from}' AND '{$to}'",
                'transaction_params' => [],
                'use_terminal_totals' => false,
            ];
        case '3m':
            return [
                'key' => '3m',
                'label' => '3 luni',
                'transaction_sql' => "tt.created_at >= DATE_ADD(DATE_SUB({$bizToday}, INTERVAL 3 MONTH), INTERVAL {$hour} HOUR)",
                'transaction_params' => [],
                'use_terminal_totals' => false,
            ];
        case '6m':
            return [
                'key' => '6m',
                'label' => '6 luni',
                'transaction_sql' => "tt.created_at >= DATE_ADD(DATE_SUB({$bizToday}, INTERVAL 6 MONTH), INTERVAL {$hour} HOUR)",
                'transaction_params' => [],
                'use_terminal_totals' => false,
            ];
        case '12m':
            return [
                'key' => '12m',
                'label' => '12 luni',
                'transaction_sql' => "tt.created_at >= DATE_ADD(DATE_SUB({$bizToday}, INTERVAL 12 MONTH), INTERVAL {$hour} HOUR)",
                'transaction_params' => [],
                'use_terminal_totals' => false,
            ];
        default:
            return [
                'key' => 'all',
                'label' => 'Tot',
                'transaction_sql' => '1 = 1',
                'transaction_params' => [],
                'use_terminal_totals' => true,
            ];
    }
}

function termAdminPeriodMetaFromInput($periodKeyOrContext): array
{
    if (is_array($periodKeyOrContext) && isset($periodKeyOrContext['meta'])) {
        return $periodKeyOrContext['meta'];
    }

    return termAdminReportPeriodMeta((string) $periodKeyOrContext);
}

function termDefaultCreditRate(): float
{
    $rate = (float) (termSetting('default_credit_rate', '0.1') ?? '0.1');

    return $rate > 0 ? $rate : 0.1;
}

function termAdminCreditRateValue($value): float
{
    $rate = (float) $value;
    if ($rate <= 0) {
        return termDefaultCreditRate();
    }

    $default = termDefaultCreditRate();
    if (abs($rate - 1.0) < 0.0001 && abs($default - 1.0) >= 0.0001) {
        return $default;
    }

    return $rate;
}

function termTerminalCreditRate(array $terminal): float
{
    return max(0.0001, termAdminCreditRateValue($terminal['credit_rate'] ?? null));
}

function termAdminEnrichTerminalPeriodStats(array $rows): array
{
    foreach ($rows as &$row) {
        $rate = termAdminCreditRateValue($row['credit_rate'] ?? null);
        $credits = (int) ($row['credits_balance'] ?? 0);
        $row['credit_rate'] = $rate;
        $row['period_in'] = (float) ($row['period_in'] ?? 0);
        $row['period_out'] = (float) ($row['period_out'] ?? 0);
        $row['credits_money'] = round($credits * $rate, 2);
        $row['cash_profit'] = round($row['period_in'] - $row['period_out'], 2);
        $row['net_profit'] = $row['cash_profit'];
        $row['profit'] = $row['net_profit'];
    }
    unset($row);

    return $rows;
}

function termAdminFetchTerminalPeriodStats(array $user, $periodKeyOrContext): array
{
    [$filterSql, $filterParams] = termTerminalFilterSql($user, 't');
    $meta = termAdminPeriodMetaFromInput($periodKeyOrContext);

    try {
        if (!empty($meta['use_terminal_totals'])) {
            $rows = getDB()->fetchAll(
                "SELECT t.id, t.name, t.terminal_code, t.credits_balance, t.credit_rate, s.name AS station_name,
                        t.money_in_total AS period_in, t.money_out_total AS period_out
                 FROM terminals t
                 LEFT JOIN stations s ON s.id = t.station_id
                 WHERE {$filterSql}
                 ORDER BY t.name ASC",
                $filterParams
            );
        } else {
            $periodSqlIn = str_replace('tt.', 'tt_in.', $meta['transaction_sql']);
            $periodSqlOut = str_replace('tt.', 'tt_out.', $meta['transaction_sql']);

            $rows = getDB()->fetchAll(
                "SELECT t.id, t.name, t.terminal_code, t.credits_balance, t.credit_rate, s.name AS station_name,
                        (
                            SELECT COALESCE(SUM(tt_in.amount_money), 0)
                            FROM terminal_transactions tt_in
                            WHERE tt_in.terminal_id = t.id
                              AND tt_in.type = 'money_in'
                              AND {$periodSqlIn}
                        ) AS period_in,
                        (
                            SELECT COALESCE(SUM(tt_out.amount_money), 0)
                            FROM terminal_transactions tt_out
                            WHERE tt_out.terminal_id = t.id
                              AND tt_out.type = 'money_out'
                              AND {$periodSqlOut}
                        ) AS period_out
                 FROM terminals t
                 LEFT JOIN stations s ON s.id = t.station_id
                 WHERE {$filterSql}
                 ORDER BY t.name ASC",
                $filterParams
            );
        }
    } catch (Exception $e) {
        error_log('termAdminFetchTerminalPeriodStats: ' . $e->getMessage());
        return [];
    }

    return termAdminEnrichTerminalPeriodStats($rows);
}

function termAdminFetchTerminalSpinCounts(array $user, $periodKeyOrContext): array
{
    [$filterSql, $filterParams] = termTerminalFilterSql($user, 't');
    $meta = termAdminPeriodMetaFromInput($periodKeyOrContext);
    $periodSql = $meta['transaction_sql'];

    try {
        $rows = getDB()->fetchAll(
            "SELECT tt.terminal_id, COUNT(*) AS spin_count
             FROM terminal_transactions tt
             INNER JOIN terminals t ON t.id = tt.terminal_id
             WHERE {$filterSql} AND tt.type = 'bet' AND {$periodSql}
             GROUP BY tt.terminal_id",
            $filterParams
        );
    } catch (Exception $e) {
        error_log('termAdminFetchTerminalSpinCounts: ' . $e->getMessage());
        return [];
    }

    $counts = [];
    foreach ($rows as $row) {
        $counts[(int) ($row['terminal_id'] ?? 0)] = (int) ($row['spin_count'] ?? 0);
    }

    return $counts;
}

function termAdminFetchTerminalSessionCounts(array $user, $periodKeyOrContext): array
{
    return termAdminFetchTerminalSpinCounts($user, $periodKeyOrContext);
}

function termAdminFetchCreditsSnapshot(array $user): array
{
    [$filterSql, $filterParams] = termTerminalFilterSql($user, 't');

    try {
        $row = getDB()->fetchOne(
            "SELECT
                COALESCE(SUM(t.credits_balance), 0) AS total_credits,
                COALESCE(SUM(t.credits_balance * CASE WHEN t.credit_rate > 0 THEN t.credit_rate ELSE 1 END), 0) AS credits_money
             FROM terminals t
             WHERE {$filterSql}",
            $filterParams
        );
    } catch (Exception $e) {
        error_log('termAdminFetchCreditsSnapshot: ' . $e->getMessage());
        return ['total_credits' => 0, 'credits_money' => 0.0];
    }

    return [
        'total_credits' => (int) ($row['total_credits'] ?? 0),
        'credits_money' => round((float) ($row['credits_money'] ?? 0), 2),
    ];
}

function termAdminFetchPeriodMoneyTotals(array $user, $periodKeyOrContext, ?array $rows = null): array
{
    if ($rows === null) {
        $rows = termAdminFetchTerminalPeriodStats($user, $periodKeyOrContext);
    }

    $creditsSnapshot = termAdminFetchCreditsSnapshot($user);
    $totalIn = 0.0;
    $totalOut = 0.0;

    foreach ($rows as $row) {
        $totalIn += (float) ($row['period_in'] ?? 0);
        $totalOut += (float) ($row['period_out'] ?? 0);
    }

    $cashProfit = round($totalIn - $totalOut, 2);
    $totalCredits = (int) ($creditsSnapshot['total_credits'] ?? 0);
    $creditsMoney = round((float) ($creditsSnapshot['credits_money'] ?? 0), 2);
    $netProfit = $cashProfit;

    return [
        'total_in' => $totalIn,
        'total_out' => $totalOut,
        'cash_profit' => $cashProfit,
        'profit' => $cashProfit,
        'total_credits' => $totalCredits,
        'credits_money' => $creditsMoney,
        'net_profit' => $netProfit,
    ];
}

function termAdminFetchPeriodGameTotals(array $user, $periodKeyOrContext): array
{
    [$filterSql, $filterParams] = termTerminalFilterSql($user, 't');
    $meta = termAdminPeriodMetaFromInput($periodKeyOrContext);
    $periodSql = $meta['transaction_sql'];

    try {
        $row = getDB()->fetchOne(
            "SELECT
                COALESCE(SUM(CASE WHEN tt.type = 'bet' THEN tt.amount_credits ELSE 0 END), 0) AS total_bet,
                COALESCE(SUM(CASE WHEN tt.type = 'win' THEN tt.amount_credits ELSE 0 END), 0) AS total_win
             FROM terminal_transactions tt
             INNER JOIN terminals t ON t.id = tt.terminal_id
             WHERE {$filterSql} AND {$periodSql}",
            $filterParams
        );
    } catch (Exception $e) {
        error_log('termAdminFetchPeriodGameTotals: ' . $e->getMessage());
        return ['total_bet' => 0, 'total_win' => 0];
    }

    return [
        'total_bet' => (int) ($row['total_bet'] ?? 0),
        'total_win' => (int) ($row['total_win'] ?? 0),
    ];
}

function termAdminProfitClass(float $profit): string
{
    if ($profit > 0.009) {
        return 'admin-profit-positive';
    }
    if ($profit < -0.009) {
        return 'admin-profit-negative';
    }

    return 'admin-profit-zero';
}

function termAdminFormatProfit(float $profit): string
{
    $prefix = $profit > 0.009 ? '+' : '';
    if ($profit < -0.009) {
        $prefix = '-';
        $profit = abs($profit);
    }

    return $prefix . termFormatMoney($profit);
}

function termAdminProfitLabel(float $profit): string
{
    if ($profit > 0.009) {
        return 'Profit';
    }
    if ($profit < -0.009) {
        return 'Minus';
    }

    return 'Echilibru';
}

function termAdminPeriodFilterMarkup($periodKeyOrContext, ?string $fromDate = null, ?string $toDate = null): string
{
    if (is_array($periodKeyOrContext)) {
        $currentPeriod = (string) ($periodKeyOrContext['key'] ?? '1d');
        $fromDate = $periodKeyOrContext['from'] ?? null;
        $toDate = $periodKeyOrContext['to'] ?? null;
    } else {
        $currentPeriod = (string) $periodKeyOrContext;
    }

    $periods = termAdminReportPeriods();
    $html = '<div class="admin-period-filters" aria-label="Filtru perioada">';

    foreach ($periods as $key => $label) {
        $query = $_GET;
        $query['period'] = $key;
        unset($query['page'], $query['from'], $query['to']);
        $url = '?' . http_build_query($query);
        $isActive = $currentPeriod === $key;
        $class = 'admin-period-filter' . ($isActive ? ' is-active' : '');

        $html .= '<a class="' . $class . '" href="' . termEscape($url) . '">' . termEscape($label) . '</a>';
    }

    $rangeClass = 'admin-period-range' . ($currentPeriod === 'custom' ? ' is-active' : '');
    $defaultTo = termAdminParseReportDate($toDate) ?? date('Y-m-d');
    $defaultFrom = termAdminParseReportDate($fromDate) ?? date('Y-m-d', strtotime('-6 days'));

    $html .= '<form class="' . $rangeClass . '" method="get" aria-label="Interval personalizat">';
    $html .= '<input type="hidden" name="period" value="custom">';
    $html .= '<span class="admin-period-range-label">Interval</span>';
    $html .= '<label class="admin-period-range-field"><span>De la</span><input type="date" name="from" value="' . termEscape($defaultFrom) . '" required></label>';
    $html .= '<label class="admin-period-range-field"><span>Pana la</span><input type="date" name="to" value="' . termEscape($defaultTo) . '" required></label>';
    $html .= '<button type="submit" class="admin-period-range-submit">Aplica</button>';
    $html .= '</form>';
    $html .= '</div>';

    return $html;
}

function termAdminPeriodFilterMarkupSafe(array $periodContext): string
{
    try {
        $reflection = new ReflectionFunction('termAdminPeriodFilterMarkup');
        $param = $reflection->getParameters()[0] ?? null;
        if ($param && $param->hasType()) {
            $type = $param->getType();
            if ($type instanceof ReflectionNamedType && $type->getName() === 'string') {
                return termAdminPeriodFilterMarkup((string) ($periodContext['key'] ?? '1d'));
            }
        }
    } catch (ReflectionException $e) {
        return termAdminPeriodFilterMarkup((string) ($periodContext['key'] ?? '1d'));
    }

    return termAdminPeriodFilterMarkup($periodContext);
}

function termAdminPeriodFetchInput(array $periodContext)
{
    try {
        $reflection = new ReflectionFunction('termAdminFetchTerminalPeriodStats');
        $param = $reflection->getParameters()[1] ?? null;
        if ($param && $param->hasType()) {
            $type = $param->getType();
            if ($type instanceof ReflectionNamedType && $type->getName() === 'string') {
                return $periodContext['key'];
            }
        }
    } catch (ReflectionException $e) {
        return $periodContext['key'];
    }

    return $periodContext;
}

function termParseMapCoordinates(?string $raw): ?array
{
    $raw = trim((string) $raw);
    if ($raw === '') {
        return null;
    }

    if (preg_match('/@(-?\d{1,2}(?:\.\d+)?),\s*(-?\d{1,3}(?:\.\d+)?)/', $raw, $m)) {
        return termNormalizeLatLng((float) $m[1], (float) $m[2]);
    }

    if (preg_match('/[?&](?:q|query|ll|destination)=(-?\d{1,2}(?:\.\d+)?),\s*(-?\d{1,3}(?:\.\d+)?)/i', $raw, $m)) {
        return termNormalizeLatLng((float) $m[1], (float) $m[2]);
    }

    if (preg_match('/!3d(-?\d{1,2}(?:\.\d+)?)!4d(-?\d{1,3}(?:\.\d+)?)/', $raw, $m)) {
        return termNormalizeLatLng((float) $m[1], (float) $m[2]);
    }

    if (preg_match('/geo:(-?\d{1,2}(?:\.\d+)?),(-?\d{1,3}(?:\.\d+)?)/i', $raw, $m)) {
        return termNormalizeLatLng((float) $m[1], (float) $m[2]);
    }

    if (preg_match('/^\s*(-?\d{1,2}(?:\.\d+)?)\s*[,;\s]\s*(-?\d{1,3}(?:\.\d+)?)\s*$/', $raw, $m)) {
        return termNormalizeLatLng((float) $m[1], (float) $m[2]);
    }

    return null;
}

function termNormalizeLatLng(float $lat, float $lng): ?array
{
    if ($lat < -90.0 || $lat > 90.0 || $lng < -180.0 || $lng > 180.0) {
        return null;
    }
    if (abs($lat) < 0.0001 && abs($lng) < 0.0001) {
        return null;
    }
    return ['lat' => $lat, 'lng' => $lng];
}

function termSaveStationCoordinates(int $stationId, ?float $lat, ?float $lng): void
{
    if ($stationId <= 0) {
        return;
    }
    if ($lat === null || $lng === null) {
        getDB()->update('stations', [
            'latitude' => null,
            'longitude' => null,
        ], 'id = :id', ['id' => $stationId]);
        return;
    }
    getDB()->update('stations', [
        'latitude' => $lat,
        'longitude' => $lng,
    ], 'id = :id', ['id' => $stationId]);
}

function termGeocodeAddress(string $address): ?array
{
    $address = trim($address);
    if ($address === '') {
        return null;
    }

    $fromMap = termParseMapCoordinates($address);
    if ($fromMap !== null) {
        return $fromMap;
    }

    $search = $address;
    if (!preg_match('/romania|românia|\bro\b/i', $address)) {
        $search .= ', Romania';
    }

    $url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' . rawurlencode($search);
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => "User-Agent: IQWIN-Skill-Terminal/1.0 (admin map)\r\nAccept: application/json\r\n",
            'timeout' => 6,
        ],
    ]);

    $response = @file_get_contents($url, false, $context);
    if ($response === false) {
        return null;
    }

    $rows = json_decode($response, true);
    if (!is_array($rows) || $rows === []) {
        return null;
    }

    $lat = (float) ($rows[0]['lat'] ?? 0);
    $lng = (float) ($rows[0]['lon'] ?? 0);
    return termNormalizeLatLng($lat, $lng);
}

function termStationSyncCoordinates(int $stationId, ?string $location = null): void
{
    try {
        if (function_exists('termStationEnsureLocationColumns')) {
            termStationEnsureLocationColumns();
        }

        $station = getDB()->fetchOne(
            'SELECT id, location, judet, localitate FROM stations WHERE id = ? LIMIT 1',
            [$stationId]
        );
        if (!$station) {
            return;
        }

        $mapCode = $location !== null ? trim($location) : trim((string) ($station['location'] ?? ''));
        $fromMap = termParseMapCoordinates($mapCode);
        if ($fromMap !== null) {
            termSaveStationCoordinates($stationId, $fromMap['lat'], $fromMap['lng']);
            return;
        }

        $judet = trim((string) ($station['judet'] ?? ''));
        $localitate = trim((string) ($station['localitate'] ?? ''));
        if (function_exists('termStationDisplayCounty')) {
            $judet = termStationDisplayCounty($judet) ?: $judet;
        }
        if (function_exists('termStationDisplayCity')) {
            $localitate = termStationDisplayCity($localitate, $judet) ?: $localitate;
        }

        $address = function_exists('termStationBuildGeoAddress')
            ? termStationBuildGeoAddress($judet, $localitate, $mapCode)
            : trim($mapCode . ' ' . $localitate . ' ' . $judet);

        $clean = trim(str_ireplace(['Romania', 'judetul', ','], '', $address));
        if ($clean === '') {
            termSaveStationCoordinates($stationId, null, null);
            return;
        }

        $coords = termGeocodeAddress($address);
        if ($coords === null && $localitate !== '') {
            $coords = termGeocodeAddress($localitate . ', ' . $judet . ', Romania');
        }
        if ($coords === null && $judet !== '') {
            $coords = termGeocodeAddress($judet . ', Romania');
        }
        if ($coords === null) {
            return;
        }

        termSaveStationCoordinates($stationId, $coords['lat'], $coords['lng']);
    } catch (Exception $e) {
        error_log('termStationSyncCoordinates: ' . $e->getMessage());
    }
}

function termStationEnsureCoordinates(int $stationId): ?array
{
    try {
        $station = getDB()->fetchOne(
            'SELECT id, location, latitude, longitude FROM stations WHERE id = ? LIMIT 1',
            [$stationId]
        );
    } catch (Exception $e) {
        return null;
    }

    if (!$station) {
        return null;
    }

    $lat = $station['latitude'] ?? null;
    $lng = $station['longitude'] ?? null;
    if ($lat !== null && $lng !== null && ((float) $lat !== 0.0 || (float) $lng !== 0.0)) {
        return ['lat' => (float) $lat, 'lng' => (float) $lng];
    }

    termStationSyncCoordinates($stationId);

    try {
        $updated = getDB()->fetchOne(
            'SELECT latitude, longitude FROM stations WHERE id = ? LIMIT 1',
            [$stationId]
        );
    } catch (Exception $e) {
        return null;
    }

    if (!$updated || $updated['latitude'] === null || $updated['longitude'] === null) {
        return null;
    }

    return [
        'lat' => (float) $updated['latitude'],
        'lng' => (float) $updated['longitude'],
    ];
}

function termAdminBuildTerminalsMapPayload(array $terminals, array $terminalStatsById, string $periodLabel): array
{
    $stations = [];
    $unmapped = [];

    foreach ($terminals as $terminal) {
        $terminalId = (int) ($terminal['id'] ?? 0);
        $stationId = (int) ($terminal['station_id'] ?? 0);
        $stat = $terminalStatsById[$terminalId] ?? [];
        $netProfit = (float) ($stat['net_profit'] ?? $stat['profit'] ?? 0);
        $entry = [
            'id' => $terminalId,
            'name' => (string) ($terminal['name'] ?? ''),
            'code' => (string) ($terminal['terminal_code'] ?? ''),
            'status' => (string) ($terminal['status'] ?? 'offline'),
            'active' => (int) ($terminal['is_active'] ?? 0) === 1,
            'credits' => (int) ($terminal['credits_balance'] ?? 0),
            'in' => termFormatMoney((float) ($stat['period_in'] ?? 0)),
            'out' => termFormatMoney((float) ($stat['period_out'] ?? 0)),
            'profit' => termAdminFormatProfit($netProfit),
            'profit_class' => termAdminProfitClass($netProfit),
            'heartbeat' => termFormatDateTime($terminal['last_heartbeat_at'] ?? null),
        ];

        if ($stationId <= 0) {
            $unmapped[] = $entry;
            continue;
        }

        if (!isset($stations[$stationId])) {
            $coords = null;
            $dbLat = $terminal['station_latitude'] ?? null;
            $dbLng = $terminal['station_longitude'] ?? null;
            if ($dbLat !== null && $dbLng !== null && ((float) $dbLat !== 0.0 || (float) $dbLng !== 0.0)) {
                $coords = ['lat' => (float) $dbLat, 'lng' => (float) $dbLng];
            } else {
                $coords = termStationEnsureCoordinates($stationId);
                if ($coords === null) {
                    $locationText = trim((string) ($terminal['station_location'] ?? ''));
                    if ($locationText !== '') {
                        $coords = termGeocodeAddress($locationText);
                    }
                }
            }

            $stations[$stationId] = [
                'id' => $stationId,
                'name' => (string) ($terminal['station_name'] ?? 'Shop'),
                'location' => (string) ($terminal['station_location'] ?? ''),
                'lat' => $coords['lat'] ?? null,
                'lng' => $coords['lng'] ?? null,
                'terminals' => [],
            ];
        }

        $stations[$stationId]['terminals'][] = $entry;
    }

    $markers = [];
    foreach ($stations as $station) {
        if ($station['lat'] === null || $station['lng'] === null) {
            foreach ($station['terminals'] as $terminalEntry) {
                $unmapped[] = $terminalEntry;
            }
            continue;
        }

        $online = 0;
        $blocked = 0;
        foreach ($station['terminals'] as $terminalEntry) {
            if (($terminalEntry['status'] ?? '') === 'online') {
                $online++;
            }
            if (($terminalEntry['status'] ?? '') === 'blocked') {
                $blocked++;
            }
        }

        $markers[] = [
            'station_id' => (int) $station['id'],
            'name' => $station['name'],
            'location' => $station['location'],
            'lat' => $station['lat'],
            'lng' => $station['lng'],
            'online' => $online,
            'total' => count($station['terminals']),
            'blocked' => $blocked,
            'terminals' => $station['terminals'],
        ];
    }

    return [
        'markers' => $markers,
        'unmapped' => $unmapped,
        'period' => $periodLabel,
        'center' => ['lat' => 45.9432, 'lng' => 24.9668],
        'zoom' => 7,
    ];
}

function termAdminStationOperatorsByStation(array $stationIds): array
{
    if ($stationIds === []) {
        return [];
    }

    $placeholders = implode(',', array_fill(0, count($stationIds), '?'));

    try {
        $rows = getDB()->fetchAll(
            "SELECT t.station_id, u.display_name
             FROM terminal_assignments ta
             INNER JOIN terminals t ON t.id = ta.terminal_id AND t.is_active = 1
             INNER JOIN users u ON u.id = ta.user_id AND u.is_active = 1
             WHERE ta.assignment_role = 'statie'
               AND t.station_id IN ({$placeholders})
             ORDER BY u.display_name ASC",
            $stationIds
        );
    } catch (Exception $e) {
        error_log('termAdminStationOperatorsByStation: ' . $e->getMessage());

        return [];
    }

    $map = [];
    foreach ($rows as $row) {
        $stationId = (int) ($row['station_id'] ?? 0);
        $name = trim((string) ($row['display_name'] ?? ''));
        if ($stationId <= 0 || $name === '') {
            continue;
        }
        if (!isset($map[$stationId])) {
            $map[$stationId] = [];
        }
        if (!in_array($name, $map[$stationId], true)) {
            $map[$stationId][] = $name;
        }
    }

    return $map;
}

function termAdminBuildStationsMapPayload(array $user, array $stations): array
{
    $terminalsByStation = [];
    $role = $user['role'] ?? '';

    try {
        if ($role === 'manager') {
            $stationIds = array_values(array_filter(array_map(
                static fn(array $station): int => (int) ($station['id'] ?? 0),
                $stations
            )));

            if ($stationIds === []) {
                $rows = [];
            } else {
                $placeholders = implode(',', array_fill(0, count($stationIds), '?'));
                $rows = getDB()->fetchAll(
                    "SELECT t.id, t.name, t.terminal_code, t.status, t.is_active, t.credits_balance,
                            t.station_id, t.money_in_total, t.money_out_total, t.credit_rate, t.last_heartbeat_at
                     FROM terminals t
                     WHERE t.station_id IN ({$placeholders}) AND t.station_id IS NOT NULL AND t.is_active = 1
                     ORDER BY t.name ASC",
                    $stationIds
                );
            }
        } else {
            [$filterSql, $filterParams] = termTerminalFilterSql($user, 't');
            $rows = getDB()->fetchAll(
                "SELECT t.id, t.name, t.terminal_code, t.status, t.is_active, t.credits_balance,
                        t.station_id, t.money_in_total, t.money_out_total, t.credit_rate, t.last_heartbeat_at
                 FROM terminals t
                 WHERE {$filterSql} AND t.station_id IS NOT NULL AND t.is_active = 1
                 ORDER BY t.name ASC",
                $filterParams
            );
        }
    } catch (Exception $e) {
        error_log('termAdminBuildStationsMapPayload: ' . $e->getMessage());
        $rows = [];
    }

    foreach ($rows as $row) {
        $stationId = (int) ($row['station_id'] ?? 0);
        if ($stationId <= 0) {
            continue;
        }

        $rate = termAdminCreditRateValue($row['credit_rate'] ?? null);
        $credits = (int) ($row['credits_balance'] ?? 0);
        $in = (float) ($row['money_in_total'] ?? 0);
        $out = (float) ($row['money_out_total'] ?? 0);
        $creditsMoney = round($credits * $rate, 2);
        $netProfit = round(($in - $out) - $creditsMoney, 2);

        $terminalsByStation[$stationId][] = [
            'id' => (int) $row['id'],
            'name' => (string) ($row['name'] ?? ''),
            'code' => (string) ($row['terminal_code'] ?? ''),
            'status' => (string) ($row['status'] ?? 'offline'),
            'active' => (int) ($row['is_active'] ?? 0) === 1,
            'credits' => $credits,
            'in' => termFormatMoney($in),
            'out' => termFormatMoney($out),
            'profit' => termAdminFormatProfit($netProfit),
            'profit_class' => termAdminProfitClass($netProfit),
            'heartbeat' => termFormatDateTime($row['last_heartbeat_at'] ?? null),
        ];
    }

    $stationIds = array_values(array_filter(array_map(
        static fn(array $station): int => (int) ($station['id'] ?? 0),
        $stations
    )));
    $operatorsByStation = termAdminStationOperatorsByStation($stationIds);

    $markers = [];
    $unmapped = [];

    foreach ($stations as $station) {
        $stationId = (int) ($station['id'] ?? 0);
        $location = trim((string) ($station['location'] ?? ''));
        $coords = null;
        $dbLat = $station['latitude'] ?? null;
        $dbLng = $station['longitude'] ?? null;

        if ($dbLat !== null && $dbLng !== null && ((float) $dbLat !== 0.0 || (float) $dbLng !== 0.0)) {
            $coords = ['lat' => (float) $dbLat, 'lng' => (float) $dbLng];
        } elseif ($location !== '') {
            $coords = termStationEnsureCoordinates($stationId);
            if ($coords === null) {
                $coords = termGeocodeAddress($location);
            }
        }

        $terminals = $terminalsByStation[$stationId] ?? [];

        if ($coords === null) {
            $unmapped[] = [
                'id' => $stationId,
                'name' => (string) ($station['name'] ?? ''),
                'code' => (string) ($station['code'] ?? ''),
                'location' => $location,
                'terminals' => count($terminals),
            ];
            continue;
        }

        $online = 0;
        $blocked = 0;
        foreach ($terminals as $terminalEntry) {
            if (($terminalEntry['status'] ?? '') === 'online') {
                $online++;
            }
            if (($terminalEntry['status'] ?? '') === 'blocked') {
                $blocked++;
            }
        }

        $operatorNames = $operatorsByStation[$stationId] ?? [];
        $markers[] = [
            'station_id' => $stationId,
            'name' => (string) ($station['name'] ?? ''),
            'code' => (string) ($station['code'] ?? ''),
            'location' => $location,
            'manager' => (string) ($station['manager_name'] ?? ''),
            'operator' => implode(', ', $operatorNames),
            'active' => (int) ($station['is_active'] ?? 0) === 1,
            'lat' => $coords['lat'],
            'lng' => $coords['lng'],
            'online' => $online,
            'total' => count($terminals),
            'terminals_total' => (int) ($station['terminals_count'] ?? count($terminals)),
            'blocked' => $blocked,
            'terminals' => $terminals,
        ];
    }

    return [
        'markers' => $markers,
        'unmapped' => $unmapped,
        'center' => ['lat' => 45.9432, 'lng' => 24.9668],
        'zoom' => 7,
    ];
}
