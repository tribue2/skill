<?php

declare(strict_types=1);

/**
 * Minimal WebAuthn helpers: base64url, CBOR (subset), attestation/assertion verify (ES256/RS256).
 */
final class IqwinWebAuthnCrypto
{
    public static function b64uEncode(string $bin): string
    {
        return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
    }

    public static function b64uDecode(string $b64): string
    {
        $b64 = strtr($b64, '-_', '+/');
        $pad = strlen($b64) % 4;
        if ($pad > 0) {
            $b64 .= str_repeat('=', 4 - $pad);
        }
        $out = base64_decode($b64, true);
        if ($out === false) {
            throw new InvalidArgumentException('base64 invalid');
        }

        return $out;
    }

    public static function expectedOrigin(): string
    {
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || ((int) ($_SERVER['SERVER_PORT'] ?? 0) === 443);
        $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');

        return ($https ? 'https' : 'http') . '://' . $host;
    }

    public static function rpId(): string
    {
        $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
        $host = preg_replace('/:\d+$/', '', $host) ?? $host;

        return strtolower($host);
    }

    /** @return array{type:string,challenge:string,origin:string} */
    public static function parseClientDataJson(string $clientDataJsonBin, string $expectedType, string $expectedChallengeB64u): array
    {
        $json = json_decode($clientDataJsonBin, true);
        if (!is_array($json)) {
            throw new RuntimeException('clientDataJSON invalid');
        }
        $type = (string) ($json['type'] ?? '');
        if ($type !== $expectedType) {
            throw new RuntimeException('tip WebAuthn invalid');
        }
        $challenge = (string) ($json['challenge'] ?? '');
        if ($challenge === '' || !hash_equals($expectedChallengeB64u, $challenge)) {
            throw new RuntimeException('challenge invalid');
        }
        $origin = (string) ($json['origin'] ?? '');
        $expectedOrigin = self::expectedOrigin();
        if ($origin === '' || !hash_equals($expectedOrigin, $origin)) {
            throw new RuntimeException('origin invalid');
        }

        return [
            'type' => $type,
            'challenge' => $challenge,
            'origin' => $origin,
        ];
    }

    /**
     * @return array{credentialId:string,publicKeyPem:string,signCount:int,flags:int}
     */
    public static function parseAttestation(string $attestationObjectBin, string $clientDataJsonBin): array
    {
        $obj = self::cborDecode($attestationObjectBin);
        if (!is_array($obj) || !isset($obj['authData']) || !is_string($obj['authData'])) {
            throw new RuntimeException('attestationObject invalid');
        }
        $auth = self::parseAuthData($obj['authData'], true);
        if ($auth['credentialId'] === '' || $auth['publicKeyPem'] === '') {
            throw new RuntimeException('credential public key lipsește');
        }
        $rpHash = substr($obj['authData'], 0, 32);
        if (!hash_equals(hash('sha256', self::rpId(), true), $rpHash)) {
            throw new RuntimeException('rpId invalid');
        }
        // clientData already checked by caller; keep hash available for packed attestation (unused for none)
        unset($clientDataJsonBin);

        return [
            'credentialId' => self::b64uEncode($auth['credentialIdBin']),
            'publicKeyPem' => $auth['publicKeyPem'],
            'signCount' => $auth['signCount'],
            'flags' => $auth['flags'],
        ];
    }

    /**
     * @return array{ok:bool,signCount:int}
     */
    public static function verifyAssertion(
        string $publicKeyPem,
        string $authenticatorDataBin,
        string $clientDataJsonBin,
        string $signatureBin,
        int $previousSignCount
    ): array {
        $rpHash = substr($authenticatorDataBin, 0, 32);
        if (strlen($authenticatorDataBin) < 37 || !hash_equals(hash('sha256', self::rpId(), true), $rpHash)) {
            throw new RuntimeException('rpId invalid');
        }
        $flags = ord($authenticatorDataBin[32]);
        if (($flags & 0x01) !== 0x01) {
            throw new RuntimeException('user present lipsește');
        }
        if (($flags & 0x04) !== 0x04) {
            throw new RuntimeException('user verified lipsește');
        }
        $signCount = unpack('N', substr($authenticatorDataBin, 33, 4))[1];
        if ($previousSignCount > 0 && $signCount > 0 && $signCount <= $previousSignCount) {
            throw new RuntimeException('signCount invalid');
        }

        $clientHash = hash('sha256', $clientDataJsonBin, true);
        $data = $authenticatorDataBin . $clientHash;

        $ok = openssl_verify($data, $signatureBin, $publicKeyPem, OPENSSL_ALGO_SHA256);
        if ($ok !== 1) {
            // Some authenticators send raw P-1363 ECDSA; convert to DER and retry.
            $der = self::p1363ToDer($signatureBin);
            if ($der !== null) {
                $ok = openssl_verify($data, $der, $publicKeyPem, OPENSSL_ALGO_SHA256);
            }
        }
        if ($ok !== 1) {
            throw new RuntimeException('semnătură invalidă');
        }

        return ['ok' => true, 'signCount' => $signCount];
    }

    /**
     * @return array{credentialIdBin:string,credentialId:string,publicKeyPem:string,signCount:int,flags:int}
     */
    private static function parseAuthData(string $authData, bool $requireAttested): array
    {
        if (strlen($authData) < 37) {
            throw new RuntimeException('authenticatorData scurt');
        }
        $flags = ord($authData[32]);
        $signCount = unpack('N', substr($authData, 33, 4))[1];
        $offset = 37;
        $credIdBin = '';
        $pem = '';

        $hasAttested = ($flags & 0x40) === 0x40;
        if ($requireAttested && !$hasAttested) {
            throw new RuntimeException('attestedCredentialData lipsește');
        }
        if ($hasAttested) {
            if (strlen($authData) < $offset + 18) {
                throw new RuntimeException('attestedCredentialData scurt');
            }
            $offset += 16; // aaguid
            $credLen = unpack('n', substr($authData, $offset, 2))[1];
            $offset += 2;
            $credIdBin = substr($authData, $offset, $credLen);
            $offset += $credLen;
            $coseBin = substr($authData, $offset);
            $pem = self::coseToPem($coseBin);
        }

        return [
            'credentialIdBin' => $credIdBin,
            'credentialId' => $credIdBin !== '' ? self::b64uEncode($credIdBin) : '',
            'publicKeyPem' => $pem,
            'signCount' => $signCount,
            'flags' => $flags,
        ];
    }

    private static function coseToPem(string $coseBin): string
    {
        $map = self::cborDecode($coseBin);
        if (!is_array($map)) {
            throw new RuntimeException('COSE invalid');
        }
        $kty = $map[1] ?? null;
        $alg = $map[3] ?? null;

        if ((int) $kty === 2) {
            // EC2
            $crv = (int) ($map[-1] ?? 0);
            $x = $map[-2] ?? null;
            $y = $map[-3] ?? null;
            if ($crv !== 1 || !is_string($x) || !is_string($y) || strlen($x) !== 32 || strlen($y) !== 32) {
                throw new RuntimeException('cheie EC P-256 invalidă');
            }
            $uncompressed = "\x04" . $x . $y;
            $der = hex2bin(
                '3059301306072a8648ce3d020106082a8648ce3d030107034200'
            ) . $uncompressed;
            if ($der === false) {
                throw new RuntimeException('DER EC eșuat');
            }

            return "-----BEGIN PUBLIC KEY-----\n"
                . chunk_split(base64_encode($der), 64, "\n")
                . "-----END PUBLIC KEY-----\n";
        }

        if ((int) $kty === 3) {
            // RSA
            $n = $map[-1] ?? null;
            $e = $map[-2] ?? null;
            if (!is_string($n) || !is_string($e) || $n === '' || $e === '') {
                throw new RuntimeException('cheie RSA invalidă');
            }
            $pem = self::rsaPublicPem($n, $e);
            unset($alg);

            return $pem;
        }

        throw new RuntimeException('tip cheie WebAuthn nesuportat');
    }

    private static function rsaPublicPem(string $n, string $e): string
    {
        $encodeInt = static function (string $bin): string {
            if ($bin !== '' && (ord($bin[0]) & 0x80) !== 0) {
                $bin = "\x00" . $bin;
            }

            return "\x02" . self::derLen(strlen($bin)) . $bin;
        };
        $mod = $encodeInt($n);
        $exp = $encodeInt($e);
        $seq = "\x30" . self::derLen(strlen($mod . $exp)) . $mod . $exp;
        $algo = hex2bin('300d06092a864886f70d0101010500');
        if ($algo === false) {
            throw new RuntimeException('RSA OID eșuat');
        }
        $bitstr = "\x03" . self::derLen(strlen($seq) + 1) . "\x00" . $seq;
        $spki = "\x30" . self::derLen(strlen($algo . $bitstr)) . $algo . $bitstr;

        return "-----BEGIN PUBLIC KEY-----\n"
            . chunk_split(base64_encode($spki), 64, "\n")
            . "-----END PUBLIC KEY-----\n";
    }

    private static function derLen(int $len): string
    {
        if ($len < 0x80) {
            return chr($len);
        }
        if ($len < 0x100) {
            return "\x81" . chr($len);
        }

        return "\x82" . pack('n', $len);
    }

    private static function p1363ToDer(string $sig): ?string
    {
        $len = strlen($sig);
        if ($len !== 64 && $len !== 96) {
            return null;
        }
        $half = intdiv($len, 2);
        $r = ltrim(substr($sig, 0, $half), "\x00");
        $s = ltrim(substr($sig, $half), "\x00");
        if ($r === '') {
            $r = "\x00";
        }
        if ($s === '') {
            $s = "\x00";
        }
        if ((ord($r[0]) & 0x80) !== 0) {
            $r = "\x00" . $r;
        }
        if ((ord($s[0]) & 0x80) !== 0) {
            $s = "\x00" . $s;
        }
        $rEnc = "\x02" . chr(strlen($r)) . $r;
        $sEnc = "\x02" . chr(strlen($s)) . $s;

        return "\x30" . chr(strlen($rEnc . $sEnc)) . $rEnc . $sEnc;
    }

    /** @return mixed */
    public static function cborDecode(string $bin)
    {
        $offset = 0;
        $value = self::cborRead($bin, $offset);
        return $value;
    }

    /** @return mixed */
    private static function cborRead(string $bin, int &$offset)
    {
        if ($offset >= strlen($bin)) {
            throw new RuntimeException('CBOR truncated');
        }
        $ib = ord($bin[$offset]);
        $offset++;
        $major = $ib >> 5;
        $ai = $ib & 0x1f;
        $val = self::cborAi($bin, $offset, $ai);

        switch ($major) {
            case 0:
                return $val;
            case 1:
                return -1 - $val;
            case 2:
                $out = substr($bin, $offset, $val);
                $offset += $val;
                return $out;
            case 3:
                $out = substr($bin, $offset, $val);
                $offset += $val;
                return $out;
            case 4:
                $arr = [];
                for ($i = 0; $i < $val; $i++) {
                    $arr[] = self::cborRead($bin, $offset);
                }
                return $arr;
            case 5:
                $map = [];
                for ($i = 0; $i < $val; $i++) {
                    $k = self::cborRead($bin, $offset);
                    $v = self::cborRead($bin, $offset);
                    if (is_int($k) || is_string($k)) {
                        $map[$k] = $v;
                    }
                }
                return $map;
            case 6:
                return self::cborRead($bin, $offset);
            case 7:
                if ($ai === 20) {
                    return false;
                }
                if ($ai === 21) {
                    return true;
                }
                if ($ai === 22 || $ai === 23) {
                    return null;
                }
                throw new RuntimeException('CBOR simple nesuportat');
            default:
                throw new RuntimeException('CBOR major nesuportat');
        }
    }

    private static function cborAi(string $bin, int &$offset, int $ai): int
    {
        if ($ai < 24) {
            return $ai;
        }
        if ($ai === 24) {
            $v = ord($bin[$offset]);
            $offset++;
            return $v;
        }
        if ($ai === 25) {
            $v = unpack('n', substr($bin, $offset, 2))[1];
            $offset += 2;
            return $v;
        }
        if ($ai === 26) {
            $v = unpack('N', substr($bin, $offset, 4))[1];
            $offset += 4;
            return $v;
        }
        throw new RuntimeException('CBOR length nesuportat');
    }
}
