<?php

if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}
@ini_set('default_charset', 'UTF-8');

function termRoNormalize(string $value): string
{
    $value = termRoFixIncomingText(trim($value));
    if ($value === '') {
        return '';
    }
    $value = mb_strtolower($value, 'UTF-8');
    $map = [
        "\u{0103}" => 'a', "\u{00E2}" => 'a', "\u{00EE}" => 'i', "\u{0219}" => 's', "\u{015F}" => 's', "\u{021B}" => 't', "\u{0163}" => 't',
        "\u{0102}" => 'a', "\u{00C2}" => 'a', "\u{00CE}" => 'i', "\u{0218}" => 's', "\u{015E}" => 's', "\u{021A}" => 't', "\u{0162}" => 't',
        '?' => '', "\u{FFFD}" => '',
    ];
    $value = strtr($value, $map);
    $value = preg_replace('/[^a-z0-9\s\-]/', '', $value) ?? $value;
    $value = preg_replace('/\s+/', ' ', $value) ?? $value;
    return trim($value);
}

function termRoFixIncomingText(string $value): string
{
    if ($value === '') {
        return '';
    }

    if (!mb_check_encoding($value, 'UTF-8')) {
        $converted = @mb_convert_encoding($value, 'UTF-8', 'Windows-1250, ISO-8859-2, Windows-1252, ISO-8859-1');
        if (is_string($converted) && $converted !== '') {
            return $converted;
        }
    }

    return $value;
}

function termRoCanonicalCounty(string $value): string
{
    $norm = termRoNormalize($value);
    if ($norm === '') {
        return '';
    }

    foreach (termRoCounties() as $county) {
        $countyNorm = termRoNormalize($county);
        if ($countyNorm === $norm) {
            return $county;
        }
    }

    foreach (termRoCounties() as $county) {
        $countyNorm = termRoNormalize($county);
        if ($countyNorm !== '' && (str_contains($norm, $countyNorm) || str_contains($countyNorm, $norm))) {
            return $county;
        }
    }

    $compact = str_replace(['s', 't', '-', ' '], '', $norm);
    foreach (termRoCounties() as $county) {
        $countyCompact = str_replace(['s', 't', '-', ' '], '', termRoNormalize($county));
        if ($countyCompact !== '' && $countyCompact === $compact) {
            return $county;
        }
    }

    return '';
}

function termRoCanonicalCity(string $value, string $county = ''): string
{
    $norm = termRoNormalize($value);
    if ($norm === '') {
        return '';
    }

    $citiesMap = termRoCitiesByCounty();
    $pool = [];
    if ($county !== '' && isset($citiesMap[$county])) {
        $pool = $citiesMap[$county];
    } else {
        foreach ($citiesMap as $list) {
            foreach ($list as $city) {
                $pool[] = $city;
            }
        }
    }

    usort($pool, static fn($a, $b) => mb_strlen((string) $b) <=> mb_strlen((string) $a));

    foreach ($pool as $city) {
        if (termRoNormalize($city) === $norm) {
            return $city;
        }
    }

    foreach ($pool as $city) {
        $cityNorm = termRoNormalize($city);
        if ($cityNorm !== '' && (str_contains($norm, $cityNorm) || str_contains($cityNorm, $norm))) {
            return $city;
        }
    }

    $compact = str_replace(['s', 't', '-', ' '], '', $norm);
    foreach ($pool as $city) {
        $cityCompact = str_replace(['s', 't', '-', ' '], '', termRoNormalize($city));
        if ($cityCompact !== '' && $cityCompact === $compact) {
            return $city;
        }
    }

    if (str_contains($norm, 'cluj')) {
        return 'Cluj-Napoca';
    }
    if (str_contains($norm, 'bucurest') || str_contains($norm, 'bucharest') || str_contains($norm, 'bucuret')) {
        return "Bucure\u{0219}ti";
    }

    return '';
}

function termRoCounties(): array
{
    return [
        'Alba',
        'Arad',
        "Arge\u{0219}",
        "Bac\u{0103}u",
        'Bihor',
        "Bistri\u{021B}a-N\u{0103}s\u{0103}ud",
        "Boto\u{0219}ani",
        "Bra\u{0219}ov",
        "Br\u{0103}ila",
        "Bucure\u{0219}ti",
        "Buz\u{0103}u",
        "Cara\u{0219}-Severin",
        "C\u{0103}l\u{0103}ra\u{0219}i",
        'Cluj',
        "Constan\u{021B}a",
        'Covasna',
        "D\u{00E2}mbovi\u{021B}a",
        'Dolj',
        "Gala\u{021B}i",
        'Giurgiu',
        'Gorj',
        'Harghita',
        'Hunedoara',
        "Ialomi\u{021B}a",
        "Ia\u{0219}i",
        'Ilfov',
        "Maramure\u{0219}",
        "Mehedin\u{021B}i",
        "Mure\u{0219}",
        "Neam\u{021B}",
        'Olt',
        'Prahova',
        'Satu Mare',
        "S\u{0103}laj",
        'Sibiu',
        'Suceava',
        'Teleorman',
        "Timi\u{0219}",
        'Tulcea',
        'Vaslui',
        "V\u{00E2}lcea",
        'Vrancea',
    ];
}

function termRoCitiesByCounty(): array
{
    static $cache = null;
    if (is_array($cache)) {
        return $cache;
    }

    $path = __DIR__ . '/data/romania-localitati.json';
    if (is_file($path)) {
        $raw = @file_get_contents($path);
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded) && $decoded !== []) {
                $cache = $decoded;
                return $cache;
            }
        }
    }

    // Fallback minimal (doar dacă lipsește fișierul SIRUTA).
    $cache = [
        'Alba' => ['Alba Iulia', 'Aiud', 'Blaj', "Sebe\u{0219}", 'Cugir'],
        'Arad' => ['Arad', 'Lipova', 'Ineu', 'Pecica'],
        "Arge\u{0219}" => ["Pite\u{0219}ti", "C\u{00E2}mpulung", "Curtea de Arge\u{0219}", 'Mioveni'],
        "Bac\u{0103}u" => ["Bac\u{0103}u", "One\u{0219}ti", "Moine\u{0219}ti", "Com\u{0103}ne\u{0219}ti"],
        'Bihor' => ['Oradea', 'Salonta', "Beiu\u{0219}", 'Marghita'],
        "Bistri\u{021B}a-N\u{0103}s\u{0103}ud" => ["Bistri\u{021B}a", "N\u{0103}s\u{0103}ud", 'Beclean'],
        "Boto\u{0219}ani" => ["Boto\u{0219}ani", 'Dorohoi', "S\u{0103}veni"],
        "Bra\u{0219}ov" => ["Bra\u{0219}ov", "F\u{0103}g\u{0103}ra\u{0219}", "S\u{0103}cele", "R\u{00E2}\u{0219}nov", "Z\u{0103}rne\u{0219}ti"],
        "Br\u{0103}ila" => ["Br\u{0103}ila", 'Ianca'],
        "Bucure\u{0219}ti" => ["Bucure\u{0219}ti", 'Sector 1', 'Sector 2', 'Sector 3', 'Sector 4', 'Sector 5', 'Sector 6'],
        "Buz\u{0103}u" => ["Buz\u{0103}u", "R\u{00E2}mnicu S\u{0103}rat"],
        "Cara\u{0219}-Severin" => ["Re\u{0219}i\u{021B}a", "Caransebe\u{0219}", "Oravi\u{021B}a"],
        "C\u{0103}l\u{0103}ra\u{0219}i" => ["C\u{0103}l\u{0103}ra\u{0219}i", "Olteni\u{021B}a"],
        'Cluj' => ['Cluj-Napoca', 'Turda', 'Dej', "C\u{00E2}mpia Turzii", 'Gherla'],
        "Constan\u{021B}a" => ["Constan\u{021B}a", 'Mangalia', 'Medgidia', "N\u{0103}vodari", "Cernavod\u{0103}"],
        'Covasna' => ["Sf\u{00E2}ntu Gheorghe", "T\u{00E2}rgu Secuiesc"],
        "D\u{00E2}mbovi\u{021B}a" => ["T\u{00E2}rgovi\u{0219}te", 'Moreni', 'Pucioasa'],
        'Dolj' => ['Craiova', "B\u{0103}ile\u{0219}ti", 'Calafat', "Filia\u{0219}i"],
        "Gala\u{021B}i" => ["Gala\u{021B}i", 'Tecuci'],
        'Giurgiu' => ['Giurgiu'],
        'Gorj' => ["T\u{00E2}rgu Jiu", 'Motru', 'Rovinari'],
        'Harghita' => ['Miercurea Ciuc', 'Odorheiu Secuiesc', 'Gheorgheni', "Topli\u{021B}a"],
        'Hunedoara' => ['Deva', 'Hunedoara', "Petro\u{0219}ani", "Or\u{0103}\u{0219}tie", 'Lupeni'],
        "Ialomi\u{021B}a" => ['Slobozia', "Fete\u{0219}ti", 'Urziceni'],
        "Ia\u{0219}i" => ["Ia\u{0219}i", "Pa\u{0219}cani", "H\u{00E2}rl\u{0103}u"],
        'Ilfov' => ['Buftea', 'Voluntari', 'Otopeni', 'Pantelimon', "Pope\u{0219}ti-Leordeni", 'Chiajna'],
        "Maramure\u{0219}" => ['Baia Mare', "Sighetu Marma\u{021B}iei", "Bor\u{0219}a"],
        "Mehedin\u{021B}i" => ['Drobeta-Turnu Severin', "Or\u{0219}ova"],
        "Mure\u{0219}" => ["T\u{00E2}rgu Mure\u{0219}", 'Reghin', "Sighi\u{0219}oara", "T\u{00E2}rn\u{0103}veni"],
        "Neam\u{021B}" => ["Piatra Neam\u{021B}", 'Roman', "T\u{00E2}rgu Neam\u{021B}"],
        'Olt' => ['Slatina', 'Caracal', "Bal\u{0219}"],
        'Prahova' => ["Ploie\u{0219}ti", "C\u{00E2}mpina", 'Sinaia', "Bu\u{0219}teni", 'Azuga'],
        'Satu Mare' => ['Satu Mare', 'Carei', "Negre\u{0219}ti-Oa\u{0219}"],
        "S\u{0103}laj" => ["Zal\u{0103}u", "\u{0218}imleu Silvaniei"],
        'Sibiu' => ['Sibiu', "Media\u{0219}", "Cisn\u{0103}die", 'Avrig'],
        'Suceava' => ['Suceava', "F\u{0103}lticeni", "R\u{0103}d\u{0103}u\u{021B}i", "C\u{00E2}mpulung Moldovenesc", 'Vatra Dornei'],
        'Teleorman' => ['Alexandria', "Ro\u{0219}iorii de Vede", "Turnu M\u{0103}gurele"],
        "Timi\u{0219}" => ["Timi\u{0219}oara", 'Lugoj', "S\u{00E2}nnicolau Mare"],
        'Tulcea' => ['Tulcea', "M\u{0103}cin"],
        'Vaslui' => ['Vaslui', "B\u{00E2}rlad", "Hu\u{0219}i"],
        "V\u{00E2}lcea" => ["R\u{00E2}mnicu V\u{00E2}lcea", "Dr\u{0103}g\u{0103}\u{0219}ani", "B\u{0103}ile Ol\u{0103}ne\u{0219}ti"],
        'Vrancea' => ["Foc\u{0219}ani", 'Adjud'],
    ];

    return $cache;
}

function termRoCitiesJsonForScript(): string
{
    $path = __DIR__ . '/data/romania-localitati.json';
    if (is_file($path)) {
        $raw = @file_get_contents($path);
        if (is_string($raw) && $raw !== '' && json_decode($raw, true) !== null) {
            return $raw;
        }
    }

    return json_encode(termRoCitiesByCounty(), JSON_UNESCAPED_UNICODE);
}

function termRoDetectCounty(string $text): string
{
    return termRoCanonicalCounty($text);
}

function termRoDetectCity(string $text, string $county = ''): string
{
    $direct = termRoCanonicalCity($text, $county);
    if ($direct !== '') {
        return $direct;
    }

    $norm = termRoNormalize($text);
    if ($norm === '') {
        return '';
    }

    $citiesMap = termRoCitiesByCounty();
    $pool = [];
    if ($county !== '' && isset($citiesMap[$county])) {
        $pool = $citiesMap[$county];
    } else {
        foreach ($citiesMap as $list) {
            foreach ($list as $city) {
                $pool[] = $city;
            }
        }
    }

    usort($pool, static fn($a, $b) => mb_strlen((string) $b) <=> mb_strlen((string) $a));
    foreach ($pool as $city) {
        $cityNorm = termRoNormalize($city);
        if ($cityNorm !== '' && str_contains($norm, $cityNorm)) {
            return $city;
        }
    }

    return termRoCanonicalCity($text, $county);
}

function termRoCountyForCity(string $city): string
{
    $cityNorm = termRoNormalize($city);
    if ($cityNorm === '') {
        return '';
    }
    foreach (termRoCitiesByCounty() as $county => $cities) {
        foreach ($cities as $item) {
            if (termRoNormalize($item) === $cityNorm) {
                return $county;
            }
        }
    }
    return '';
}

function termStationEnsureLocationColumns(): void
{
    static $ready = false;
    if ($ready) {
        return;
    }

    $db = getDB();

    try {
        $table = $db->fetchOne(
            "SELECT TABLE_COLLATION AS collation_name
             FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'stations'
             LIMIT 1"
        );
        $tableCollation = strtolower((string) ($table['collation_name'] ?? ''));
        if ($tableCollation === '' || !str_starts_with($tableCollation, 'utf8mb4_')) {
            $db->query('ALTER TABLE stations CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        }
    } catch (Throwable $e) {
    }

    $ensureUtf8Column = static function (string $column, string $definition) use ($db): void {
        $info = $db->fetchOne(
            "SELECT CHARACTER_SET_NAME AS charset_name, COLLATION_NAME AS collation_name
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'stations'
               AND COLUMN_NAME = ?
             LIMIT 1",
            [$column]
        );

        if (!$info) {
            $db->query('ALTER TABLE stations ADD COLUMN ' . $definition);
            return;
        }

        $charset = strtolower((string) ($info['charset_name'] ?? ''));
        $collation = strtolower((string) ($info['collation_name'] ?? ''));
        if ($charset === 'utf8mb4' && str_starts_with($collation, 'utf8mb4_')) {
            return;
        }

        $db->query('ALTER TABLE stations MODIFY COLUMN ' . $definition);
    };

    try {
        $ensureUtf8Column(
            'judet',
            'judet varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL AFTER location'
        );
        $ensureUtf8Column(
            'localitate',
            'localitate varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL AFTER judet'
        );
        $ensureUtf8Column(
            'location',
            'location varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL'
        );
    } catch (Throwable $e) {
    }

    $rows = $db->fetchAll(
        "SELECT id, name, location, judet, localitate
         FROM stations
         WHERE (judet IS NULL OR judet = '' OR localitate IS NULL OR localitate = '' OR judet LIKE '%?%' OR localitate LIKE '%?%' OR name LIKE '%?%' OR location LIKE '%?%')
         LIMIT 500"
    );
    foreach ($rows as $row) {
        $blob = trim((string) ($row['name'] ?? '') . ' ' . (string) ($row['location'] ?? '') . ' ' . (string) ($row['judet'] ?? '') . ' ' . (string) ($row['localitate'] ?? ''));
        $judetValue = termRoCanonicalCounty((string) ($row['judet'] ?? ''));
        if ($judetValue === '') {
            $judetValue = termRoDetectCounty($blob);
        }
        $localitateValue = termRoCanonicalCity((string) ($row['localitate'] ?? ''), $judetValue);
        if ($localitateValue === '') {
            $localitateValue = termRoDetectCity($blob, $judetValue);
        }
        if ($judetValue === '' && $localitateValue !== '') {
            $judetValue = termRoCountyForCity($localitateValue);
        }
        if ($judetValue === '' && $localitateValue === '') {
            continue;
        }
        termStationSaveLocationFields(
            (int) $row['id'],
            $judetValue !== '' ? $judetValue : null,
            $localitateValue !== '' ? $localitateValue : null,
            null,
            false
        );
    }

    $ready = true;
}

function termStationSaveLocationFields(int $stationId, ?string $judet, ?string $localitate, ?string $location = null, bool $touchLocation = true): void
{
    if ($stationId <= 0) {
        return;
    }

    $judetValue = trim((string) ($judet ?? ''));
    $localitateValue = trim((string) ($localitate ?? ''));
    $locationValue = trim((string) ($location ?? ''));

    $pdo = getDB()->getConnection();
    try {
        $pdo->exec('SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci');
    } catch (Throwable $e) {
    }

    $sets = [
        'judet = IF(:has_judet = 0, NULL, CONVERT(FROM_BASE64(:judet_b64) USING utf8mb4))',
        'localitate = IF(:has_localitate = 0, NULL, CONVERT(FROM_BASE64(:localitate_b64) USING utf8mb4))',
    ];
    $params = [
        ':has_judet' => $judetValue !== '' ? 1 : 0,
        ':judet_b64' => base64_encode($judetValue),
        ':has_localitate' => $localitateValue !== '' ? 1 : 0,
        ':localitate_b64' => base64_encode($localitateValue),
        ':id' => $stationId,
    ];

    if ($touchLocation) {
        $sets[] = 'location = IF(:has_location = 0, NULL, CONVERT(FROM_BASE64(:location_b64) USING utf8mb4))';
        $params[':has_location'] = $locationValue !== '' ? 1 : 0;
        $params[':location_b64'] = base64_encode($locationValue);
    }

    $sql = 'UPDATE stations SET ' . implode(', ', $sets) . ' WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
}

function termStationNormalizeLocationInput(?string $judet, ?string $localitate, ?string $location = null): array
{
    $rawJudet = termRoFixIncomingText(trim((string) $judet));
    $rawLocalitate = termRoFixIncomingText(trim((string) $localitate));
    $street = termRoFixIncomingText(trim((string) $location));

    $canonicalJudet = termRoCanonicalCounty($rawJudet);
    if ($canonicalJudet === '') {
        $canonicalJudet = termRoDetectCounty($rawJudet . ' ' . $rawLocalitate . ' ' . $street);
    }

    $canonicalLocalitate = termRoCanonicalCity($rawLocalitate, $canonicalJudet);
    if ($canonicalLocalitate === '') {
        $canonicalLocalitate = termRoDetectCity($rawLocalitate . ' ' . $street, $canonicalJudet);
    }

    if ($canonicalJudet === '' && $canonicalLocalitate !== '') {
        $canonicalJudet = termRoCountyForCity($canonicalLocalitate);
    }

    return [
        'judet' => $canonicalJudet,
        'localitate' => $canonicalLocalitate,
        'location' => $street,
    ];
}

function termStationDisplayCounty(?string $value): string
{
    $raw = trim((string) $value);
    if ($raw === '') {
        return '';
    }
    $canonical = termRoCanonicalCounty($raw);
    return $canonical !== '' ? $canonical : $raw;
}

function termStationDisplayCity(?string $value, ?string $county = null): string
{
    $raw = trim((string) $value);
    if ($raw === '') {
        return '';
    }
    $canonicalCounty = termStationDisplayCounty((string) $county);
    $canonical = termRoCanonicalCity($raw, $canonicalCounty);
    return $canonical !== '' ? $canonical : $raw;
}

function termStationBuildGeoAddress(?string $judet, ?string $localitate, ?string $location): string
{
    $parts = [];
    $street = trim((string) $location);
    $city = trim((string) $localitate);
    $county = trim((string) $judet);
    if ($street !== '') {
        $parts[] = $street;
    }
    if ($city !== '' && ($street === '' || mb_stripos($street, $city) === false)) {
        $parts[] = $city;
    }
    if ($county !== '' && ($street === '' || mb_stripos($street, $county) === false)) {
        $parts[] = 'judetul ' . $county;
    }
    $parts[] = 'Romania';
    return implode(', ', array_values(array_unique($parts)));
}
