<?php

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/report_period_compat.php';

if (!function_exists('termCanViewTerminals')) {
    function termCanViewTerminals(string $role): bool
    {
        return termCanManageTerminals($role) || $role === 'statie';
    }
}

if (!function_exists('termCanViewStationsMap')) {
    function termCanViewStationsMap(string $role): bool
    {
        return in_array($role, ['boss', 'colaborator', 'manager'], true);
    }
}

if (!function_exists('termAdminCanViewUser')) {
    function termAdminCanViewUser(array $viewer, array $target): bool
    {
        $viewerRole = $viewer['role'] ?? '';
        $targetRole = $target['role'] ?? '';
        $viewerId = (int) ($viewer['id'] ?? 0);
        $targetId = (int) ($target['id'] ?? 0);

        if ($viewerId <= 0 || $targetId <= 0) {
            return false;
        }

        if ($viewerRole === 'boss') {
            return true;
        }

        if ($viewerRole === 'colaborator') {
            return $targetRole !== 'boss';
        }

        if ($viewerRole === 'manager') {
            if ($viewerId === $targetId) {
                return true;
            }

            return in_array($targetRole, ['statie', 'desfasurator'], true)
                && (int) ($target['created_by'] ?? 0) === $viewerId;
        }

        return false;
    }
}

function termAdminStartSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');

    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        ini_set('session.cookie_secure', '1');
    }

    session_name('skill_terminal_admin');
    session_start();
}

function termAdminCsrfToken(): string
{
    if (empty($_SESSION['term_admin_csrf'])) {
        $_SESSION['term_admin_csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['term_admin_csrf'];
}

function termAdminVerifyCsrf(?string $token): bool
{
    $sessionToken = $_SESSION['term_admin_csrf'] ?? '';
    return is_string($token) && $token !== '' && hash_equals($sessionToken, $token);
}

function termAdminCurrent(): ?array
{
    $userId = (int) ($_SESSION['term_admin_user_id'] ?? 0);
    if ($userId <= 0) {
        return null;
    }

    try {
        $user = getDB()->fetchOne(
            'SELECT id, username, display_name, email, role, is_active, last_login_at FROM users WHERE id = ? LIMIT 1',
            [$userId]
        );

        if (!$user || !(int) $user['is_active']) {
            return null;
        }

        return $user;
    } catch (Exception $e) {
        return null;
    }
}

function termAdminRequireLogin(): array
{
    $user = termAdminCurrent();
    if ($user === null) {
        header('Location: login.php');
        exit;
    }

    if (($user['role'] ?? '') === 'casier') {
        termAdminLogout();
        header('Location: login.php');
        exit;
    }

    return $user;
}

function termAdminRequireRole(array $roles): array
{
    $user = termAdminRequireLogin();
    if (!in_array($user['role'], $roles, true)) {
        http_response_code(403);
        exit('Acces interzis.');
    }

    return $user;
}

function termAdminRedirectIfLoggedIn(): void
{
    if (termAdminCurrent() !== null) {
        header('Location: index.php');
        exit;
    }
}

function termAdminAttemptLogin(string $username, string $password): array
{
    $username = trim($username);
    $password = trim($password);

    if ($username === '' || $password === '') {
        return ['ok' => false, 'error' => 'invalid'];
    }

    try {
        $user = getDB()->fetchOne(
            'SELECT id, username, password_hash, display_name, role, is_active FROM users WHERE username = ? LIMIT 1',
            [$username]
        );
    } catch (Exception $e) {
        return ['ok' => false, 'error' => 'db'];
    }

    if (!$user || !(int) $user['is_active']) {
        return ['ok' => false, 'error' => 'invalid'];
    }

    if (($user['role'] ?? '') === 'casier') {
        return ['ok' => false, 'error' => 'invalid'];
    }

    $storedHash = trim((string) ($user['password_hash'] ?? ''));
    if ($storedHash === '' || !password_verify($password, $storedHash)) {
        return ['ok' => false, 'error' => 'invalid'];
    }

    termAdminEstablishSession($user);

    return ['ok' => true];
}

/**
 * @param array{id:int|string,username:string,role:string} $user
 */
function termAdminEstablishSession(array $user): void
{
    try {
        session_regenerate_id(true);
    } catch (Exception $e) {
    }

    $_SESSION['term_admin_user_id'] = (int) $user['id'];
    $_SESSION['term_admin_username'] = (string) $user['username'];
    $_SESSION['term_admin_role'] = (string) $user['role'];
    unset($_SESSION['term_admin_csrf']);

    try {
        getDB()->update(
            'users',
            ['last_login_at' => date('Y-m-d H:i:s')],
            'id = :where_id',
            ['where_id' => (int) $user['id']]
        );
    } catch (Exception $e) {
    }
}

function termAdminLogout(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }

    session_destroy();
}

function termAdminChangePassword(int $userId, string $currentPassword, string $newPassword, string $confirmPassword): array
{
    if ($newPassword !== $confirmPassword) {
        return ['ok' => false, 'message' => 'Parolele noi nu coincid.'];
    }

    if (strlen($newPassword) < 8) {
        return ['ok' => false, 'message' => 'Parola noua trebuie sa aiba minim 8 caractere.'];
    }

    try {
        $user = getDB()->fetchOne('SELECT password_hash FROM users WHERE id = ? LIMIT 1', [$userId]);
        if (!$user || !password_verify($currentPassword, $user['password_hash'])) {
            return ['ok' => false, 'message' => 'Parola curenta este incorecta.'];
        }

        getDB()->update('users', [
            'password_hash' => password_hash($newPassword, PASSWORD_DEFAULT),
        ], 'id = :id', ['id' => $userId]);

        return ['ok' => true, 'message' => 'Parola a fost actualizata cu succes.'];
    } catch (Exception $e) {
        return ['ok' => false, 'message' => 'Nu am putut actualiza parola.'];
    }
}

function termAdminNavItems(array $user): array
{
    $role = $user['role'] ?? '';
    $items = [
        ['href' => 'index.php', 'icon' => 'fas fa-gauge-high', 'label' => 'Dashboard', 'page' => 'index.php', 'roles' => ['boss', 'colaborator', 'manager', 'statie', 'desfasurator']],
    ];

    if (termCanManageGames($role)) {
        $items[] = ['href' => 'jocuri.php', 'icon' => 'fas fa-gamepad', 'label' => 'Jocuri', 'page' => 'jocuri.php', 'roles' => ['boss', 'colaborator']];
        $items[] = ['href' => 'setari-marquee.php', 'icon' => 'fas fa-bullhorn', 'label' => 'Marquee terminal', 'page' => 'setari-marquee.php', 'roles' => ['boss', 'colaborator']];
    }

    if (in_array($role, ['boss', 'manager'], true)) {
        $items[] = ['href' => 'setari-terminal.php', 'icon' => 'fas fa-sliders', 'label' => 'Settings terminal', 'page' => 'setari-terminal.php', 'roles' => ['boss', 'manager']];
    }

    if (termCanManageUsers($role)) {
        $usersPageLabel = $role === 'manager' ? 'Shop-uri' : 'Shop si Manageri';
        $items[] = ['href' => 'utilizatori.php', 'icon' => 'fas fa-store', 'label' => $usersPageLabel, 'page' => 'utilizatori.php', 'roles' => ['boss', 'colaborator', 'manager']];
    }

    if (termCanViewTerminals($role)) {
        $items[] = ['href' => 'terminale.php', 'icon' => 'fas fa-desktop', 'label' => 'Terminale', 'page' => 'terminale.php', 'roles' => ['boss', 'colaborator', 'manager', 'statie']];
    }

    if (termCanViewStationsMap($role)) {
        $items[] = ['href' => 'harta-shop.php', 'icon' => 'fas fa-map-location-dot', 'label' => 'Harta Shop', 'page' => 'harta-shop.php', 'roles' => ['boss', 'colaborator', 'manager']];
    }

    $items[] = ['href' => 'incasari.php', 'icon' => 'fas fa-coins', 'label' => 'Incasari', 'page' => 'incasari.php', 'roles' => ['boss', 'colaborator', 'manager', 'statie', 'desfasurator']];
    $items[] = ['href' => 'sesiuni.php', 'icon' => 'fas fa-play', 'label' => 'Sesiuni joc', 'page' => 'sesiuni.php', 'roles' => ['boss', 'colaborator', 'manager', 'statie']];
    $items[] = ['href' => 'desfasari.php', 'icon' => 'fas fa-calculator', 'label' => 'Desfasurari', 'page' => 'desfasari.php', 'roles' => ['boss', 'colaborator', 'manager', 'desfasurator']];
    $items[] = ['href' => 'setari-parola.php', 'icon' => 'fas fa-key', 'label' => 'Schimba parola', 'page' => 'setari-parola.php', 'roles' => ['boss', 'colaborator', 'manager', 'statie', 'desfasurator']];

    return array_values(array_filter($items, static fn($item) => in_array($role, $item['roles'], true)));
}

function termAdminEnsureDefaultBoss(): void
{
    try {
        $existing = getDB()->fetchOne('SELECT id FROM users WHERE username = ? LIMIT 1', ['boss']);
        if ($existing) {
            return;
        }

        getDB()->insert('users', [
            'username' => 'boss',
            'password_hash' => password_hash('12341234', PASSWORD_DEFAULT),
            'display_name' => 'Administrator Boss',
            'role' => 'boss',
            'is_active' => 1,
        ]);
    } catch (Exception $e) {
    }
}

termAdminStartSession();
termAdminEnsureDefaultBoss();
