<?php

declare(strict_types=1);

require_once __DIR__ . '/lib/webauthn_crypto.php';

const IQWIN_WEBAUTHN_MAX_PER_USER = 5;

function iqwinWebAuthnEnsureTable(): void
{
    static $ready = false;
    if ($ready) {
        return;
    }

    try {
        getDB()->query(
            "CREATE TABLE IF NOT EXISTS `user_webauthn` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `user_id` int(11) NOT NULL,
              `credential_id` varchar(255) NOT NULL,
              `public_key` text NOT NULL,
              `sign_count` int(10) unsigned NOT NULL DEFAULT 0,
              `label` varchar(80) DEFAULT NULL,
              `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
              `last_used_at` timestamp NULL DEFAULT NULL,
              PRIMARY KEY (`id`),
              UNIQUE KEY `credential_id` (`credential_id`),
              KEY `user_id` (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {
    }

    $ready = true;
}

function iqwinWebAuthnReadJsonBody(): array
{
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || trim($raw) === '') {
        return [];
    }
    $data = json_decode($raw, true);

    return is_array($data) ? $data : [];
}

function iqwinWebAuthnNewChallenge(): string
{
    return IqwinWebAuthnCrypto::b64uEncode(random_bytes(32));
}

function iqwinWebAuthnStoreChallenge(string $kind, string $challengeB64u, ?int $userId = null): void
{
    $_SESSION['iqwin_webauthn_' . $kind] = [
        'challenge' => $challengeB64u,
        'user_id' => $userId,
        'at' => time(),
    ];
}

/** @return array{challenge:string,user_id:?int}|null */
function iqwinWebAuthnTakeChallenge(string $kind): ?array
{
    $key = 'iqwin_webauthn_' . $kind;
    $row = $_SESSION[$key] ?? null;
    unset($_SESSION[$key]);
    if (!is_array($row) || empty($row['challenge'])) {
        return null;
    }
    $at = (int) ($row['at'] ?? 0);
    if ($at > 0 && (time() - $at) > 300) {
        return null;
    }

    return [
        'challenge' => (string) $row['challenge'],
        'user_id' => isset($row['user_id']) ? (int) $row['user_id'] : null,
    ];
}

function iqwinWebAuthnCountForUser(int $userId): int
{
    iqwinWebAuthnEnsureTable();
    try {
        $row = getDB()->fetchOne(
            'SELECT COUNT(*) AS c FROM user_webauthn WHERE user_id = ?',
            [$userId]
        );

        return (int) ($row['c'] ?? 0);
    } catch (Throwable $e) {
        return 0;
    }
}

/** @return list<array{id:int,label:?string,created_at:string,last_used_at:?string}> */
function iqwinWebAuthnListForUser(int $userId): array
{
    iqwinWebAuthnEnsureTable();
    try {
        $rows = getDB()->fetchAll(
            'SELECT id, label, created_at, last_used_at
             FROM user_webauthn
             WHERE user_id = ?
             ORDER BY id ASC',
            [$userId]
        );
        $out = [];
        foreach ($rows as $row) {
            $out[] = [
                'id' => (int) $row['id'],
                'label' => $row['label'] !== null && $row['label'] !== '' ? (string) $row['label'] : null,
                'created_at' => (string) $row['created_at'],
                'last_used_at' => $row['last_used_at'] !== null ? (string) $row['last_used_at'] : null,
            ];
        }

        return $out;
    } catch (Throwable $e) {
        return [];
    }
}

function iqwinWebAuthnRemoveForUser(int $userId, int $credentialRowId): bool
{
    iqwinWebAuthnEnsureTable();
    try {
        $n = getDB()->delete(
            'user_webauthn',
            'id = :where_id AND user_id = :where_user',
            ['where_id' => $credentialRowId, 'where_user' => $userId]
        );

        return $n > 0;
    } catch (Throwable $e) {
        return false;
    }
}

/** @return list<array{id:string,type:string}> */
function iqwinWebAuthnAllowCredentials(): array
{
    iqwinWebAuthnEnsureTable();
    try {
        $rows = getDB()->fetchAll(
            "SELECT w.credential_id
             FROM user_webauthn w
             INNER JOIN users u ON u.id = w.user_id
             WHERE u.is_active = 1 AND u.role <> 'casier'
             ORDER BY w.last_used_at DESC, w.id DESC
             LIMIT 200"
        );
        $out = [];
        foreach ($rows as $row) {
            $id = (string) ($row['credential_id'] ?? '');
            if ($id === '') {
                continue;
            }
            $out[] = ['id' => $id, 'type' => 'public-key'];
        }

        return $out;
    } catch (Throwable $e) {
        return [];
    }
}

/** @return list<array{id:string,type:string}> */
function iqwinWebAuthnExcludeCredentials(int $userId): array
{
    iqwinWebAuthnEnsureTable();
    try {
        $rows = getDB()->fetchAll(
            'SELECT credential_id FROM user_webauthn WHERE user_id = ?',
            [$userId]
        );
        $out = [];
        foreach ($rows as $row) {
            $id = (string) ($row['credential_id'] ?? '');
            if ($id !== '') {
                $out[] = ['id' => $id, 'type' => 'public-key'];
            }
        }

        return $out;
    } catch (Throwable $e) {
        return [];
    }
}

function iqwinWebAuthnRegisterInit(array $user): array
{
    iqwinWebAuthnEnsureTable();
    $userId = (int) ($user['id'] ?? 0);
    if ($userId <= 0) {
        return ['ok' => false, 'message' => 'Neautentificat.'];
    }
    if (iqwinWebAuthnCountForUser($userId) >= IQWIN_WEBAUTHN_MAX_PER_USER) {
        return ['ok' => false, 'message' => 'Ai deja maxim ' . IQWIN_WEBAUTHN_MAX_PER_USER . ' amprente.'];
    }

    $challenge = iqwinWebAuthnNewChallenge();
    iqwinWebAuthnStoreChallenge('register', $challenge, $userId);

    $userHandle = IqwinWebAuthnCrypto::b64uEncode(pack('N', $userId));
    $display = trim((string) ($user['display_name'] ?? ''));
    if ($display === '') {
        $display = (string) ($user['username'] ?? 'user');
    }

    return [
        'ok' => true,
        'publicKey' => [
            'challenge' => $challenge,
            'rp' => [
                'name' => 'IQWIN',
                'id' => IqwinWebAuthnCrypto::rpId(),
            ],
            'user' => [
                'id' => $userHandle,
                'name' => (string) ($user['username'] ?? ('user' . $userId)),
                'displayName' => $display,
            ],
            'pubKeyCredParams' => [
                ['type' => 'public-key', 'alg' => -7],
                ['type' => 'public-key', 'alg' => -257],
            ],
            'timeout' => 60000,
            'attestation' => 'none',
            'authenticatorSelection' => [
                // Preferă Windows Hello / amprentă pe dispozitiv, fără a bloca Chrome
                // când API-ul de „platform available” raportează fals negativ.
                'residentKey' => 'preferred',
                'requireResidentKey' => false,
                'userVerification' => 'required',
            ],
            'excludeCredentials' => iqwinWebAuthnExcludeCredentials($userId),
        ],
    ];
}

function iqwinWebAuthnRegisterComplete(array $user, array $credential, ?string $label = null): array
{
    iqwinWebAuthnEnsureTable();
    $userId = (int) ($user['id'] ?? 0);
    $stored = iqwinWebAuthnTakeChallenge('register');
    if ($stored === null || (int) ($stored['user_id'] ?? 0) !== $userId) {
        return ['ok' => false, 'message' => 'Sesiunea amprentă a expirat. Încearcă din nou.'];
    }
    if (iqwinWebAuthnCountForUser($userId) >= IQWIN_WEBAUTHN_MAX_PER_USER) {
        return ['ok' => false, 'message' => 'Ai deja maxim ' . IQWIN_WEBAUTHN_MAX_PER_USER . ' amprente.'];
    }

    try {
        $response = $credential['response'] ?? null;
        if (!is_array($response)) {
            throw new RuntimeException('răspuns lipsa');
        }
        $clientDataJson = IqwinWebAuthnCrypto::b64uDecode((string) ($response['clientDataJSON'] ?? ''));
        IqwinWebAuthnCrypto::parseClientDataJson($clientDataJson, 'webauthn.create', $stored['challenge']);
        $attObj = IqwinWebAuthnCrypto::b64uDecode((string) ($response['attestationObject'] ?? ''));
        $parsed = IqwinWebAuthnCrypto::parseAttestation($attObj, $clientDataJson);

        $credIdFromClient = (string) ($credential['id'] ?? '');
        if ($credIdFromClient !== '' && !hash_equals($parsed['credentialId'], $credIdFromClient)) {
            // Browser id is base64url of rawId; tolerate padding differences
            $rawId = (string) ($credential['rawId'] ?? '');
            if ($rawId !== '') {
                $fromRaw = IqwinWebAuthnCrypto::b64uEncode(IqwinWebAuthnCrypto::b64uDecode($rawId));
                if (!hash_equals($parsed['credentialId'], $fromRaw)) {
                    throw new RuntimeException('credential id mismatch');
                }
            }
        }

        $label = trim((string) ($label ?? ''));
        if (function_exists('mb_substr')) {
            $label = mb_substr($label, 0, 80, 'UTF-8');
        } else {
            $label = substr($label, 0, 80);
        }
        if ($label === '') {
            $label = 'Dispozitiv ' . date('d.m.Y H:i');
        }

        getDB()->insert('user_webauthn', [
            'user_id' => $userId,
            'credential_id' => $parsed['credentialId'],
            'public_key' => $parsed['publicKeyPem'],
            'sign_count' => (int) $parsed['signCount'],
            'label' => $label,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return ['ok' => true, 'message' => 'Amprenta a fost adăugată.'];
    } catch (Throwable $e) {
        $msg = $e->getMessage();
        if (stripos($msg, 'Duplicate') !== false || stripos($msg, '1062') !== false) {
            return ['ok' => false, 'message' => 'Această amprentă este deja înregistrată.'];
        }
        error_log('webauthn register: ' . $msg);

        return ['ok' => false, 'message' => 'Nu am putut salva amprenta. Încearcă din nou.'];
    }
}

function iqwinWebAuthnLoginInit(): array
{
    iqwinWebAuthnEnsureTable();
    $allow = iqwinWebAuthnAllowCredentials();
    if ($allow === []) {
        return [
            'ok' => false,
            'message' => 'Nicio amprentă înregistrată. Intră cu parola, apoi adaugă amprenta din Setări.',
        ];
    }

    $challenge = iqwinWebAuthnNewChallenge();
    iqwinWebAuthnStoreChallenge('login', $challenge, null);

    return [
        'ok' => true,
        'publicKey' => [
            'challenge' => $challenge,
            'timeout' => 60000,
            'rpId' => IqwinWebAuthnCrypto::rpId(),
            'userVerification' => 'required',
            'allowCredentials' => $allow,
        ],
    ];
}

function iqwinWebAuthnLoginComplete(array $credential): array
{
    iqwinWebAuthnEnsureTable();
    $stored = iqwinWebAuthnTakeChallenge('login');
    if ($stored === null) {
        return ['ok' => false, 'message' => 'Sesiunea amprentă a expirat. Încearcă din nou.'];
    }

    try {
        $credId = (string) ($credential['id'] ?? '');
        if ($credId === '') {
            $rawId = (string) ($credential['rawId'] ?? '');
            if ($rawId !== '') {
                $credId = IqwinWebAuthnCrypto::b64uEncode(IqwinWebAuthnCrypto::b64uDecode($rawId));
            }
        }
        if ($credId === '') {
            throw new RuntimeException('credential id lipsa');
        }

        $row = getDB()->fetchOne(
            'SELECT w.id, w.user_id, w.public_key, w.sign_count, w.credential_id,
                    u.username, u.role, u.is_active
             FROM user_webauthn w
             INNER JOIN users u ON u.id = w.user_id
             WHERE w.credential_id = ?
             LIMIT 1',
            [$credId]
        );
        if (!$row) {
            // try normalized id
            $norm = IqwinWebAuthnCrypto::b64uEncode(IqwinWebAuthnCrypto::b64uDecode($credId));
            if ($norm !== $credId) {
                $row = getDB()->fetchOne(
                    'SELECT w.id, w.user_id, w.public_key, w.sign_count, w.credential_id,
                            u.username, u.role, u.is_active
                     FROM user_webauthn w
                     INNER JOIN users u ON u.id = w.user_id
                     WHERE w.credential_id = ?
                     LIMIT 1',
                    [$norm]
                );
            }
        }
        if (!$row || !(int) $row['is_active'] || ($row['role'] ?? '') === 'casier') {
            throw new RuntimeException('credential necunoscut');
        }

        $response = $credential['response'] ?? null;
        if (!is_array($response)) {
            throw new RuntimeException('răspuns lipsa');
        }
        $clientDataJson = IqwinWebAuthnCrypto::b64uDecode((string) ($response['clientDataJSON'] ?? ''));
        IqwinWebAuthnCrypto::parseClientDataJson($clientDataJson, 'webauthn.get', $stored['challenge']);
        $authData = IqwinWebAuthnCrypto::b64uDecode((string) ($response['authenticatorData'] ?? ''));
        $signature = IqwinWebAuthnCrypto::b64uDecode((string) ($response['signature'] ?? ''));
        $verified = IqwinWebAuthnCrypto::verifyAssertion(
            (string) $row['public_key'],
            $authData,
            $clientDataJson,
            $signature,
            (int) $row['sign_count']
        );

        getDB()->update(
            'user_webauthn',
            [
                'sign_count' => (int) $verified['signCount'],
                'last_used_at' => date('Y-m-d H:i:s'),
            ],
            'id = :where_id',
            ['where_id' => (int) $row['id']]
        );

        if (!function_exists('termAdminEstablishSession')) {
            throw new RuntimeException('auth helper lipsa');
        }
        termAdminEstablishSession([
            'id' => (int) $row['user_id'],
            'username' => (string) $row['username'],
            'role' => (string) $row['role'],
        ]);

        return ['ok' => true, 'redirect' => 'index.php'];
    } catch (Throwable $e) {
        error_log('webauthn login: ' . $e->getMessage());

        return ['ok' => false, 'message' => 'Autentificarea cu amprentă a eșuat.'];
    }
}
