<?php

if (!function_exists('termAdminHasDashboardScope')) {
    function termAdminHasDashboardScope(array $user): bool
    {
        return in_array($user['role'] ?? '', ['manager', 'statie', 'desfasurator'], true);
    }
}

if (!function_exists('termAdminParseReportDate')) {
    function termAdminParseReportDate(?string $value): ?string
    {
        $value = trim((string) ($value ?? ''));
        if ($value === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return null;
        }

        $parts = explode('-', $value);
        if (!checkdate((int) $parts[1], (int) $parts[2], (int) $parts[0])) {
            return null;
        }

        return $value;
    }
}

if (!function_exists('termAdminFormatReportDateLabel')) {
    function termAdminFormatReportDateLabel(?string $value): string
    {
        $value = termAdminParseReportDate($value);
        if ($value === null) {
            return '';
        }

        $timestamp = strtotime($value . ' 00:00:00');
        if ($timestamp === false) {
            return $value;
        }

        return date('d.m.Y', $timestamp);
    }
}

if (!function_exists('termAdminBuildCustomReportPeriodMeta')) {
    function termAdminBuildCustomReportPeriodMeta(string $from, string $to): array
    {
        return [
            'key' => 'custom',
            'label' => termAdminFormatReportDateLabel($from) . ' - ' . termAdminFormatReportDateLabel($to),
            'transaction_sql' => "DATE(tt.created_at) BETWEEN '{$from}' AND '{$to}'",
            'transaction_params' => [],
            'use_terminal_totals' => false,
        ];
    }
}

if (!function_exists('termAdminReportPeriodContext')) {
    function termAdminReportPeriodContext(?array $query = null): array
    {
        $query = $query ?? $_GET;
        $key = termAdminNormalizeReportPeriod($query['period'] ?? '1d');
        $from = null;
        $to = null;

        if ($key === 'custom') {
            $from = termAdminParseReportDate($query['from'] ?? null);
            $to = termAdminParseReportDate($query['to'] ?? null);
            if ($from === null || $to === null || $from > $to) {
                $key = '7d';
                $from = null;
                $to = null;
            }
        }

        if ($key === 'custom' && $from !== null && $to !== null) {
            $meta = termAdminBuildCustomReportPeriodMeta($from, $to);
        } else {
            $meta = termAdminReportPeriodMeta($key);
        }

        return [
            'key' => $key,
            'from' => $from,
            'to' => $to,
            'meta' => $meta,
        ];
    }
}

if (!function_exists('termAdminPeriodMetaFromInput')) {
    function termAdminPeriodMetaFromInput($periodKeyOrContext): array
    {
        if (is_array($periodKeyOrContext) && isset($periodKeyOrContext['meta'])) {
            return $periodKeyOrContext['meta'];
        }

        return termAdminReportPeriodMeta((string) $periodKeyOrContext);
    }
}

if (!function_exists('termAdminPeriodFilterMarkupSafe')) {
    function termAdminPeriodFilterMarkupSafe(array $periodContext): string
    {
        try {
            $reflection = new ReflectionFunction('termAdminPeriodFilterMarkup');
            $param = $reflection->getParameters()[0] ?? null;
            if ($param && $param->hasType()) {
                $type = $param->getType();
                if ($type instanceof ReflectionNamedType && $type->getName() === 'string') {
                    return termAdminPeriodFilterMarkup((string) ($periodContext['key'] ?? '1d'));
                }
            }
        } catch (ReflectionException $e) {
            return termAdminPeriodFilterMarkup((string) ($periodContext['key'] ?? '1d'));
        }

        return termAdminPeriodFilterMarkup($periodContext);
    }
}

if (!function_exists('termAdminPeriodFetchInput')) {
    function termAdminPeriodFetchInput(array $periodContext)
    {
        try {
            $reflection = new ReflectionFunction('termAdminFetchTerminalPeriodStats');
            $param = $reflection->getParameters()[1] ?? null;
            if ($param && $param->hasType()) {
                $type = $param->getType();
                if ($type instanceof ReflectionNamedType && $type->getName() === 'string') {
                    return $periodContext['key'];
                }
            }
        } catch (ReflectionException $e) {
            return $periodContext['key'];
        }

        return $periodContext;
    }
}
