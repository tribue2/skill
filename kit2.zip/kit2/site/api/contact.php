<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function siteContactJson(array $payload, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    siteContactJson(['ok' => false, 'message' => 'Metoda invalida.'], 405);
}

$raw = file_get_contents('php://input');
$body = [];
if (is_string($raw) && trim($raw) !== '') {
    $parsed = json_decode($raw, true);
    if (is_array($parsed)) {
        $body = $parsed;
    }
}
if (!$body) {
    $body = $_POST;
}

$name = trim((string) ($body['name'] ?? ''));
$email = trim((string) ($body['email'] ?? ''));
$phone = trim((string) ($body['phone'] ?? ''));
$subject = trim((string) ($body['subject'] ?? ''));
$message = trim((string) ($body['message'] ?? ''));
$honeypot = trim((string) ($body['company'] ?? ''));

if ($honeypot !== '') {
    siteContactJson(['ok' => true, 'message' => 'Mesaj trimis.']);
}

if ($name === '' || mb_strlen($name) < 2) {
    siteContactJson(['ok' => false, 'message' => 'Completează numele complet.'], 422);
}
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    siteContactJson(['ok' => false, 'message' => 'Introdu un e-mail valid.'], 422);
}
if ($subject === '' || mb_strlen($subject) < 2) {
    siteContactJson(['ok' => false, 'message' => 'Completează subiectul.'], 422);
}
if ($message === '' || mb_strlen($message) < 10) {
    siteContactJson(['ok' => false, 'message' => 'Mesajul este prea scurt.'], 422);
}
if (mb_strlen($name) > 120 || mb_strlen($email) > 180 || mb_strlen($phone) > 40 || mb_strlen($subject) > 180 || mb_strlen($message) > 5000) {
    siteContactJson(['ok' => false, 'message' => 'Datele depășesc limita permisă.'], 422);
}

try {
    require_once __DIR__ . '/../../config/config.php';
    $db = getDB();

    $table = $db->fetchOne("SHOW TABLES LIKE 'site_contact_messages'");
    if (!$table) {
        $db->query(
            "CREATE TABLE site_contact_messages (
              id bigint unsigned NOT NULL AUTO_INCREMENT,
              full_name varchar(120) NOT NULL,
              email varchar(180) NOT NULL,
              phone varchar(40) NOT NULL DEFAULT '',
              subject varchar(180) NOT NULL,
              message text NOT NULL,
              ip varchar(64) NOT NULL DEFAULT '',
              user_agent varchar(255) NOT NULL DEFAULT '',
              created_at datetime NOT NULL,
              PRIMARY KEY (id),
              KEY idx_scm_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    }

    $db->insert('site_contact_messages', [
        'full_name' => $name,
        'email' => $email,
        'phone' => $phone,
        'subject' => $subject,
        'message' => $message,
        'ip' => substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64),
        'user_agent' => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
        'created_at' => date('Y-m-d H:i:s'),
    ]);

    siteContactJson(['ok' => true, 'message' => 'Mesajul a fost trimis. Îți răspundem în curând.']);
} catch (Throwable $e) {
    error_log('site contact: ' . $e->getMessage());
    siteContactJson(['ok' => false, 'message' => 'Nu am putut trimite mesajul. Încearcă din nou.'], 500);
}
