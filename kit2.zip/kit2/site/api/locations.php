<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function siteJson(array $payload, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    require_once __DIR__ . '/../../config/config.php';
    require_once __DIR__ . '/../../includes/helpers.php';
    require_once __DIR__ . '/../../includes/romania_locations.php';
    termStationEnsureLocationColumns();

    $db = getDB();
    $rows = $db->fetchAll(
        "SELECT id, name, location, judet, localitate, latitude, longitude, is_active
         FROM stations
         ORDER BY judet ASC, localitate ASC, name ASC, id ASC"
    );

    $locations = [];
    foreach ($rows as $row) {
        $stationId = (int) ($row['id'] ?? 0);
        $name = trim((string) ($row['name'] ?? ''));
        $location = trim((string) ($row['location'] ?? ''));
        $judet = termStationDisplayCounty((string) ($row['judet'] ?? ''));
        $localitate = termStationDisplayCity((string) ($row['localitate'] ?? ''), $judet);
        $active = (int) ($row['is_active'] ?? 0) === 1;

        $lat = $row['latitude'] ?? null;
        $lng = $row['longitude'] ?? null;
        $hasCoords = $lat !== null && $lng !== null
            && abs((float) $lat) > 0.0001
            && abs((float) $lng) > 0.0001;

        if (!$hasCoords && function_exists('termStationSyncCoordinates')) {
            termStationSyncCoordinates($stationId, $location !== '' ? $location : null);
            $fresh = $db->fetchOne(
                'SELECT latitude, longitude FROM stations WHERE id = ? LIMIT 1',
                [$stationId]
            );
            if ($fresh) {
                $lat = $fresh['latitude'] ?? null;
                $lng = $fresh['longitude'] ?? null;
                $hasCoords = $lat !== null && $lng !== null
                    && abs((float) $lat) > 0.0001
                    && abs((float) $lng) > 0.0001;
            }
        }

        if (!$hasCoords) {
            continue;
        }

        $dbJudet = trim((string) ($row['judet'] ?? ''));
        $dbLocalitate = trim((string) ($row['localitate'] ?? ''));
        if (
            ($judet !== '' && ($dbJudet !== $judet || str_contains($dbJudet, '?')))
            || ($localitate !== '' && ($dbLocalitate !== $localitate || str_contains($dbLocalitate, '?')))
        ) {
            try {
                termStationSaveLocationFields(
                    $stationId,
                    $judet !== '' ? $judet : null,
                    $localitate !== '' ? $localitate : null,
                    null,
                    false
                );
            } catch (Throwable $e) {
            }
        }

        $locations[] = [
            'id' => $stationId,
            'name' => $name !== '' ? $name : ('Locatie #' . $stationId),
            'location' => $location,
            'judet' => $judet,
            'localitate' => $localitate,
            'active' => $active,
            'lat' => (float) $lat,
            'lng' => (float) $lng,
        ];
    }

    siteJson([
        'ok' => true,
        'count' => count($locations),
        'locations' => $locations,
        'counties' => termRoCounties(),
    ]);
} catch (Throwable $e) {
    error_log('site locations: ' . $e->getMessage());
    siteJson(['ok' => false, 'message' => 'Nu am putut încărca locațiile.'], 500);
}
