(() => {
    const mapEl = document.getElementById('siteMap');
    const emptyEl = document.getElementById('siteMapEmpty');
    const judetSelect = document.getElementById('filterJudet');
    const localitateSelect = document.getElementById('filterLocalitate');
    if (!mapEl || !window.L) return;

    const state = {
        all: [],
        map: null,
        layer: null
    };

    function pinIcon(active) {
        const inactiveClass = active === false ? ' is-inactive' : '';
        return L.divIcon({
            className: 'site-pin-wrap',
            html: '<div class="site-pin' + inactiveClass + '"><div class="site-pin__core"></div></div>',
            iconSize: [34, 34],
            iconAnchor: [17, 34],
            popupAnchor: [0, -28]
        });
    }

    function uniqueSorted(values) {
        return Array.from(new Set(values.filter(Boolean))).sort((a, b) => a.localeCompare(b, 'ro'));
    }

    function fillSelect(select, values, placeholder) {
        if (!select) return;
        const current = select.value;
        select.innerHTML = '';
        const first = document.createElement('option');
        first.value = '';
        first.textContent = placeholder;
        select.appendChild(first);
        values.forEach((value) => {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = value;
            select.appendChild(option);
        });
        if (values.includes(current)) {
            select.value = current;
        }
    }

    function filtered() {
        const judet = judetSelect ? judetSelect.value : '';
        const localitate = localitateSelect ? localitateSelect.value : '';
        return state.all.filter((item) => {
            if (judet && item.judet !== judet) return false;
            if (localitate && item.localitate !== localitate) return false;
            return true;
        });
    }

    function refreshLocalitati() {
        const judet = judetSelect ? judetSelect.value : '';
        const pool = judet ? state.all.filter((item) => item.judet === judet) : state.all;
        fillSelect(
            localitateSelect,
            uniqueSorted(pool.map((item) => item.localitate)),
            'Selectează localitate'
        );
    }

    function renderMarkers() {
        if (!state.map || !state.layer) return;
        state.layer.clearLayers();
        const rows = filtered();

        if (emptyEl) {
            emptyEl.classList.toggle('is-hidden', rows.length > 0);
            emptyEl.textContent = state.all.length
                ? 'Nicio locație pentru filtrele selectate.'
                : 'Locațiile vor apărea aici în curând.';
        }

        const bounds = [];
        rows.forEach((item) => {
            const isActive = item.active !== false;
            const marker = L.marker([item.lat, item.lng], { icon: pinIcon(isActive) });
            const statusLabel = isActive ? '' : '<br><em>În curând</em>';
            marker.bindPopup(
                '<strong>' + escapeHtml(item.name) + '</strong><br>' +
                escapeHtml(item.localitate || item.judet || '') +
                statusLabel
            );
            state.layer.addLayer(marker);
            bounds.push([item.lat, item.lng]);
        });

        if (bounds.length > 1) {
            state.map.fitBounds(bounds, { padding: [40, 40], maxZoom: 10 });
        } else if (bounds.length === 1) {
            state.map.setView(bounds[0], 11);
        } else {
            state.map.setView([45.9432, 24.9668], 6.5);
        }
    }

    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    async function loadLocations() {
        const response = await fetch('/site/api/locations.php', { cache: 'no-store' });
        const data = await response.json();
        if (!response.ok || !data || !data.ok) {
            throw new Error((data && data.message) || 'Nu am putut încărca locațiile.');
        }
        state.all = Array.isArray(data.locations) ? data.locations : [];
        const fromData = uniqueSorted(state.all.map((item) => item.judet));
        const allCounties = Array.isArray(data.counties) ? data.counties : [];
        fillSelect(judetSelect, fromData.length ? fromData : allCounties, 'Selectează județ');
        refreshLocalitati();
        renderMarkers();
    }

    state.map = L.map(mapEl, {
        zoomControl: true,
        scrollWheelZoom: true
    }).setView([45.9432, 24.9668], 6.5);

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap &copy; CARTO',
        subdomains: 'abcd',
        maxZoom: 18
    }).addTo(state.map);

    state.layer = L.layerGroup().addTo(state.map);

    if (judetSelect) {
        judetSelect.addEventListener('change', () => {
            refreshLocalitati();
            renderMarkers();
        });
    }
    if (localitateSelect) {
        localitateSelect.addEventListener('change', renderMarkers);
    }

    loadLocations().catch((error) => {
        if (emptyEl) {
            emptyEl.classList.remove('is-hidden');
            emptyEl.textContent = error.message || 'Eroare la încărcarea locațiilor.';
        }
    });
})();
