<?php

declare(strict_types=1);

function siteBasePath(): string
{
    return '';
}

function siteAsset(string $path): string
{
    $full = __DIR__ . '/' . ltrim($path, '/');
    $version = is_file($full) ? (string) filemtime($full) : (string) time();
    return siteBasePath() . '/site/' . ltrim($path, '/') . '?v=' . $version;
}

function siteUrl(string $path = '/'): string
{
    $path = '/' . ltrim($path, '/');
    if ($path === '/index.php' || $path === '/') {
        return siteBasePath() . '/';
    }
    return siteBasePath() . $path;
}

function siteEscape(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function siteCurrentPage(): string
{
    $script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? 'index.php'));
    if ($script === 'locatii.php') {
        return 'locatii';
    }
    if ($script === 'contact.php') {
        return 'contact';
    }
    return 'acasa';
}

function siteRenderHeader(string $title, string $description = ''): void
{
    $page = siteCurrentPage();
    $desc = $description !== ''
        ? $description
        : 'IQWIN — Skill Beats Luck. Divertisment bazat pe inteligenta, cultura generala si abilitati cognitive.';
    $pageTitle = $title !== '' ? ($title . ' | IQWIN') : 'IQWIN — Skill Beats Luck';
    ?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo siteEscape($pageTitle); ?></title>
    <meta name="description" content="<?php echo siteEscape($desc); ?>">
    <meta name="theme-color" content="#050505">
    <link rel="icon" href="<?php echo siteEscape(siteBasePath() . '/images/logo.webp'); ?>" type="image/webp">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo siteEscape(siteAsset('css/site.css')); ?>">
</head>
<body class="site-body site-page--<?php echo siteEscape($page); ?>">
<header class="site-header" id="siteHeader">
    <div class="site-header__inner">
        <a class="site-brand" href="<?php echo siteEscape(siteUrl('/')); ?>">
            <img class="site-brand__mark" src="<?php echo siteEscape(siteBasePath() . '/images/logoz.png'); ?>" alt="" width="64" height="64" decoding="async">
            <span class="site-brand__text">
                <strong>IQWIN</strong>
                <em>Skill Beats Luck</em>
            </span>
        </a>
        <button class="site-nav-toggle" type="button" id="siteNavToggle" aria-expanded="false" aria-controls="siteNav">
            <span></span><span></span>
        </button>
        <nav class="site-nav" id="siteNav" aria-label="Navigare principala">
            <a class="<?php echo $page === 'acasa' ? 'is-active' : ''; ?>" href="<?php echo siteEscape(siteUrl('/')); ?>">Acasă</a>
            <a class="<?php echo $page === 'locatii' ? 'is-active' : ''; ?>" href="<?php echo siteEscape(siteUrl('/locatii.php')); ?>">Locații</a>
            <a class="<?php echo $page === 'contact' ? 'is-active' : ''; ?>" href="<?php echo siteEscape(siteUrl('/contact.php')); ?>">Contact</a>
        </nav>
    </div>
</header>
<main class="site-main">
    <?php
}

function siteRenderFooter(): void
{
    ?>
</main>
<footer class="site-footer">
    <div class="site-footer__inner">
        <p class="site-footer__brand">IQWIN</p>
        <p class="site-footer__tag">Skill Beats Luck</p>
        <p class="site-footer__copy">&copy; <?php echo date('Y'); ?> iqwin.eu</p>
    </div>
</footer>
<script src="<?php echo siteEscape(siteAsset('js/site.js')); ?>"></script>
</body>
</html>
    <?php
}
