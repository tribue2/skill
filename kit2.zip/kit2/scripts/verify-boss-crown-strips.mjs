import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '..');
const jsonPath = path.join(root, 'games/boss-crown/assets/reel-strips.json');

const payload = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
const strips = payload.strips;

if (!Array.isArray(strips) || strips.length !== 5) {
    console.error('FAIL: expected 5 strips');
    process.exit(1);
}

function hasAdjacentDup(strip) {
    for (let i = 0; i < strip.length - 1; i += 1) {
        if (strip[i] === strip[i + 1]) return true;
    }
    return strip.length > 1 && strip[strip.length - 1] === strip[0];
}

strips.forEach((strip, reelIndex) => {
    if (!Array.isArray(strip) || strip.length === 0) {
        console.error(`FAIL: reel ${reelIndex} empty`);
        process.exit(1);
    }
    if (hasAdjacentDup(strip)) {
        console.error(`FAIL: reel ${reelIndex} has adjacent duplicate symbols`);
        process.exit(1);
    }
    console.log(`OK reel ${reelIndex}: length ${strip.length}`);
});

console.log('OK boss-crown reel-strips.json');
