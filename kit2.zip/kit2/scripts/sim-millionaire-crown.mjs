/**
 * Monte Carlo Millionaire Crown — random vs jucător bun.
 * Plată: skill-stop folosit (câștigul calculat e plătit).
 *
 * Usage:
 *   node scripts/sim-millionaire-crown.mjs [spins=10000] [betPerLine=1]
 */
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dir = dirname(fileURLToPath(import.meta.url));
const root = join(__dir, '..');
const stripsPath = join(root, 'games/boss-crown/assets/reel-strips.json');

const PAYTABLE = {
  scatter: { 5: 80, 4: 8, 3: 0.8 },
  om: { 5: 500, 4: 100, 3: 10 },
  faraon: { 5: 100, 4: 20, 3: 5 },
  scarabeu: { 5: 100, 4: 20, 3: 5 },
  buburuza: { 5: 50, 4: 15, 3: 3 },
  a: { 5: 25, 4: 4, 3: 1 },
  k: { 5: 25, 4: 4, 3: 1 },
  q: { 5: 25, 4: 4, 3: 1 },
  j: { 5: 25, 4: 4, 3: 1 },
};

const PAYLINES = [
  [1, 1, 1, 1, 1],
  [0, 0, 0, 0, 0],
  [2, 2, 2, 2, 2],
  [0, 1, 2, 1, 0],
  [2, 1, 0, 1, 2],
  [0, 0, 1, 2, 2],
  [2, 2, 1, 0, 0],
  [1, 0, 0, 0, 1],
  [1, 2, 2, 2, 1],
  [0, 1, 1, 1, 0],
];

const SCATTER_REEL_INDEXES = new Set([1, 3]);
const DOLLAR_TOTAL_BET_PAY = { 3: 2, 4: 20, 5: 100 };
const IQWIN_LINE_SEQUENCE = ['iq_i', 'iq_q', 'iq_w', 'iq_i', 'iq_n'];
const IQWIN_SYMBOLS = new Set(['iq_i', 'iq_q', 'iq_w', 'iq_n']);
const IQWIN_LINE_PAY = 1000;
const LINES = 5;

const SYMBOL_VALUE = {
  om: 10,
  faraon: 5,
  scarabeu: 5,
  buburuza: 3,
  dollar: 2.5,
  scatter: 4,
  a: 1,
  k: 1,
  q: 1,
  j: 1,
  iq_i: 6,
  iq_q: 6,
  iq_w: 6,
  iq_n: 6,
};

const decoded = JSON.parse(readFileSync(stripsPath, 'utf8'));
const strips = decoded.strips;
if (!Array.isArray(strips) || strips.length !== 5) {
  throw new Error('reel-strips.json invalid');
}

function readColumn(reelIndex, stopIndex) {
  const strip = strips[reelIndex];
  const length = strip.length;
  const top = ((stopIndex % length) + length) % length;
  return [strip[top % length], strip[(top + 1) % length], strip[(top + 2) % length]];
}

function buildBoard(stops) {
  return stops.map((stop, reel) => readColumn(reel, stop));
}

function isWild(symbol) {
  return symbol === 'scatter';
}

function isIqwin(symbol) {
  return IQWIN_SYMBOLS.has(symbol);
}

function countPaylineMatches(symbols) {
  let target = null;
  let matched = 0;
  let pendingWilds = 0;

  for (const symbol of symbols) {
    if (isWild(symbol)) {
      if (target === null) pendingWilds += 1;
      else if (!isIqwin(target)) matched += 1;
      else break;
      continue;
    }

    if (target === null) {
      target = symbol;
      matched = isIqwin(target) ? 1 : pendingWilds + 1;
      pendingWilds = 0;
      continue;
    }

    if (symbol === target) {
      matched += 1;
      continue;
    }
    break;
  }

  return { target, matched };
}

function evaluateIqwinLine(board, lineRows, totalBet) {
  for (let reel = 0; reel < 5; reel += 1) {
    if ((board[reel][lineRows[reel]] ?? '') !== IQWIN_LINE_SEQUENCE[reel]) return null;
  }
  const payout = Math.round(totalBet * IQWIN_LINE_PAY * 100) / 100;
  return payout > 0 ? { symbol: 'iqwin', count: 5, payout } : null;
}

function evaluatePayline(board, lineRows, totalBet) {
  const iqwin = evaluateIqwinLine(board, lineRows, totalBet);
  if (iqwin) return iqwin;

  const symbols = lineRows.map((row, reel) => board[reel][row] ?? '');
  const { target, matched } = countPaylineMatches(symbols);
  if (target === null || matched < 3 || isIqwin(target)) return null;

  let multiplier = 0;
  if (target === 'dollar') {
    multiplier = DOLLAR_TOTAL_BET_PAY[matched] ?? 0;
  } else {
    const payKey = PAYTABLE[target] ? target : 'q';
    multiplier = PAYTABLE[payKey]?.[matched] ?? 0;
  }
  if (multiplier <= 0) return null;

  const payout = Math.round(totalBet * multiplier * 100) / 100;
  return payout > 0 ? { symbol: target, count: matched, payout } : null;
}

function scatterPositions(board) {
  const positions = [];
  for (let reel = 0; reel < board.length; reel += 1) {
    if (!SCATTER_REEL_INDEXES.has(reel)) continue;
    for (let row = 0; row < board[reel].length; row += 1) {
      if (board[reel][row] === 'scatter') positions.push(`${reel}-${row}`);
    }
  }
  return positions;
}

function evaluateBoard(board, betPerLine, lines) {
  const totalBet = Math.round(betPerLine * lines * 100) / 100;
  let total = 0;
  const wins = [];

  for (let index = 0; index < lines; index += 1) {
    const lineWin = evaluatePayline(board, PAYLINES[index], totalBet);
    if (!lineWin) continue;
    total += lineWin.payout;
    wins.push(lineWin);
  }

  const scatters = scatterPositions(board);
  if (scatters.length >= 3) {
    const scatterCount = Math.min(5, scatters.length);
    const multiplier = PAYTABLE.scatter[scatterCount] ?? 0;
    const payout = Math.round(totalBet * multiplier * 100) / 100;
    if (payout > 0) {
      total += payout;
      wins.push({ symbol: 'scatter', count: scatters.length, payout });
    }
  }

  return { wins, total: Math.round(total * 100) / 100, totalBet };
}

function wrapStop(reel, stop) {
  const len = strips[reel].length;
  return ((stop % len) + len) % len;
}

function windowScore(reel, stop) {
  const col = readColumn(reel, stop);
  let score = 0;
  for (const symbol of col) {
    score += SYMBOL_VALUE[symbol] ?? 0;
  }
  // bonus dacă simbolul din mijloc e premium (linie orizontală centrală)
  score += (SYMBOL_VALUE[col[1]] ?? 0) * 0.5;
  return score;
}

function randomStops() {
  return strips.map((strip) => Math.floor(Math.random() * strip.length));
}

/** Jucător bun: pe fiecare rolă, din fereastra ±W față de un moment aleator, alege zona cu simboluri mari. */
function skilledValueStops(windowRadius) {
  return strips.map((strip, reel) => {
    const base = Math.floor(Math.random() * strip.length);
    let bestStop = base;
    let bestScore = -1;
    for (let d = -windowRadius; d <= windowRadius; d += 1) {
      const stop = wrapStop(reel, base + d);
      const score = windowScore(reel, stop);
      if (score > bestScore) {
        bestScore = score;
        bestStop = stop;
      }
    }
    return bestStop;
  });
}

/**
 * Jucător bun + aliniere: oprește rolele stânga→dreapta;
 * în fereastra ±W alege stopul care maximizează câștigul estimat
 * (rolele viitoare = tot ce e mai bun în fereastra lor de reacție).
 */
function skilledAlignStops(windowRadius, betPerLine, lines) {
  const bases = strips.map((strip) => Math.floor(Math.random() * strip.length));
  const futureValueStops = bases.map((base, reel) => {
    let bestStop = base;
    let bestScore = -1;
    for (let d = -windowRadius; d <= windowRadius; d += 1) {
      const stop = wrapStop(reel, base + d);
      const score = windowScore(reel, stop);
      if (score > bestScore) {
        bestScore = score;
        bestStop = stop;
      }
    }
    return bestStop;
  });

  const stops = [];
  for (let reel = 0; reel < 5; reel += 1) {
    let bestStop = bases[reel];
    let bestPay = -1;
    let bestScore = -1;
    for (let d = -windowRadius; d <= windowRadius; d += 1) {
      const stop = wrapStop(reel, bases[reel] + d);
      const trial = futureValueStops.slice();
      for (let i = 0; i < reel; i += 1) trial[i] = stops[i];
      trial[reel] = stop;
      const pay = evaluateBoard(buildBoard(trial), betPerLine, lines).total;
      const score = windowScore(reel, stop);
      if (pay > bestPay || (pay === bestPay && score > bestScore)) {
        bestPay = pay;
        bestScore = score;
        bestStop = stop;
      }
    }
    stops.push(bestStop);
  }
  return stops;
}

function runScenario(name, spins, betPerLine, lines, pickStops) {
  let totalIn = 0;
  let totalOut = 0;
  let hits = 0;
  let maxWin = 0;
  const buckets = { 0: 0, lt1x: 0, '1_5x': 0, '5_20x': 0, '20_100x': 0, ge100x: 0 };

  for (let i = 0; i < spins; i += 1) {
    const result = evaluateBoard(buildBoard(pickStops()), betPerLine, lines);
    totalIn += result.totalBet;
    totalOut += result.total;
    if (result.total > 0) hits += 1;
    if (result.total > maxWin) maxWin = result.total;

    const mult = result.total / result.totalBet;
    if (result.total === 0) buckets[0] += 1;
    else if (mult < 1) buckets.lt1x += 1;
    else if (mult < 5) buckets['1_5x'] += 1;
    else if (mult < 20) buckets['5_20x'] += 1;
    else if (mult < 100) buckets['20_100x'] += 1;
    else buckets.ge100x += 1;
  }

  return {
    name,
    spins,
    totalIn,
    totalOut,
    diff: totalIn - totalOut,
    rtp: totalIn > 0 ? (totalOut / totalIn) * 100 : 0,
    hitRate: (hits / spins) * 100,
    hits,
    maxWin,
    buckets,
  };
}

function printScenario(s, totalBetPerSpin) {
  console.log(`--- ${s.name} ---`);
  console.log(`Total IN:  ${s.totalIn.toFixed(2)}`);
  console.log(`Total OUT: ${s.totalOut.toFixed(2)}`);
  console.log(`Diferență (IN-OUT): ${s.diff.toFixed(2)}`);
  console.log(`RTP: ${s.rtp.toFixed(2)}%`);
  console.log(`Hit rate: ${s.hitRate.toFixed(2)}% (${s.hits}/${s.spins})`);
  console.log(`Max spin: ${s.maxWin.toFixed(2)} (${(s.maxWin / totalBetPerSpin).toFixed(2)}×)`);
  console.log(
    `Distribuție: 0×=${s.buckets[0]} | <1×=${s.buckets.lt1x} | 1–5×=${s.buckets['1_5x']} | 5–20×=${s.buckets['5_20x']} | 20–100×=${s.buckets['20_100x']} | ≥100×=${s.buckets.ge100x}`
  );
  console.log('');
}

const spins = Math.max(1, Number(process.argv[2] || 10000));
const betPerLine = Math.max(0.01, Number(process.argv[3] || 1));
const lines = LINES;
const totalBetPerSpin = Math.round(betPerLine * lines * 100) / 100;
const windows = (process.argv[4] || '1,2,4')
  .split(',')
  .map((v) => Number(v.trim()))
  .filter((v) => Number.isFinite(v) && v >= 0);

console.log('=== Millionaire Crown — random vs jucător bun ===');
console.log(`Benzile: reel-strips.json (version ${decoded.version ?? '?'})`);
console.log(`Spins: ${spins} | miza ${betPerLine} × ${lines} = ${totalBetPerSpin}/spin`);
console.log('Model skill: moment aleator pe rolă + alegere în fereastra ±W');
console.log('Plată: skill-stop folosit (câștigul calculat e plătit)');
console.log('');

const scenarios = [
  runScenario('Aleator (fără țintire)', spins, betPerLine, lines, randomStops),
];

for (const W of windows) {
  scenarios.push(
    runScenario(
      `Zone simboluri mari (±${W})`,
      spins,
      betPerLine,
      lines,
      () => skilledValueStops(W)
    )
  );
  scenarios.push(
    runScenario(
      `Aliniere linii (±${W}, stânga→dreapta)`,
      spins,
      betPerLine,
      lines,
      () => skilledAlignStops(W, betPerLine, lines)
    )
  );
}

for (const s of scenarios) printScenario(s, totalBetPerSpin);

console.log('Rezumat:');
console.log(
  'strategie'.padEnd(44),
  'RTP'.padStart(9),
  'hit%'.padStart(8),
  'IN-OUT'.padStart(12)
);
for (const s of scenarios) {
  console.log(
    s.name.padEnd(44),
    `${s.rtp.toFixed(1)}%`.padStart(9),
    `${s.hitRate.toFixed(1)}%`.padStart(8),
    s.diff.toFixed(0).padStart(12)
  );
}
console.log('');
console.log('Notă: ±W = câte poziții pe bandă poate „corecta” jucătorul');
console.log('față de momentul aleator al apăsării. ±1 = bun realist;');
console.log('±4 = aproape perfect pe zonă. Alinierea e un jucător care');
console.log('optimizează și potrivirile pe linii, nu doar simbolul mare.');
