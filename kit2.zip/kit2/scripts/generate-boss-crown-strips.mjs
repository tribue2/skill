import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '..');

const ORIGINAL = [
    ['faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'iq_i', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'iq_i'],
    ['buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'scatter', 'iq_q', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'iq_q'],
    ['a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'iq_w', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'iq_w'],
    ['j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'scatter', 'iq_i', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'iq_i'],
    ['q', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'dollar', 'j', 'iq_n', 'q', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'dollar', 'j', 'q', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'dollar', 'j', 'iq_n'],
];

const ROTATION_OFFSETS = [0, 11, 7, 19, 13];

function rotateStrip(strip, offset) {
    const len = strip.length;
    const o = ((offset % len) + len) % len;
    return strip.slice(o).concat(strip.slice(0, o));
}

function hasAdjacentDup(strip) {
    for (let i = 0; i < strip.length - 1; i += 1) {
        if (strip[i] === strip[i + 1]) return true;
    }
    return strip.length > 1 && strip[strip.length - 1] === strip[0];
}

function countMap(arr) {
    const m = new Map();
    arr.forEach((s) => m.set(s, (m.get(s) || 0) + 1));
    return m;
}

function mapsEqual(a, b) {
    if (a.size !== b.size) return false;
    for (const [k, v] of a) {
        if (b.get(k) !== v) return false;
    }
    return true;
}

function pickRotation(strip, reelIndex) {
    if (reelIndex === 0) return strip.slice();
    const preferred = ROTATION_OFFSETS[reelIndex];
    for (let attempt = 0; attempt < strip.length; attempt += 1) {
        const offset = (preferred + attempt) % strip.length;
        const rotated = rotateStrip(strip, offset);
        if (!hasAdjacentDup(rotated)) return rotated;
    }
    throw new Error(`No valid rotation for reel ${reelIndex}`);
}

const strips = ORIGINAL.map((strip, reelIndex) => pickRotation(strip, reelIndex));

strips.forEach((strip, ri) => {
    if (!mapsEqual(countMap(strip), countMap(ORIGINAL[ri]))) {
        throw new Error(`multiset mismatch reel ${ri}`);
    }
    if (hasAdjacentDup(strip)) {
        throw new Error(`adjacent dup reel ${ri}`);
    }
});

const payload = {
    version: 2,
    game: 'boss-crown',
    strips,
};

const outPath = path.join(root, 'games/boss-crown/assets/reel-strips.json');
fs.writeFileSync(outPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
console.log('OK', outPath);
strips.forEach((s, i) => {
    const sameAsOrig = JSON.stringify(s) === JSON.stringify(ORIGINAL[i]);
    console.log(`  reel ${i}: len ${s.length} ${sameAsOrig ? '(unchanged)' : `(rotated, starts ${s[0]})`}`);
});
