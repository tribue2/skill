<?php

function termTopDisplayEnsureSchema(): void
{
    static $ready = false;
    if ($ready) {
        return;
    }

    $db = getDB();
    $table = $db->fetchOne("SHOW TABLES LIKE 'terminal_top_display'");
    if (!$table) {
        $db->query(
            "CREATE TABLE terminal_top_display (
              terminal_id int unsigned NOT NULL,
              phase varchar(16) NOT NULL DEFAULT 'lobby',
              slug varchar(64) NOT NULL DEFAULT '',
              title varchar(255) NOT NULL DEFAULT '',
              html mediumtext NULL,
              updated_at datetime NOT NULL,
              PRIMARY KEY (terminal_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    }

    $ready = true;
}

function termTopDisplayDefault(): array
{
    return [
        'phase' => 'lobby',
        'slug' => '',
        'title' => '',
        'html' => '',
        'updated_at' => null,
    ];
}

function termTopDisplayGet(int $terminalId): array
{
    termTopDisplayEnsureSchema();
    if ($terminalId <= 0) {
        return termTopDisplayDefault();
    }

    $row = getDB()->fetchOne(
        'SELECT phase, slug, title, html, updated_at FROM terminal_top_display WHERE terminal_id = ? LIMIT 1',
        [$terminalId]
    );

    if (!$row) {
        return termTopDisplayDefault();
    }

    $phase = strtolower(trim((string) ($row['phase'] ?? 'lobby')));
    if ($phase !== 'game') {
        $phase = 'lobby';
    }

    return [
        'phase' => $phase,
        'slug' => strtolower(trim((string) ($row['slug'] ?? ''))),
        'title' => trim((string) ($row['title'] ?? '')),
        'html' => (string) ($row['html'] ?? ''),
        'updated_at' => $row['updated_at'] ?? null,
    ];
}

function termTopDisplaySave(int $terminalId, array $payload): array
{
    termTopDisplayEnsureSchema();
    if ($terminalId <= 0) {
        return termTopDisplayDefault();
    }

    $phase = strtolower(trim((string) ($payload['phase'] ?? 'lobby')));
    if ($phase !== 'game') {
        $phase = 'lobby';
    }

    $slug = strtolower(trim((string) ($payload['slug'] ?? '')));
    $title = trim((string) ($payload['title'] ?? ''));
    $html = (string) ($payload['html'] ?? '');

    if ($phase === 'lobby') {
        $slug = '';
        $title = '';
        $html = '';
    }

    if (strlen($html) > 1500000) {
        $html = substr($html, 0, 1500000);
    }

    $db = getDB();
    $now = date('Y-m-d H:i:s');
    $existing = $db->fetchOne(
        'SELECT terminal_id, phase, slug, html FROM terminal_top_display WHERE terminal_id = ? LIMIT 1',
        [$terminalId]
    );

    if (
        $phase === 'game'
        && $html === ''
        && $existing
        && strtolower(trim((string) ($existing['slug'] ?? ''))) === $slug
        && trim((string) ($existing['html'] ?? '')) !== ''
    ) {
        $html = (string) $existing['html'];
    }

    $data = [
        'phase' => $phase,
        'slug' => $slug,
        'title' => $title,
        'html' => $html,
        'updated_at' => $now,
    ];

    if ($existing) {
        $db->update('terminal_top_display', $data, 'terminal_id = :id', ['id' => $terminalId]);
    } else {
        $data['terminal_id'] = $terminalId;
        $db->insert('terminal_top_display', $data);
    }

    return termTopDisplayGet($terminalId);
}

function termTopDisplaySetGame(int $terminalId, string $slug, string $title = ''): array
{
    return termTopDisplaySave($terminalId, [
        'phase' => 'game',
        'slug' => $slug,
        'title' => $title,
        'html' => '',
    ]);
}

function termTopDisplaySetLobby(int $terminalId): array
{
    return termTopDisplaySave($terminalId, [
        'phase' => 'lobby',
        'slug' => '',
        'title' => '',
        'html' => '',
    ]);
}
