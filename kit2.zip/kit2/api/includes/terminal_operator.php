<?php

require_once __DIR__ . '/../../includes/auth.php';

function termKioskStartSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    require_once __DIR__ . '/../../config/session_config.php';

    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');

    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        ini_set('session.cookie_secure', '1');
    }

    session_name('skill_terminal_kiosk');
    session_start();
}

function termKioskOperatorRoles(): array
{
    return ['boss', 'colaborator', 'manager', 'statie', 'desfasurator', 'casier'];
}

function termKioskOperatorCurrent(): ?array
{
    $userId = (int) ($_SESSION['term_kiosk_operator_user_id'] ?? 0);
    $terminalId = (int) ($_SESSION['term_kiosk_operator_terminal_id'] ?? 0);

    if ($userId <= 0 || $terminalId <= 0) {
        return null;
    }

    try {
        $user = getDB()->fetchOne(
            'SELECT id, username, display_name, email, role, is_active, created_by FROM users WHERE id = ? LIMIT 1',
            [$userId]
        );

        if (!$user || !(int) $user['is_active']) {
            return null;
        }

        if (!in_array($user['role'] ?? '', termKioskOperatorRoles(), true)) {
            return null;
        }

        return [
            'user' => $user,
            'terminal_id' => $terminalId,
        ];
    } catch (Exception $e) {
        return null;
    }
}

function termKioskOperatorPayload(?array $session): ?array
{
    if ($session === null) {
        return null;
    }

    $user = $session['user'];

    return [
        'id' => (int) $user['id'],
        'username' => $user['username'],
        'display_name' => $user['display_name'] ?: $user['username'],
        'role' => $user['role'],
        'role_label' => termRoleLabel((string) $user['role']),
    ];
}

function termKioskTerminalContext(array $terminal): array
{
    $stationName = '';
    $stationCode = '';
    $stationId = (int) ($terminal['station_id'] ?? 0);

    if ($stationId > 0) {
        try {
            $station = getDB()->fetchOne(
                'SELECT name, code FROM stations WHERE id = ? AND is_active = 1 LIMIT 1',
                [$stationId]
            );
            if ($station) {
                $stationName = (string) ($station['name'] ?? '');
                $stationCode = (string) ($station['code'] ?? '');
            }
        } catch (Exception $e) {
        }
    }

    return [
        'id' => (int) $terminal['id'],
        'name' => (string) ($terminal['name'] ?? ''),
        'terminal_code' => (string) ($terminal['terminal_code'] ?? ''),
        'station_id' => $stationId > 0 ? $stationId : null,
        'station_name' => $stationName,
        'station_code' => $stationCode,
        'credits_balance' => termApiNormalizeCredits($terminal['credits_balance'] ?? 0),
        'credit_rate' => termTerminalCreditRate($terminal),
    ];
}

function termKioskOperatorCandidateIds(int $terminalId): array
{
    $roles = termKioskOperatorRoles();
    $rolePlaceholders = implode(',', array_fill(0, count($roles), '?'));
    $params = array_merge([$terminalId, $terminalId], $roles);

    try {
        $rows = getDB()->fetchAll(
            "SELECT DISTINCT u.id
             FROM users u
             LEFT JOIN terminal_assignments ta ON ta.user_id = u.id AND ta.terminal_id = ?
             LEFT JOIN terminals t ON t.id = ?
             LEFT JOIN stations s ON s.id = t.station_id AND s.manager_id = u.id
             WHERE u.is_active = 1
               AND u.role IN ({$rolePlaceholders})
               AND (
                    u.role IN ('boss', 'colaborator')
                    OR ta.user_id IS NOT NULL
                    OR s.manager_id IS NOT NULL
               )
             ORDER BY u.id ASC",
            $params
        );
    } catch (Exception $e) {
        return [];
    }

    $ids = [];
    foreach ($rows as $row) {
        $id = (int) ($row['id'] ?? 0);
        if ($id > 0) {
            $ids[] = $id;
        }
    }

    return $ids;
}

function termKioskOperatorAttemptLogin(array $terminal, string $username, string $password): array
{
    termEnsureCasierRole();
    $username = trim($username);
    $password = trim($password);

    if ($username === '' || $password === '') {
        return ['ok' => false, 'message' => 'Introdu utilizatorul și parola.'];
    }

    try {
        $user = getDB()->fetchOne(
            'SELECT id, username, password_hash, display_name, role, is_active, created_by
             FROM users
             WHERE username = ?
             LIMIT 1',
            [$username]
        );
    } catch (Exception $e) {
        return ['ok' => false, 'message' => 'Eroare la autentificare.'];
    }

    if (!$user || !(int) ($user['is_active'] ?? 0)) {
        return ['ok' => false, 'message' => 'Utilizator sau parolă incorectă.'];
    }

    if (!in_array((string) ($user['role'] ?? ''), termKioskOperatorRoles(), true)) {
        return ['ok' => false, 'message' => 'Acest cont nu poate deschide panoul de pe terminal.'];
    }

    $hash = trim((string) ($user['password_hash'] ?? ''));
    if ($hash === '' || !password_verify($password, $hash)) {
        return ['ok' => false, 'message' => 'Utilizator sau parolă incorectă.'];
    }

    $accessible = termAccessibleTerminalIds($user);
    if (!in_array((int) $terminal['id'], $accessible, true)) {
        return ['ok' => false, 'message' => 'Contul nu are acces la acest terminal.'];
    }

    termKioskStartSession();

    try {
        session_regenerate_id(true);
    } catch (Exception $e) {
    }

    $_SESSION['term_kiosk_operator_user_id'] = (int) $user['id'];
    $_SESSION['term_kiosk_operator_terminal_id'] = (int) $terminal['id'];

    try {
        getDB()->update('users', ['last_login_at' => date('Y-m-d H:i:s')], 'id = :where_id', ['where_id' => (int) $user['id']]);
    } catch (Exception $e) {
    }

    $session = termKioskOperatorCurrent();

    return [
        'ok' => true,
        'operator' => termKioskOperatorPayload($session),
    ];
}

function termKioskOperatorLogout(): void
{
    termKioskStartSession();
    unset($_SESSION['term_kiosk_operator_user_id'], $_SESSION['term_kiosk_operator_terminal_id']);
}

function termKioskRequireOperator(array $terminal): array
{
    $session = termKioskOperatorCurrent();

    if ($session === null) {
        termJson(['ok' => false, 'message' => 'Sesiune expirata. Autentifica-te din nou.'], 401);
    }

    if ((int) $session['terminal_id'] !== (int) $terminal['id']) {
        termKioskOperatorLogout();
        termJson(['ok' => false, 'message' => 'Sesiune invalida pentru acest terminal.'], 401);
    }

    $accessible = termAccessibleTerminalIds($session['user']);
    if (!in_array((int) $terminal['id'], $accessible, true)) {
        termKioskOperatorLogout();
        termJson(['ok' => false, 'message' => 'Contul nu mai are acces la acest terminal.'], 403);
    }

    return $session;
}

function termKioskOperatorReportTerminalIds(array $user, array $terminal): array
{
    $currentId = (int) ($terminal['id'] ?? 0);
    $stationId = (int) ($terminal['station_id'] ?? 0);
    if ($currentId <= 0) {
        return [];
    }

    $accessible = termAccessibleTerminalIds($user);
    if (!in_array($currentId, $accessible, true)) {
        return [];
    }

    if ($stationId <= 0) {
        return [$currentId];
    }

    try {
        $rows = getDB()->fetchAll(
            'SELECT id FROM terminals WHERE station_id = ? ORDER BY id ASC',
            [$stationId]
        );
    } catch (Throwable $e) {
        return [$currentId];
    }

    $ids = [];
    foreach (is_array($rows) ? $rows : [] as $row) {
        $id = (int) ($row['id'] ?? 0);
        if ($id > 0) {
            $ids[$id] = $id;
        }
    }

    return $ids !== [] ? array_values($ids) : [$currentId];
}

function termKioskTransactionTypeLabel(string $type): string
{
    $labels = [
        'money_in' => 'IN',
        'money_out' => 'OUT',
    ];

    return $labels[$type] ?? strtoupper($type);
}

function termKioskCashLei($value): string
{
    return number_format((float) $value, 2, ',', '.');
}

function termKioskOperatorCompany(array $terminal, array $user = []): array
{
    $location = trim((string) ($terminal['station_name'] ?? ''));
    $unitate = '';
    $cui = '';
    $nrJ = '';
    $sediu = '';
    $stationId = (int) ($terminal['station_id'] ?? 0);
    $shopId = 0;

    if ($stationId > 0) {
        try {
            $row = getDB()->fetchOne(
                'SELECT s.name, s.operator_id,
                        uo.unitate, uo.cui, uo.nr_j, uo.sediu, uo.role
                 FROM stations s
                 LEFT JOIN users uo ON uo.id = s.operator_id
                 WHERE s.id = ?
                 LIMIT 1',
                [$stationId]
            );
            if (is_array($row)) {
                if ($location === '') {
                    $location = trim((string) ($row['name'] ?? ''));
                }
                $shopId = (int) ($row['operator_id'] ?? 0);
                $unitate = trim((string) ($row['unitate'] ?? ''));
                $cui = trim((string) ($row['cui'] ?? ''));
                $nrJ = trim((string) ($row['nr_j'] ?? ''));
                $sediu = trim((string) ($row['sediu'] ?? ''));
            }
        } catch (Throwable $e) {
        }
    }

    if ($shopId <= 0 && $stationId > 0 && ($unitate === '' || $cui === '' || $nrJ === '' || $sediu === '')) {
        try {
            $assigned = getDB()->fetchOne(
                "SELECT u.id, u.unitate, u.cui, u.nr_j, u.sediu
                 FROM users u
                 INNER JOIN terminal_assignments ta ON ta.user_id = u.id AND ta.assignment_role = 'statie'
                 INNER JOIN terminals t ON t.id = ta.terminal_id
                 WHERE t.station_id = ?
                   AND u.role = 'statie'
                   AND u.is_active = 1
                 ORDER BY u.id ASC
                 LIMIT 1",
                [$stationId]
            );
            if (is_array($assigned)) {
                $shopId = (int) ($assigned['id'] ?? 0);
                if ($unitate === '') {
                    $unitate = trim((string) ($assigned['unitate'] ?? ''));
                }
                if ($cui === '') {
                    $cui = trim((string) ($assigned['cui'] ?? ''));
                }
                if ($nrJ === '') {
                    $nrJ = trim((string) ($assigned['nr_j'] ?? ''));
                }
                if ($sediu === '') {
                    $sediu = trim((string) ($assigned['sediu'] ?? ''));
                }
            }
        } catch (Throwable $e) {
        }
    }

    if ($unitate === '' || $cui === '' || $nrJ === '' || $sediu === '') {
        $role = (string) ($user['role'] ?? '');
        $sourceId = 0;
        if ($role === 'statie') {
            $sourceId = (int) ($user['id'] ?? 0);
        } elseif ($role === 'casier') {
            $sourceId = (int) ($user['created_by'] ?? 0);
        }
        if ($sourceId > 0) {
            try {
                $shop = getDB()->fetchOne(
                    "SELECT unitate, cui, nr_j, sediu FROM users WHERE id = ? AND role = 'statie' LIMIT 1",
                    [$sourceId]
                );
                if (is_array($shop)) {
                    if ($unitate === '') {
                        $unitate = trim((string) ($shop['unitate'] ?? ''));
                    }
                    if ($cui === '') {
                        $cui = trim((string) ($shop['cui'] ?? ''));
                    }
                    if ($nrJ === '') {
                        $nrJ = trim((string) ($shop['nr_j'] ?? ''));
                    }
                    if ($sediu === '') {
                        $sediu = trim((string) ($shop['sediu'] ?? ''));
                    }
                }
            } catch (Throwable $e) {
            }
        }
    }

    return [
        'unitate' => $unitate !== '' ? $unitate : '-',
        'cui' => $cui !== '' ? $cui : '-',
        'nr_j' => $nrJ !== '' ? $nrJ : '-',
        'sediu' => $sediu !== '' ? $sediu : '-',
        'location' => $location !== '' ? $location : 'Shop',
    ];
}

function termKioskCashHistoryNets(int $stationId, array $terminalIds): array
{
    $nets = [];
    $ids = [];
    foreach ($terminalIds as $terminalId) {
        $id = (int) $terminalId;
        if ($id > 0) {
            $ids[$id] = $id;
        }
    }

    if ($ids !== []) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        try {
            $rows = getDB()->fetchAll(
                "SELECT DATE(tt.created_at) AS day_key,
                        COALESCE(SUM(CASE WHEN tt.type = 'money_in' THEN tt.amount_money ELSE 0 END), 0)
                      - COALESCE(SUM(CASE WHEN tt.type = 'money_out' THEN tt.amount_money ELSE 0 END), 0) AS net_amount
                 FROM terminal_transactions tt
                 WHERE tt.terminal_id IN ({$placeholders})
                   AND tt.type IN ('money_in', 'money_out')
                 GROUP BY DATE(tt.created_at)",
                array_values($ids)
            );
            foreach (is_array($rows) ? $rows : [] as $row) {
                $day = substr((string) ($row['day_key'] ?? ''), 0, 10);
                if ($day === '') {
                    continue;
                }
                $nets[$day] = round((float) ($row['net_amount'] ?? 0), 2);
            }
        } catch (Throwable $e) {
        }
    }

    if ($stationId > 0) {
        try {
            $rows = getDB()->fetchAll(
                "SELECT DATE(created_at) AS day_key,
                        COALESCE(SUM(CASE WHEN doc_type = 'di' THEN amount ELSE 0 END), 0)
                      - COALESCE(SUM(CASE WHEN doc_type = 'dp' THEN amount ELSE 0 END), 0) AS net_amount
                 FROM shop_cash_docs
                 WHERE station_id = ?
                 GROUP BY DATE(created_at)",
                [$stationId]
            );
            foreach (is_array($rows) ? $rows : [] as $row) {
                $day = substr((string) ($row['day_key'] ?? ''), 0, 10);
                if ($day === '') {
                    continue;
                }
                $nets[$day] = round(($nets[$day] ?? 0) + (float) ($row['net_amount'] ?? 0), 2);
            }
        } catch (Throwable $e) {
        }
    }

    return $nets;
}

function termKioskOpeningSold(array $nets, string $day): float
{
    $sold = 0.0;
    foreach ($nets as $key => $net) {
        if (strcmp((string) $key, $day) < 0) {
            $sold += (float) $net;
        }
    }

    return round($sold, 2);
}

function termKioskBuildRegister(array $transactions, array $historyNets = []): array
{
    $byDay = [];
    foreach ($transactions as $row) {
        $created = (string) ($row['created_at'] ?? '');
        $day = substr($created, 0, 10);
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) !== 1) {
            $timestamp = strtotime($created);
            $day = $timestamp === false ? date('Y-m-d') : date('Y-m-d', $timestamp);
        }
        $byDay[$day][] = $row;
    }

    ksort($byDay);
    $sheets = [];

    foreach ($byDay as $day => $items) {
        $soldInitial = termKioskOpeningSold($historyNets, $day);
        $sumIn = 0.0;
        $sumDi = 0.0;
        $sumOut = 0.0;
        $sumDp = 0.0;

        foreach ($items as $item) {
            $kind = (string) ($item['kind'] ?? '');
            $amount = round((float) ($item['amount_money'] ?? 0), 2);
            if ($amount <= 0) {
                continue;
            }
            if ($kind === 'di') {
                $sumDi += $amount;
            } elseif ($kind === 'dp') {
                $sumDp += $amount;
            } elseif (($item['type'] ?? '') === 'money_in') {
                $sumIn += $amount;
            } else {
                $sumOut += $amount;
            }
        }

        $sumIn = round($sumIn, 2);
        $sumDi = round($sumDi, 2);
        $sumOut = round($sumOut, 2);
        $sumDp = round($sumDp, 2);

        $rowsSpec = [
            [
                'show' => $sumIn > 0.009,
                'terminal' => 'Terminale',
                'in_text' => 'Alimentare sold',
                'in_sum' => $sumIn,
                'out_text' => '',
                'out_sum' => 0.0,
                'delta' => $sumIn,
            ],
            [
                'show' => $sumDi > 0.009,
                'terminal' => 'Casă shop',
                'in_text' => 'Alimentare Numerar (DI)',
                'in_sum' => $sumDi,
                'out_text' => '',
                'out_sum' => 0.0,
                'delta' => $sumDi,
            ],
            [
                'show' => $sumOut > 0.009,
                'terminal' => 'Terminale',
                'in_text' => '',
                'in_sum' => 0.0,
                'out_text' => 'Restituire sold',
                'out_sum' => $sumOut,
                'delta' => -$sumOut,
            ],
            [
                'show' => $sumDp > 0.009,
                'terminal' => 'Casă shop',
                'in_text' => '',
                'in_sum' => 0.0,
                'out_text' => 'Retragere Numerar (DP)',
                'out_sum' => $sumDp,
                'delta' => -$sumDp,
            ],
        ];

        $sold = $soldInitial;
        $lines = [];
        $n = 1;
        foreach ($rowsSpec as $spec) {
            if (empty($spec['show'])) {
                continue;
            }
            $sold = round($sold + (float) $spec['delta'], 2);
            $lines[] = [
                'nr' => $n,
                'time' => '',
                'terminal' => (string) $spec['terminal'],
                'in_text' => (string) $spec['in_text'],
                'in_sum' => ((float) $spec['in_sum'] > 0.009) ? termKioskCashLei((float) $spec['in_sum']) : '',
                'out_text' => (string) $spec['out_text'],
                'out_sum' => ((float) $spec['out_sum'] > 0.009) ? termKioskCashLei((float) $spec['out_sum']) : '',
                'sold' => termKioskCashLei($sold),
            ];
            $n++;
        }

        $dayTs = strtotime($day . ' 12:00:00');
        $sheets[] = [
            'day' => $day,
            'day_label' => $dayTs === false ? $day : date('d.m.Y', $dayTs),
            'items' => $lines,
            'total_in' => termKioskCashLei($sumIn + $sumDi),
            'total_out' => termKioskCashLei($sumOut + $sumDp),
            'sold_initial' => termKioskCashLei($soldInitial),
            'sold_final' => termKioskCashLei($sold),
        ];
    }

    return $sheets;
}

function termKioskFetchShopCashDocsForReport(array $stationIds, string $periodSql): array
{
    $ids = [];
    foreach ($stationIds as $stationId) {
        $id = (int) $stationId;
        if ($id > 0) {
            $ids[$id] = $id;
        }
    }
    if ($ids === []) {
        return [];
    }

    $docPeriodSql = str_replace('tt.created_at', 'd.created_at', $periodSql);
    $docPeriodSql = str_replace('tt.', 'd.', $docPeriodSql);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    try {
        $rows = getDB()->fetchAll(
            "SELECT d.id, d.station_id, d.doc_type, d.series_no, d.code, d.amount, d.created_at,
                    s.name AS shop_name, s.code AS shop_code
             FROM shop_cash_docs d
             LEFT JOIN stations s ON s.id = d.station_id
             WHERE d.station_id IN ({$placeholders})
               AND {$docPeriodSql}
             ORDER BY d.created_at ASC, d.id ASC",
            array_values($ids)
        );
    } catch (Throwable $e) {
        return [];
    }

    $items = [];
    foreach (is_array($rows) ? $rows : [] as $row) {
        $docType = (string) ($row['doc_type'] ?? 'di');
        $isPay = $docType === 'dp';
        $code = trim((string) ($row['code'] ?? ''));
        if ($code === '') {
            $seriesNo = (int) ($row['series_no'] ?? 0);
            $code = strtoupper($docType) . '-' . $seriesNo;
        }
        $items[] = [
            'id' => (int) ($row['id'] ?? 0),
            'created_at' => (string) ($row['created_at'] ?? ''),
            'type' => $isPay ? 'money_out' : 'money_in',
            'kind' => $isPay ? 'dp' : 'di',
            'amount_money' => round((float) ($row['amount'] ?? 0), 2),
            'terminal_name' => 'Casă shop',
            'code' => $code,
            'shop_name' => trim((string) ($row['shop_name'] ?? '')),
            'shop_code' => trim((string) ($row['shop_code'] ?? '')),
        ];
    }

    return $items;
}

function termKioskOperatorReport(array $session, array $terminal, string $periodKey): array
{
    $user = $session['user'];
    $periodKey = termAdminNormalizeReportPeriod($periodKey);
    $periodMeta = termAdminReportPeriodMeta($periodKey);
    $hour = termAdminBusinessDayHour();
    $hourLabel = str_pad((string) $hour, 2, '0', STR_PAD_LEFT) . ':00';
    $periodLabel = $periodMeta['label'];
    if ($periodKey === '1d') {
        $periodLabel = 'Azi (' . $hourLabel . ' → ' . $hourLabel . ')';
    } elseif ($periodKey === 'yesterday') {
        $periodLabel = 'Ieri (' . $hourLabel . ' → ' . $hourLabel . ')';
    }
    $company = termKioskOperatorCompany($terminal, $user);
    $terminalIds = termKioskOperatorReportTerminalIds($user, $terminal);

    if ($terminalIds === []) {
        return [
            'period' => $periodKey,
            'period_label' => $periodLabel,
            'range_from' => date('d.m.Y'),
            'range_to' => date('d.m.Y'),
            'printed_at' => date('d.m.Y H:i'),
            'company' => $company,
            'register' => [],
            'summary' => [
                'total_in' => 0,
                'total_out' => 0,
                'profit' => 0,
                'total_credits' => 0,
                'credits_money' => 0,
                'net_profit' => 0,
            ],
            'terminals' => [],
            'daily' => [],
            'transactions' => [],
        ];
    }

    $placeholders = implode(',', array_fill(0, count($terminalIds), '?'));
    $periodSql = $periodMeta['transaction_sql'];

    $terminals = termAdminFetchTerminalPeriodStats($user, $periodKey);
    $terminals = array_values(array_filter($terminals, static function ($row) use ($terminalIds) {
        return in_array((int) ($row['id'] ?? 0), $terminalIds, true);
    }));

    $moneyTotals = termAdminFetchPeriodMoneyTotals($user, $periodKey, $terminals);

    $scopedCredits = 0.0;
    $scopedCreditsMoney = 0.0;
    foreach ($terminals as $row) {
        $scopedCredits += (float) ($row['credits_balance'] ?? 0);
        $scopedCreditsMoney += (float) ($row['credits_money'] ?? 0);
    }
    $scopedCredits = termApiNormalizeCredits($scopedCredits);
    $scopedCreditsMoney = round($scopedCreditsMoney, 2);
    $scopedNetProfit = round((float) ($moneyTotals['cash_profit'] ?? $moneyTotals['net_profit'] ?? 0), 2);

    $bizDay = termAdminBusinessDaySqlExpr('tt.created_at');

    try {
        $dailyRows = getDB()->fetchAll(
            "SELECT {$bizDay} AS day_key,
                    COALESCE(SUM(CASE WHEN tt.type = 'money_in' THEN tt.amount_money ELSE 0 END), 0) AS total_in,
                    COALESCE(SUM(CASE WHEN tt.type = 'money_out' THEN tt.amount_money ELSE 0 END), 0) AS total_out,
                    COUNT(*) AS tx_count
             FROM terminal_transactions tt
             WHERE tt.terminal_id IN ({$placeholders})
               AND tt.type IN ('money_in', 'money_out')
               AND {$periodSql}
             GROUP BY {$bizDay}
             ORDER BY day_key DESC",
            $terminalIds
        );

        $transactions = getDB()->fetchAll(
            "SELECT tt.id, tt.terminal_id, tt.type, tt.amount_credits, tt.amount_money, tt.balance_after, tt.created_at,
                    t.name AS terminal_name, t.terminal_code
             FROM terminal_transactions tt
             INNER JOIN terminals t ON t.id = tt.terminal_id
             WHERE tt.terminal_id IN ({$placeholders})
               AND tt.type IN ('money_in', 'money_out')
               AND {$periodSql}
             ORDER BY tt.created_at ASC, tt.id ASC
             LIMIT 500",
            $terminalIds
        );
    } catch (Exception $e) {
        error_log('termKioskOperatorReport: ' . $e->getMessage());
        $dailyRows = [];
        $transactions = [];
    }

    $daily = [];
    foreach ($dailyRows as $row) {
        $in = (float) ($row['total_in'] ?? 0);
        $out = (float) ($row['total_out'] ?? 0);
        $daily[(string) ($row['day_key'] ?? '')] = [
            'day' => (string) ($row['day_key'] ?? ''),
            'day_label' => termKioskFormatReportDay((string) ($row['day_key'] ?? '')),
            'total_in' => $in,
            'total_in_fmt' => termFormatMoney($in),
            'total_out' => $out,
            'total_out_fmt' => termFormatMoney($out),
            'profit' => round($in - $out, 2),
            'profit_fmt' => termFormatMoney($in - $out),
            'tx_count' => (int) ($row['tx_count'] ?? 0),
        ];
    }

    $txPayload = [];
    foreach ($transactions as $row) {
        $txPayload[] = [
            'id' => (int) ($row['id'] ?? 0),
            'terminal_id' => (int) ($row['terminal_id'] ?? 0),
            'terminal_name' => (string) ($row['terminal_name'] ?? ''),
            'terminal_code' => (string) ($row['terminal_code'] ?? ''),
            'type' => (string) ($row['type'] ?? ''),
            'type_label' => termKioskTransactionTypeLabel((string) ($row['type'] ?? '')),
            'amount_credits' => termApiNormalizeCredits($row['amount_credits'] ?? 0),
            'amount_money' => (float) ($row['amount_money'] ?? 0),
            'amount_money_fmt' => termFormatMoney($row['amount_money'] ?? 0),
            'balance_after' => termApiNormalizeCredits($row['balance_after'] ?? 0),
            'created_at' => (string) ($row['created_at'] ?? ''),
            'created_at_fmt' => termKioskFormatReportDateTime((string) ($row['created_at'] ?? '')),
        ];
    }

    $stationId = (int) ($terminal['station_id'] ?? 0);
    $cashDocs = $stationId > 0 ? termKioskFetchShopCashDocsForReport([$stationId], $periodSql) : [];
    $registerRows = [];
    foreach (is_array($transactions) ? $transactions : [] as $row) {
        $registerRows[] = [
            'created_at' => (string) ($row['created_at'] ?? ''),
            'type' => (string) ($row['type'] ?? ''),
            'kind' => '',
            'amount_money' => (float) ($row['amount_money'] ?? 0),
            'terminal_name' => (string) ($row['terminal_name'] ?? 'Terminal'),
            'code' => '',
        ];
    }
    foreach ($cashDocs as $doc) {
        $registerRows[] = $doc;
        $amount = round((float) ($doc['amount_money'] ?? 0), 2);
        $dayKey = substr((string) ($doc['created_at'] ?? ''), 0, 10);
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dayKey) !== 1) {
            $ts = strtotime((string) ($doc['created_at'] ?? ''));
            $dayKey = $ts === false ? date('Y-m-d') : date('Y-m-d', $ts);
        }
        if (!isset($daily[$dayKey])) {
            $daily[$dayKey] = [
                'day' => $dayKey,
                'day_label' => termKioskFormatReportDay($dayKey),
                'total_in' => 0.0,
                'total_in_fmt' => termFormatMoney(0),
                'total_out' => 0.0,
                'total_out_fmt' => termFormatMoney(0),
                'profit' => 0.0,
                'profit_fmt' => termFormatMoney(0),
                'tx_count' => 0,
            ];
        }
        if (($doc['kind'] ?? '') === 'di') {
            $moneyTotals['total_in'] = round((float) ($moneyTotals['total_in'] ?? 0) + $amount, 2);
            $daily[$dayKey]['total_in'] = round((float) $daily[$dayKey]['total_in'] + $amount, 2);
        } elseif (($doc['kind'] ?? '') === 'dp') {
            $moneyTotals['total_out'] = round((float) ($moneyTotals['total_out'] ?? 0) + $amount, 2);
            $daily[$dayKey]['total_out'] = round((float) $daily[$dayKey]['total_out'] + $amount, 2);
        }
        $daily[$dayKey]['tx_count'] = (int) $daily[$dayKey]['tx_count'] + 1;
        $daily[$dayKey]['profit'] = round((float) $daily[$dayKey]['total_in'] - (float) $daily[$dayKey]['total_out'], 2);
        $daily[$dayKey]['total_in_fmt'] = termFormatMoney($daily[$dayKey]['total_in']);
        $daily[$dayKey]['total_out_fmt'] = termFormatMoney($daily[$dayKey]['total_out']);
        $daily[$dayKey]['profit_fmt'] = termFormatMoney($daily[$dayKey]['profit']);
    }
    $moneyTotals['cash_profit'] = round((float) ($moneyTotals['total_in'] ?? 0) - (float) ($moneyTotals['total_out'] ?? 0), 2);
    $moneyTotals['profit'] = $moneyTotals['cash_profit'];
    $scopedNetProfit = $moneyTotals['cash_profit'];
    krsort($daily);
    $daily = array_values($daily);

    $terminalPayload = [];
    foreach ($terminals as $row) {
        $terminalPayload[] = [
            'id' => (int) ($row['id'] ?? 0),
            'name' => (string) ($row['name'] ?? ''),
            'terminal_code' => (string) ($row['terminal_code'] ?? ''),
            'station_name' => (string) ($row['station_name'] ?? ''),
            'period_in' => (float) ($row['period_in'] ?? 0),
            'period_in_fmt' => termFormatMoney($row['period_in'] ?? 0),
            'period_out' => (float) ($row['period_out'] ?? 0),
            'period_out_fmt' => termFormatMoney($row['period_out'] ?? 0),
            'credits_balance' => termApiNormalizeCredits($row['credits_balance'] ?? 0),
            'credits_money' => (float) ($row['credits_money'] ?? 0),
            'credits_money_fmt' => termFormatMoney($row['credits_money'] ?? 0),
            'net_profit' => (float) ($row['net_profit'] ?? 0),
            'net_profit_fmt' => termAdminFormatProfit($row['net_profit'] ?? 0),
        ];
    }

    $register = termKioskBuildRegister(
        $registerRows,
        termKioskCashHistoryNets($stationId, $terminalIds)
    );
    $rangeFrom = date('d.m.Y');
    $rangeTo = date('d.m.Y');
    if ($register !== []) {
        $rangeFrom = (string) ($register[0]['day_label'] ?? $rangeFrom);
        $rangeTo = (string) ($register[count($register) - 1]['day_label'] ?? $rangeTo);
    }

    return [
        'period' => $periodKey,
        'period_label' => $periodLabel,
        'range_from' => $rangeFrom,
        'range_to' => $rangeTo,
        'printed_at' => date('d.m.Y H:i'),
        'company' => $company,
        'register' => $register,
        'summary' => [
            'total_in' => (float) ($moneyTotals['total_in'] ?? 0),
            'total_in_fmt' => termFormatMoney($moneyTotals['total_in'] ?? 0),
            'total_out' => (float) ($moneyTotals['total_out'] ?? 0),
            'total_out_fmt' => termFormatMoney($moneyTotals['total_out'] ?? 0),
            'profit' => (float) ($moneyTotals['cash_profit'] ?? $moneyTotals['profit'] ?? 0),
            'profit_fmt' => termFormatMoney($moneyTotals['cash_profit'] ?? $moneyTotals['profit'] ?? 0),
            'total_credits' => $scopedCredits,
            'credits_money' => $scopedCreditsMoney,
            'credits_money_fmt' => termFormatMoney($scopedCreditsMoney),
            'net_profit' => $scopedNetProfit,
            'net_profit_fmt' => termAdminFormatProfit($scopedNetProfit),
        ],
        'terminals' => $terminalPayload,
        'daily' => $daily,
        'transactions' => $txPayload,
    ];
}

function termKioskFormatReportDay(string $dayKey): string
{
    if ($dayKey === '') {
        return '-';
    }

    $timestamp = strtotime($dayKey . ' 12:00:00');
    if ($timestamp === false) {
        return $dayKey;
    }

    return date('d.m.Y', $timestamp);
}

function termKioskFormatReportDateTime(string $value): string
{
    if ($value === '') {
        return '-';
    }

    $timestamp = strtotime($value);
    if ($timestamp === false) {
        return $value;
    }

    return date('d.m.Y H:i:s', $timestamp);
}

function termKioskOperatorPeriodOptions(): array
{
    $keys = ['1d', 'yesterday', '7d', '30d', 'all'];
    $options = [];
    $hour = termAdminBusinessDayHour();
    $hourLabel = str_pad((string) $hour, 2, '0', STR_PAD_LEFT) . ':00';

    foreach ($keys as $key) {
        $meta = termAdminReportPeriodMeta($key);
        $label = $meta['label'];
        if ($key === '1d') {
            $label = 'Azi (' . $hourLabel . ')';
        } elseif ($key === 'yesterday') {
            $label = 'Ieri (' . $hourLabel . ')';
        }
        $options[] = [
            'key' => $key,
            'label' => $label,
        ];
    }

    return $options;
}
