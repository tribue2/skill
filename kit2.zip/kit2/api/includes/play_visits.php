<?php

const TERM_PLAY_VISIT_IDLE_SECONDS = 60;

function termEnsurePlayVisitsTable(): void
{
    static $ready = false;
    if ($ready) {
        return;
    }

    try {
        getDB()->query(
            "CREATE TABLE IF NOT EXISTS play_visits (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                terminal_id int unsigned NOT NULL,
                started_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                ended_at datetime DEFAULT NULL,
                idle_since datetime DEFAULT NULL,
                end_reason enum('cashout','bust_idle','reset') DEFAULT NULL,
                money_in decimal(12,2) NOT NULL DEFAULT 0.00,
                money_out decimal(12,2) NOT NULL DEFAULT 0.00,
                bets int unsigned NOT NULL DEFAULT 0,
                PRIMARY KEY (id),
                KEY idx_play_visits_terminal_open (terminal_id, ended_at),
                KEY idx_play_visits_started (started_at),
                KEY idx_play_visits_idle (idle_since)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {
        error_log('termEnsurePlayVisitsTable: ' . $e->getMessage());
    }

    $ready = true;
}

function termPlayVisitCloseExpired(?int $terminalId = null): void
{
    termEnsurePlayVisitsTable();
    $seconds = (int) TERM_PLAY_VISIT_IDLE_SECONDS;
    $params = [];
    $sql = "UPDATE play_visits
            SET ended_at = DATE_ADD(idle_since, INTERVAL {$seconds} SECOND),
                end_reason = 'bust_idle',
                idle_since = NULL
            WHERE ended_at IS NULL
              AND idle_since IS NOT NULL
              AND idle_since <= DATE_SUB(NOW(), INTERVAL {$seconds} SECOND)";
    if ($terminalId !== null && $terminalId > 0) {
        $sql .= ' AND terminal_id = ?';
        $params[] = $terminalId;
    }

    try {
        getDB()->query($sql, $params);
    } catch (Throwable $e) {
        error_log('termPlayVisitCloseExpired: ' . $e->getMessage());
    }
}

function termPlayVisitFindOpen(int $terminalId): ?array
{
    if ($terminalId <= 0) {
        return null;
    }

    try {
        $row = getDB()->fetchOne(
            'SELECT * FROM play_visits
             WHERE terminal_id = ? AND ended_at IS NULL
             ORDER BY id DESC
             LIMIT 1',
            [$terminalId]
        );
    } catch (Throwable $e) {
        error_log('termPlayVisitFindOpen: ' . $e->getMessage());
        return null;
    }

    return is_array($row) ? $row : null;
}

function termPlayVisitEnsureOpen(int $terminalId): ?array
{
    $open = termPlayVisitFindOpen($terminalId);
    if ($open !== null) {
        return $open;
    }

    try {
        $id = (int) getDB()->insert('play_visits', [
            'terminal_id' => $terminalId,
            'started_at' => date('Y-m-d H:i:s'),
        ]);
        if ($id <= 0) {
            return null;
        }

        return termPlayVisitFindOpen($terminalId);
    } catch (Throwable $e) {
        error_log('termPlayVisitEnsureOpen: ' . $e->getMessage());
        return null;
    }
}

function termPlayVisitClose(int $visitId, string $reason, ?string $endedAt = null): void
{
    $allowed = ['cashout' => true, 'bust_idle' => true, 'reset' => true];
    if ($visitId <= 0 || !isset($allowed[$reason])) {
        return;
    }

    try {
        getDB()->update('play_visits', [
            'ended_at' => $endedAt ?: date('Y-m-d H:i:s'),
            'idle_since' => null,
            'end_reason' => $reason,
        ], 'id = :id AND ended_at IS NULL', [
            'id' => $visitId,
        ]);
    } catch (Throwable $e) {
        error_log('termPlayVisitClose: ' . $e->getMessage());
    }
}

function termPlayVisitOnActivity(int $terminalId, float $balanceAfter, array $delta = []): void
{
    if ($terminalId <= 0) {
        return;
    }

    termEnsurePlayVisitsTable();
    termPlayVisitCloseExpired($terminalId);

    $hasCredits = $balanceAfter >= 0.01;
    $moneyIn = round(max(0, (float) ($delta['money_in'] ?? 0)), 2);
    $moneyOut = round(max(0, (float) ($delta['money_out'] ?? 0)), 2);
    $bets = max(0, (int) ($delta['bets'] ?? 0));

    $open = termPlayVisitFindOpen($terminalId);
    if ($open === null && !$hasCredits && $moneyIn < 0.01 && $bets <= 0) {
        return;
    }

    $visit = $open ?? termPlayVisitEnsureOpen($terminalId);
    if ($visit === null) {
        return;
    }

    $visitId = (int) ($visit['id'] ?? 0);
    if ($visitId <= 0) {
        return;
    }

    $patch = [];
    if ($moneyIn > 0.009) {
        $patch['money_in'] = round((float) ($visit['money_in'] ?? 0) + $moneyIn, 2);
    }
    if ($moneyOut > 0.009) {
        $patch['money_out'] = round((float) ($visit['money_out'] ?? 0) + $moneyOut, 2);
    }
    if ($bets > 0) {
        $patch['bets'] = (int) ($visit['bets'] ?? 0) + $bets;
    }

    if ($hasCredits) {
        $patch['idle_since'] = null;
    } elseif ($moneyOut > 0.009) {
        if ($patch !== []) {
            try {
                getDB()->update('play_visits', $patch, 'id = :id AND ended_at IS NULL', [
                    'id' => $visitId,
                ]);
            } catch (Throwable $e) {
                error_log('termPlayVisitOnActivity: ' . $e->getMessage());
            }
        }
        termPlayVisitClose($visitId, 'cashout');
        return;
    } elseif (empty($visit['idle_since'])) {
        $patch['idle_since'] = date('Y-m-d H:i:s');
    }

    if ($patch === []) {
        return;
    }

    try {
        getDB()->update('play_visits', $patch, 'id = :id AND ended_at IS NULL', [
            'id' => $visitId,
        ]);
    } catch (Throwable $e) {
        error_log('termPlayVisitOnActivity: ' . $e->getMessage());
    }
}

function termPlayVisitOnHeartbeat(int $terminalId, float $creditsBalance): void
{
    if ($terminalId <= 0) {
        return;
    }

    termEnsurePlayVisitsTable();
    termPlayVisitCloseExpired($terminalId);

    if ($creditsBalance >= 0.01) {
        termPlayVisitOnActivity($terminalId, $creditsBalance);
    }
}

function termPlayVisitPeriodSql(array $periodContext): string
{
    $sql = (string) ($periodContext['meta']['transaction_sql'] ?? '1 = 1');
    $sql = str_replace('tt.created_at', 'pv.started_at', $sql);

    return str_replace('tt.', 'pv.', $sql);
}

function termPlayVisitCount(array $user, array $periodContext): int
{
    termEnsurePlayVisitsTable();
    [$filterSql, $filterParams] = termTerminalFilterSql($user, 't');
    $periodSql = termPlayVisitPeriodSql($periodContext);

    try {
        $row = getDB()->fetchOne(
            "SELECT COUNT(*) AS total
             FROM play_visits pv
             INNER JOIN terminals t ON t.id = pv.terminal_id
             WHERE {$filterSql} AND {$periodSql}",
            $filterParams
        );
    } catch (Throwable $e) {
        error_log('termPlayVisitCount: ' . $e->getMessage());
        return 0;
    }

    return (int) ($row['total'] ?? 0);
}

function termPlayVisitDailySeries(array $user): array
{
    termEnsurePlayVisitsTable();
    [$filterSql, $filterParams] = termTerminalFilterSql($user, 't');
    $days = [];
    for ($i = 6; $i >= 0; $i--) {
        $days[date('Y-m-d', strtotime('-' . $i . ' days'))] = 0;
    }

    try {
        $bizDay = termAdminBusinessDaySqlExpr('pv.started_at');
        $bizToday = termAdminCurrentBusinessDaySqlExpr();
        $rows = getDB()->fetchAll(
            "SELECT {$bizDay} AS day_key, COUNT(*) AS total
             FROM play_visits pv
             INNER JOIN terminals t ON t.id = pv.terminal_id
             WHERE {$filterSql}
               AND {$bizDay} >= DATE_SUB({$bizToday}, INTERVAL 6 DAY)
             GROUP BY day_key
             ORDER BY day_key ASC",
            $filterParams
        );
        foreach (is_array($rows) ? $rows : [] as $row) {
            $key = (string) ($row['day_key'] ?? '');
            if (isset($days[$key])) {
                $days[$key] = (int) ($row['total'] ?? 0);
            }
        }
    } catch (Throwable $e) {
        error_log('termPlayVisitDailySeries: ' . $e->getMessage());
    }

    return array_values($days);
}

function termPlayVisitDurationLabel(?string $from): string
{
    $from = trim((string) $from);
    if ($from === '') {
        return '';
    }

    $start = strtotime($from);
    if ($start === false) {
        return '';
    }

    $seconds = max(0, time() - $start);
    if ($seconds < 60) {
        return 'acum';
    }

    if ($seconds < 3600) {
        return (string) (int) floor($seconds / 60) . ' min';
    }

    $hours = (int) floor($seconds / 3600);
    $minutes = (int) floor(($seconds % 3600) / 60);
    if ($minutes <= 0) {
        return (string) $hours . ' h';
    }

    return (string) $hours . ' h ' . (string) $minutes . ' min';
}

function termPlayVisitDashboard(array $user, array $periodContext): array
{
    termEnsurePlayVisitsTable();
    termPlayVisitCloseExpired();

    $empty = [
        'visits' => 0,
        'prev_visits' => 0,
        'playing' => 0,
        'free' => 0,
        'terminals' => [],
        'series' => [0, 0],
        'hidden' => 0,
    ];

    [$filterSql, $filterParams] = termTerminalFilterSql($user, 't');
    $visits = termPlayVisitCount($user, $periodContext);
    $prevContext = function_exists('iqwinAdminPreviousPeriodContext')
        ? iqwinAdminPreviousPeriodContext($periodContext)
        : $periodContext;
    $prevVisits = termPlayVisitCount($user, $prevContext);
    $series = termPlayVisitDailySeries($user);

    $bizToday = termAdminCurrentBusinessDaySqlExpr();
    $bizStarted = termAdminBusinessDaySqlExpr('pv.started_at');

    try {
        $rows = getDB()->fetchAll(
            "SELECT t.id, t.name, t.terminal_code, t.status, t.credits_balance, t.last_heartbeat_at,
                    s.name AS station_name,
                    v.id AS visit_id, v.started_at AS visit_started_at, v.idle_since,
                    (
                        SELECT COUNT(*)
                        FROM play_visits pv
                        WHERE pv.terminal_id = t.id
                          AND {$bizStarted} = {$bizToday}
                    ) AS visits_today
             FROM terminals t
             LEFT JOIN stations s ON s.id = t.station_id
             LEFT JOIN play_visits v ON v.terminal_id = t.id AND v.ended_at IS NULL
             WHERE {$filterSql} AND t.is_active = 1
             ORDER BY t.name ASC",
            $filterParams
        );
    } catch (Throwable $e) {
        error_log('termPlayVisitDashboard: ' . $e->getMessage());
        $empty['visits'] = $visits;
        $empty['prev_visits'] = $prevVisits;
        $empty['series'] = $series;

        return $empty;
    }

    $terminals = [];
    $playing = 0;
    foreach (is_array($rows) ? $rows : [] as $row) {
        $credits = (float) ($row['credits_balance'] ?? 0);
        $isPlaying = $credits >= 0.01;
        if ($isPlaying) {
            $playing++;
        }
        $started = $isPlaying ? (string) ($row['visit_started_at'] ?? '') : '';
        $terminals[] = [
            'id' => (int) ($row['id'] ?? 0),
            'name' => (string) ($row['name'] ?? ''),
            'code' => (string) ($row['terminal_code'] ?? ''),
            'station' => (string) ($row['station_name'] ?? ''),
            'playing' => $isPlaying,
            'since' => termPlayVisitDurationLabel($started !== '' ? $started : null),
            'today' => (int) ($row['visits_today'] ?? 0),
            'online' => (string) ($row['status'] ?? '') === 'online',
        ];
    }

    usort($terminals, static function (array $a, array $b): int {
        if ($a['playing'] !== $b['playing']) {
            return $a['playing'] ? -1 : 1;
        }
        return strcasecmp($a['name'], $b['name']);
    });

    $total = is_array($rows) ? count($rows) : 0;
    $limit = 16;
    $hidden = max(0, count($terminals) - $limit);
    if ($hidden > 0) {
        $terminals = array_slice($terminals, 0, $limit);
    }

    return [
        'visits' => $visits,
        'prev_visits' => $prevVisits,
        'playing' => $playing,
        'free' => max(0, $total - $playing),
        'terminals' => $terminals,
        'series' => $series,
        'hidden' => $hidden,
    ];
}
