<?php

declare(strict_types=1);

final class IqwinWordSearchEngine
{
    public const SIZE = 6;
    public const TIME_LIMIT_MS = 5000;
    public const TIME_GRACE_MS = 2000;

    private const WORDS = [
        'NOROC',
        'REGELE',
        'CARTEA',
        'LOGICA',
        'CREIER',
        'CASTIG',
        'PREMIU',
        'STEAUA',
        'AURUL',
        'BANII',
        'REGINA',
        'MINTEA',
    ];

    private const DIRS = [
        [0, 1],
    ];

    private const FILL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

    public static function build(int $sessionId): array
    {
        $usable = [];
        foreach (self::WORDS as $word) {
            if (strlen($word) >= 5 && strlen($word) <= self::SIZE) {
                $usable[] = $word;
            }
        }
        $count = count($usable);
        $word = $usable[self::mod($sessionId, $count)];
        $letters = str_split($word);
        $len = count($letters);
        $dir = self::DIRS[self::mod($sessionId * 7 + 3, count(self::DIRS))];
        $start = self::findStart($sessionId, $len, $dir);

        $grid = [];
        for ($r = 0; $r < self::SIZE; $r += 1) {
            $row = [];
            for ($c = 0; $c < self::SIZE; $c += 1) {
                $row[] = self::FILL[self::mod($sessionId * 13 + $r * 17 + $c * 29 + 5, 26)];
            }
            $grid[] = $row;
        }

        $path = [];
        for ($i = 0; $i < $len; $i += 1) {
            $r = $start[0] + $dir[0] * $i;
            $c = $start[1] + $dir[1] * $i;
            $grid[$r][$c] = $letters[$i];
            $path[] = [$r, $c];
        }

        $rows = [];
        foreach ($grid as $row) {
            $rows[] = implode('', $row);
        }

        return [
            'word' => $word,
            'grid' => $rows,
            'size' => self::SIZE,
            'duration_ms' => self::TIME_LIMIT_MS,
        ];
    }

    public static function sign(int $sessionId, int $gameId, int $t0Ms, string $secret): string
    {
        $payload = $sessionId . '|' . $gameId . '|' . $t0Ms;
        return $t0Ms . '.' . hash_hmac('sha256', $payload, $secret);
    }

    public static function readToken(?string $token, int $sessionId, int $gameId, string $secret): ?int
    {
        if (!is_string($token) || $token === '' || strpos($token, '.') === false) {
            return null;
        }
        [$t0Raw, $mac] = explode('.', $token, 2);
        if (!ctype_digit($t0Raw) || $mac === '') {
            return null;
        }
        $t0 = (int) $t0Raw;
        $expected = hash_hmac('sha256', $sessionId . '|' . $gameId . '|' . $t0, $secret);
        if (!hash_equals($expected, $mac)) {
            return null;
        }

        return $t0;
    }

    public static function parsePath($raw): ?array
    {
        if (!is_array($raw) || $raw === []) {
            return null;
        }
        $path = [];
        foreach ($raw as $cell) {
            if (is_array($cell) && array_key_exists('r', $cell) && array_key_exists('c', $cell)) {
                $r = (int) $cell['r'];
                $c = (int) $cell['c'];
            } elseif (is_array($cell) && isset($cell[0], $cell[1])) {
                $r = (int) $cell[0];
                $c = (int) $cell[1];
            } else {
                return null;
            }
            if ($r < 0 || $r >= self::SIZE || $c < 0 || $c >= self::SIZE) {
                return null;
            }
            $path[] = [$r, $c];
        }

        return $path;
    }

    public static function pathMatches(array $puzzle, array $path): bool
    {
        $word = (string) ($puzzle['word'] ?? '');
        $grid = $puzzle['grid'] ?? [];
        if ($word === '' || !is_array($grid) || count($path) !== strlen($word)) {
            return false;
        }

        $seen = [];
        $got = '';
        $sdr = null;
        $sdc = null;
        foreach ($path as $i => [$r, $c]) {
            $key = $r . ',' . $c;
            if (isset($seen[$key])) {
                return false;
            }
            $seen[$key] = true;
            $row = $grid[$r] ?? '';
            if (!is_string($row) || !isset($row[$c])) {
                return false;
            }
            $got .= $row[$c];
            if ($i === 0) {
                continue;
            }
            $dr = $r - $path[$i - 1][0];
            $dc = $c - $path[$i - 1][1];
            if ($i === 1) {
                if ($dr !== 0 || abs($dc) !== 1) {
                    return false;
                }
                $sdr = $dr;
                $sdc = $dc;
            } elseif ($dr !== $sdr || $dc !== $sdc) {
                return false;
            }
        }

        return $got === $word;
    }

    public static function withinTime(int $t0Ms, ?int $nowMs = null): bool
    {
        $now = $nowMs ?? (int) round(microtime(true) * 1000);

        return ($now - $t0Ms) <= (self::TIME_LIMIT_MS + self::TIME_GRACE_MS)
            && ($now - $t0Ms) >= 0;
    }

    private static function findStart(int $sessionId, int $len, array $dir): array
    {
        $offset = self::mod($sessionId * 11 + 19, self::SIZE * self::SIZE);
        for ($n = 0; $n < self::SIZE * self::SIZE; $n += 1) {
            $idx = ($offset + $n) % (self::SIZE * self::SIZE);
            $r = intdiv($idx, self::SIZE);
            $c = $idx % self::SIZE;
            $endR = $r + $dir[0] * ($len - 1);
            $endC = $c + $dir[1] * ($len - 1);
            if ($endR >= 0 && $endR < self::SIZE && $endC >= 0 && $endC < self::SIZE) {
                return [$r, $c];
            }
        }

        return [0, 0];
    }

    private static function mod(int $value, int $mod): int
    {
        if ($mod <= 0) {
            return 0;
        }
        $r = $value % $mod;
        return $r < 0 ? $r + $mod : $r;
    }
}
