<?php

require_once __DIR__ . '/../includes/terminal_api.php';
require_once __DIR__ . '/../includes/games/skill_spin_physics.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Terminal-Code, X-Terminal-Secret');
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    termJson(['ok' => false, 'message' => 'Metoda invalida.'], 405);
}

try {
    $terminal = termApiRequireTerminal();
    $body = termApiReadJsonBody();
    $action = trim((string) ($body['action'] ?? ''));

    $db = getDB();
    $terminalId = (int) $terminal['id'];
    $creditRate = termTerminalCreditRate($terminal);

    if ($action === 'ping') {
        termJson([
            'ok' => true,
            'credits_balance' => termApiCreditsBalance($terminal),
        ] + termApiStackerPayload($terminal));
    }

    if ($action === 'money_in') {
        $gameOverlayOpen = filter_var($body['game_overlay_open'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $notes = trim((string) ($body['notes'] ?? ''));
        if ($notes === '') {
            $notes = 'manual_kiosk';
        }
        $fromValidator = ($notes === 'itl_validator' || $notes === 'uba_validator' || $notes === 'bill_validator');
        $eventId = trim((string) ($body['event_id'] ?? $body['idempotency_key'] ?? ''));
        if ($eventId === '') {
            termJson(['ok' => false, 'message' => 'Lipseste event_id pentru creditare.'], 422);
        }
        if (strlen($eventId) > 80) {
            termJson(['ok' => false, 'message' => 'event_id invalid.'], 422);
        }

        SkillSpinPhysics::ensureSchema();
        $existing = null;
        try {
            $existing = $db->fetchOne(
                'SELECT amount_credits, balance_after, amount_money FROM terminal_transactions
                 WHERE terminal_id = ? AND type = ? AND idempotency_key = ? LIMIT 1',
                [$terminalId, 'money_in', $eventId]
            );
        } catch (Throwable $e) {
            $existing = null;
        }
        if ($existing) {
            termJson([
                'ok' => true,
                'credits_balance' => termApiFetchCreditsBalanceById($terminalId),
                'credits_added' => termApiNormalizeCredits($existing['amount_credits'] ?? 0),
                'amount_money' => (float) ($existing['amount_money'] ?? 0),
                'duplicate' => true,
            ] + termApiStackerPayload(termApiFetchStackerTerminal($terminalId)));
        }

        if (!$fromValidator) {
            if (!$gameOverlayOpen) {
                termApiCloseAllOpenGameSessions($terminalId);
            } elseif (termApiTerminalHasOpenGame($terminalId)) {
                termJson(['ok' => false, 'message' => 'Nu poti introduce bani in timpul jocului.'], 423);
            }
        }

        $amountMoney = round(max(0, (float) ($body['amount_money'] ?? 0)), 2);

        if ($amountMoney < 0.01) {
            termJson(['ok' => false, 'message' => 'Suma invalida.'], 422);
        }

        $creditsAdded = (int) floor($amountMoney / $creditRate);
        if ($creditsAdded <= 0) {
            termJson(['ok' => false, 'message' => 'Suma prea mica.'], 422);
        }

        $currentBalance = termApiCreditsBalance($terminal);
        $maxCredits = termApiMaxCreditsForTerminal($terminal);
        $roomLeft = $maxCredits - $currentBalance;
        $creditsAdded = min($creditsAdded, max(0, (int) floor($roomLeft)));

        if ($creditsAdded <= 0) {
            $maxLei = termApiMaxTerminalLei();
            termJson(['ok' => false, 'message' => 'Sold maxim ' . number_format($maxLei, 2, ',', '.') . ' LEI atins.'], 422);
        }

        $balance = termApiClampCreditsToCap($currentBalance + $creditsAdded, $terminal);
        $moneyInTotal = round((float) $terminal['money_in_total'] + $amountMoney, 2);

        try {
            $db->insert('terminal_transactions', [
                'terminal_id' => $terminalId,
                'type' => 'money_in',
                'amount_credits' => $creditsAdded,
                'amount_money' => $amountMoney,
                'balance_after' => $balance,
                'notes' => $notes,
                'idempotency_key' => $eventId,
            ]);
        } catch (Throwable $e) {
            $dup = $db->fetchOne(
                'SELECT amount_credits, amount_money FROM terminal_transactions
                 WHERE terminal_id = ? AND type = ? AND idempotency_key = ? LIMIT 1',
                [$terminalId, 'money_in', $eventId]
            );
            if ($dup) {
                termJson([
                    'ok' => true,
                    'credits_balance' => termApiFetchCreditsBalanceById($terminalId),
                    'credits_added' => termApiNormalizeCredits($dup['amount_credits'] ?? 0),
                    'amount_money' => (float) ($dup['amount_money'] ?? 0),
                    'duplicate' => true,
                ] + termApiStackerPayload(termApiFetchStackerTerminal($terminalId)));
            }
            throw $e;
        }

        $db->update('terminals', [
            'credits_balance' => $balance,
            'money_in_total' => $moneyInTotal,
        ], 'id = :id', ['id' => $terminalId]);

        termPlayVisitOnActivity($terminalId, (float) $balance, [
            'money_in' => $amountMoney,
        ]);

        $stacker = $fromValidator
            ? termApiIncrementStackerBills($terminalId)
            : termApiStackerPayload(termApiFetchStackerTerminal($terminalId));

        termJson([
            'ok' => true,
            'credits_balance' => $balance,
            'credits_added' => $creditsAdded,
            'amount_money' => $amountMoney,
            'money_in_total' => $moneyInTotal,
        ] + $stacker);
    }

    if ($action === 'stacker_reset') {
        $notes = trim((string) ($body['notes'] ?? ''));
        if ($notes === '') {
            $notes = 'stacker_reset';
        }
        $stacker = termApiResetStackerBills($terminalId, $notes);
        termJson(['ok' => true] + $stacker);
    }

    if ($action === 'money_out') {
        $balance = termApiCreditsBalance($terminal);
        $maxWholeCredits = (int) floor($balance);
        $cap = termApiBalanceCapPayload($terminal);
        $forced = filter_var($body['forced'] ?? false, FILTER_VALIDATE_BOOLEAN);

        if ($maxWholeCredits <= 0) {
            termJson(['ok' => false, 'message' => 'Nu ai sold intreg de retras.'], 422);
        }

        $creditsOut = $maxWholeCredits;
        $requestedCredits = (int) ($body['credits'] ?? 0);
        if ($requestedCredits > 0) {
            $creditsOut = min($maxWholeCredits, $requestedCredits);
        }

        if ($creditsOut <= 0) {
            termJson(['ok' => false, 'message' => 'Suma invalida.'], 422);
        }

        $validationError = termApiValidateMoneyOutCredits($terminal, $creditsOut);
        if ($validationError) {
            termJson(['ok' => false, 'message' => $validationError], 422);
        }

        if ($forced) {
            if (!$cap['balance_over_cap']) {
                termJson(['ok' => false, 'message' => 'Retragerea obligatorie nu este necesara.'], 422);
            }
        }

        $grossMoney = round($creditsOut * $creditRate, 2);
        $payout = termApiCalculateWithdrawalPayout($grossMoney);
        $amountMoney = (float) $payout['net_money'];
        $newBalance = termApiNormalizeCredits($balance - $creditsOut);

        $moneyOutTotal = round((float) $terminal['money_out_total'] + $amountMoney, 2);

        $db->insert('terminal_transactions', [
            'terminal_id' => $terminalId,
            'type' => 'money_out',
            'amount_credits' => $creditsOut,
            'amount_money' => $amountMoney,
            'balance_after' => $newBalance,
            'notes' => 'manual_kiosk',
        ]);

        $db->update('terminals', [
            'credits_balance' => $newBalance,
            'money_out_total' => $moneyOutTotal,
        ], 'id = :id', ['id' => $terminalId]);

        termPlayVisitOnActivity($terminalId, (float) $newBalance, [
            'money_out' => $amountMoney,
        ]);

        termJson([
            'ok' => true,
            'credits_balance' => $newBalance,
            'credits_out' => $creditsOut,
            'amount_money' => $amountMoney,
            'gross_money' => $grossMoney,
            'tax_money' => 0,
            'money_out_total' => $moneyOutTotal,
            'balance_cap' => termApiBalanceCapPayload($terminal),
        ]);
    }

    termJson(['ok' => false, 'message' => 'Actiune invalida.'], 400);
} catch (Throwable $e) {
    error_log('credits.php: ' . $e->getMessage());
    termJson(['ok' => false, 'message' => 'Eroare server.'], 500);
}
