<?php

require_once __DIR__ . '/../includes/terminal_api.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    termJson(['ok' => false, 'message' => 'Metoda invalida.'], 405);
}

try {
    $body = termApiReadJsonBody();

    $pairCode = strtoupper(trim((string) ($body['pair_code'] ?? '')));
    if ($pairCode === '') {
        termJson(['ok' => false, 'message' => 'Codul de pairing lipseste.'], 422);
    }

    $row = getDB()->fetchOne(
        'SELECT pc.*, t.name, t.terminal_code, t.api_secret
         FROM terminal_pairing_codes pc
         INNER JOIN terminals t ON t.id = pc.terminal_id
         WHERE pc.pair_code = ?
           AND t.is_active = 1
         LIMIT 1',
        [$pairCode]
    );

    if (!$row) {
        termJson(['ok' => false, 'message' => 'Cod invalid.'], 404);
    }

    $newSecret = termGenerateSecret(24);

    getDB()->update('terminals', [
        'api_secret' => $newSecret,
        'status' => 'online',
        'last_heartbeat_at' => date('Y-m-d H:i:s'),
        'last_ip' => $_SERVER['REMOTE_ADDR'] ?? null,
    ], 'id = :where_id', ['where_id' => (int) $row['terminal_id']]);

    termJson([
        'ok' => true,
        'terminal' => [
            'id' => (int) $row['terminal_id'],
            'name' => $row['name'],
            'terminal_code' => $row['terminal_code'],
            'api_secret' => $newSecret,
        ],
    ]);
} catch (Throwable $e) {
    termJson(['ok' => false, 'message' => 'Eroare server pairing.'], 500);
}
