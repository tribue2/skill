<?php

require_once __DIR__ . '/../includes/terminal_api.php';
require_once __DIR__ . '/../includes/terminal_operator.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Terminal-Code, X-Terminal-Secret');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Credentials: true');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    termKioskStartSession();
    $terminal = termApiRequireTerminal();
    termApiUpdateHeartbeat($terminal);

    $body = termApiReadJsonBody();
    $action = trim((string) ($_GET['action'] ?? $body['action'] ?? ''));

    if ($action === 'context') {
        $session = termKioskOperatorCurrent();
        termJson([
            'ok' => true,
            'terminal' => termKioskTerminalContext($terminal),
            'operator' => termKioskOperatorPayload($session),
            'periods' => termKioskOperatorPeriodOptions(),
        ]);
    }

    if ($action === 'session') {
        $session = termKioskOperatorCurrent();
        termJson([
            'ok' => true,
            'operator' => termKioskOperatorPayload($session),
        ]);
    }

    if ($action === 'login') {
        $username = trim((string) ($body['username'] ?? ''));
        $password = trim((string) ($body['password'] ?? ''));
        $result = termKioskOperatorAttemptLogin($terminal, $username, $password);

        if (empty($result['ok'])) {
            termJson([
                'ok' => false,
                'message' => $result['message'] ?? 'Autentificare esuata.',
            ], 401);
        }

        termJson([
            'ok' => true,
            'operator' => $result['operator'] ?? null,
            'terminal' => termKioskTerminalContext($terminal),
        ]);
    }

    if ($action === 'logout') {
        termKioskOperatorLogout();
        termJson(['ok' => true]);
    }

    if ($action === 'report') {
        $session = termKioskRequireOperator($terminal);
        $period = termAdminNormalizeReportPeriod((string) ($body['period'] ?? $_GET['period'] ?? '1d'));
        $report = termKioskOperatorReport($session, $terminal, $period);

        termJson([
            'ok' => true,
            'operator' => termKioskOperatorPayload($session),
            'terminal' => termKioskTerminalContext($terminal),
            'report' => $report,
            'periods' => termKioskOperatorPeriodOptions(),
        ]);
    }

    termJson(['ok' => false, 'message' => 'Actiune necunoscuta.'], 400);
} catch (Throwable $e) {
    error_log('operator.php: ' . $e->getMessage());
    termJson(['ok' => false, 'message' => 'Eroare server operator.'], 500);
}
