<?php

require_once __DIR__ . '/../includes/terminal_api.php';
require_once __DIR__ . '/../includes/multiplayer_contest.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Terminal-Code, X-Terminal-Secret');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    $terminal = termApiRequireTerminal();
    termApiCloseAllOpenGameSessions((int) $terminal['id']);
    termApiUpdateHeartbeat($terminal);
    termApiMarkOffline();

    $games = termApiActiveGames();
    $contest = termMpBuildPayloadForTerminal($terminal);

    termJson([
        'ok' => true,
        'terminal' => [
            'id' => (int) $terminal['id'],
            'station_id' => (int) ($terminal['station_id'] ?? 0),
            'name' => $terminal['name'],
            'terminal_code' => $terminal['terminal_code'],
            'status' => $terminal['status'],
            'credits_balance' => termApiFetchCreditsBalanceById((int) $terminal['id']),
            'credit_rate' => termTerminalCreditRate($terminal),
        ] + termApiStackerPayload($terminal),
        'games' => array_map(static function ($game) {
            $isFrozen = (int) ($game['is_frozen'] ?? 0) === 1;

            return [
                'id' => (int) $game['id'],
                'slot' => (int) $game['slot_number'],
                'slug' => $game['slug'],
                'title' => $game['title'],
                'subtitle' => $game['subtitle'],
                'icon_key' => $game['icon_key'],
                'status' => $game['status'],
                'frozen' => $isFrozen,
                'playable' => $game['status'] === 'active' && !empty($game['game_url']) && !$isFrozen,
                'game_url' => $game['game_url'],
                'min_bet' => (int) $game['min_bet'],
                'max_bet' => (int) $game['max_bet'],
            ];
        }, $games),
        'refresh_seconds' => (int) (termSetting('terminal_refresh_seconds', '15') ?? 15),
        'marquee' => termTerminalMarqueePayload(),
        'contest' => $contest,
        'balance_cap' => termApiBalanceCapPayload($terminal),
    ]);
} catch (Throwable $e) {
    error_log('bootstrap.php: ' . $e->getMessage());
    termJson(['ok' => false, 'message' => 'Eroare server bootstrap.'], 500);
}
