<?php

require_once __DIR__ . '/../includes/terminal_api.php';
require_once __DIR__ . '/../includes/multiplayer_contest.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Terminal-Code, X-Terminal-Secret');
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    termJson(['ok' => false, 'message' => 'Metoda invalida.'], 405);
}

try {
    $terminal = termApiRequireTerminal();
    $body = termApiReadJsonBody();
    $appVersion = trim((string) ($body['app_version'] ?? ''));
    $gameOverlayOpen = filter_var($body['game_overlay_open'] ?? false, FILTER_VALIDATE_BOOLEAN);

    if (!$gameOverlayOpen) {
        termApiCloseAllOpenGameSessions((int) $terminal['id']);
    } else {
        termApiCloseIdleGameSessions((int) $terminal['id']);
    }

    termApiUpdateHeartbeat($terminal);
    termApiMarkOffline();
    termPlayVisitOnHeartbeat((int) $terminal['id'], termApiCreditsBalance($terminal));

    $contest = termMpBuildPayloadForTerminal($terminal);

    termJson([
        'ok' => true,
        'terminal_id' => (int) $terminal['id'],
        'status' => $terminal['status'] === 'maintenance' ? 'maintenance' : 'online',
        'server_time' => date('c'),
        'app_version' => $appVersion,
        'credits_balance' => termMpResolveTerminalCreditsBalance($terminal, $contest),
        'balance_cap' => termApiBalanceCapPayload($terminal),
        'contest' => $contest,
    ]);
} catch (Throwable $e) {
    error_log('heartbeat.php: ' . $e->getMessage());
    termJson(['ok' => false, 'message' => 'Eroare server heartbeat.'], 500);
}
