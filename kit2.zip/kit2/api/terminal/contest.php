<?php

require_once __DIR__ . '/../includes/terminal_api.php';
require_once __DIR__ . '/../includes/multiplayer_contest.php';
require_once __DIR__ . '/../includes/top_display_state.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Terminal-Code, X-Terminal-Secret');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    $terminal = termApiRequireTerminal();
    termApiUpdateHeartbeat($terminal);

    $contest = termMpBuildPayloadForTerminal($terminal);
    $display = termTopDisplayGet((int) ($terminal['id'] ?? 0));

    termJson([
        'ok' => true,
        'contest' => $contest,
        'display' => $display,
        'credits_balance' => termMpResolveTerminalCreditsBalance($terminal, $contest),
        'server_time' => date('c'),
    ]);
} catch (Throwable $e) {
    error_log('contest.php: ' . $e->getMessage());
    termJson(['ok' => false, 'message' => 'Eroare server concurs.'], 500);
}
