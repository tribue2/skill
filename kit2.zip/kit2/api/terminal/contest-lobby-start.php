<?php

require_once __DIR__ . '/../includes/terminal_api.php';
require_once __DIR__ . '/../includes/multiplayer_contest.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Terminal-Code, X-Terminal-Secret');
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    termJson(['ok' => false, 'message' => 'Metoda invalida.'], 405);
}

try {
    $terminal = termApiRequireTerminal();
    termApiUpdateHeartbeat($terminal);

    $contest = termMpManualStartLobby($terminal);

    termJson([
        'ok' => true,
        'started' => true,
        'contest' => $contest,
        'credits_balance' => termMpResolveTerminalCreditsBalance($terminal, $contest),
        'server_time' => date('c'),
    ]);
} catch (RuntimeException $e) {
    termJson(['ok' => false, 'message' => $e->getMessage()], 422);
} catch (Throwable $e) {
    error_log('contest-lobby-start.php: ' . $e->getMessage());
    termJson(['ok' => false, 'message' => 'Eroare la pornirea concursului.'], 500);
}
