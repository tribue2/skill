<?php

require_once __DIR__ . '/../includes/terminal_api.php';
require_once __DIR__ . '/../../administrator/includes/shop_cash.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Terminal-Code, X-Terminal-Secret');
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    termJson(['ok' => false, 'message' => 'Metoda invalida.'], 405);
}

try {
    $terminal = termApiRequireTerminal();
    $body = termApiReadJsonBody();
    $event = strtolower(trim((string) ($body['event'] ?? 'inserted')));
    if ($event !== 'inserted') {
        termJson(['ok' => true, 'ignored' => true]);
    }

    $drive = strtoupper(trim((string) ($body['drive_letter'] ?? '')));
    if ($drive !== '' && !preg_match('/^[A-Z]:$/', $drive)) {
        $drive = '';
    }

    $deviceId = trim((string) ($body['device_id'] ?? ''));
    if (function_exists('mb_substr')) {
        $deviceId = mb_substr($deviceId, 0, 160, 'UTF-8');
    } else {
        $deviceId = substr($deviceId, 0, 160);
    }

    $model = trim((string) ($body['model'] ?? $body['volume_name'] ?? ''));
    if (function_exists('mb_substr')) {
        $model = mb_substr($model, 0, 80, 'UTF-8');
    } else {
        $model = substr($model, 0, 80);
    }

    $deviceKind = strtolower(trim((string) ($body['device_kind'] ?? '')));
    if (!in_array($deviceKind, ['usb', 'keyboard', 'mouse'], true)) {
        $deviceKind = $drive !== '' ? 'usb' : 'usb';
    }

    if ($drive === '' && $deviceId === '' && $model === '') {
        termJson(['ok' => false, 'message' => 'Date USB incomplete.'], 422);
    }

    $created = iqwinAdminCreateUsbStickNotices($terminal, $drive, $model, $deviceId, $deviceKind);
    termJson([
        'ok' => true,
        'notices' => $created,
        'drive_letter' => $drive,
        'device_id' => $deviceId,
        'device_kind' => $deviceKind,
    ]);
} catch (Throwable $e) {
    error_log('usb-alert.php: ' . $e->getMessage());
    termJson(['ok' => false, 'message' => 'Eroare server USB alert.'], 500);
}
