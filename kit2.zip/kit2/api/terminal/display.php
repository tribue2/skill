<?php

require_once __DIR__ . '/../includes/terminal_api.php';
require_once __DIR__ . '/../includes/top_display_state.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Terminal-Code, X-Terminal-Secret');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    $terminal = termApiRequireTerminal();
    $terminalId = (int) ($terminal['id'] ?? 0);

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        termJson([
            'ok' => true,
            'display' => termTopDisplayGet($terminalId),
            'server_time' => date('c'),
        ]);
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        termJson(['ok' => false, 'message' => 'Metoda invalida.'], 405);
    }

    $body = termApiReadJsonBody();
    $display = termTopDisplaySave($terminalId, $body);

    termJson([
        'ok' => true,
        'display' => $display,
        'server_time' => date('c'),
    ]);
} catch (Throwable $e) {
    error_log('display.php: ' . $e->getMessage());
    termJson(['ok' => false, 'message' => 'Eroare server display.'], 500);
}
