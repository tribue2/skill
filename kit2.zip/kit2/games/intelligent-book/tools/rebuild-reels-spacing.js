const MIN_DIST = 3;

const TARGET_COUNTS = [
    { coif: 2, house: 2, bug: 2, vas: 2, symbo: 2, zeu: 1, iq_i: 1, a: 5, k: 4, q: 4, j: 1, ten: 4 },
    { bug: 2, vas: 2, symbo: 2, zeu: 1, coif: 1, house: 1, wild: 1, iq_q2: 1, a: 3, k: 4, q: 5, j: 4, ten: 3 },
    { bug: 2, vas: 2, symbo: 2, zeu: 1, coif: 1, house: 1, iq_w: 1, a: 3, k: 5, q: 4, j: 2, ten: 3 },
    { bug: 2, vas: 1, symbo: 1, zeu: 1, coif: 1, house: 1, wild: 1, iq_i: 1, a: 4, k: 5, q: 5, j: 4, ten: 3 },
    { bug: 1, vas: 1, symbo: 1, zeu: 1, coif: 1, house: 1, iq_n: 1, a: 4, k: 6, q: 5, j: 4, ten: 4 }
];

const SMALL = ['a', 'k', 'q', 'j', 'ten'];
const lengths = [30, 30, 27, 30, 30];

function cd(L, i, j) {
    const d = Math.abs(i - j);
    return Math.min(d, L - d);
}

function count(reel) {
    const c = {};
    reel.forEach((s) => { c[s] = (c[s] || 0) + 1; });
    return c;
}

function violations(reel) {
    const L = reel.length;
    const bad = [];
    const pos = {};
    reel.forEach((s, i) => { (pos[s] || (pos[s] = [])).push(i); });
    for (const [sym, idxs] of Object.entries(pos)) {
        for (let a = 0; a < idxs.length; a += 1) {
            for (let b = a + 1; b < idxs.length; b += 1) {
                if (cd(L, idxs[a], idxs[b]) < MIN_DIST) {
                    bad.push({ sym, a: idxs[a], b: idxs[b], d: cd(L, idxs[a], idxs[b]) });
                }
            }
        }
    }
    return bad;
}

function canPlace(reel, idx, sym) {
    const L = reel.length;
    for (let i = 0; i < L; i += 1) {
        if (reel[i] === sym && cd(L, idx, i) < MIN_DIST) return false;
    }
    return true;
}

function buildStrip(target, length, seed) {
    const fixed = Object.entries(target).filter(([k]) => !SMALL.includes(k));
    const reel = Array(length).fill(null);

    for (const [sym, cnt] of fixed) {
        const slots = [];
        for (let i = 0; i < length; i += 1) slots.push(i);
        slots.sort((a, b) => ((a * 17 + seed) % length) - ((b * 17 + seed) % length));

        for (let n = 0; n < cnt; n += 1) {
            let best = -1;
            let bestScore = -1;
            for (const i of slots) {
                if (reel[i] !== null) continue;
                if (!canPlace(reel, i, sym)) continue;
                let score = 999;
                for (let j = 0; j < length; j += 1) {
                    if (reel[j] === sym) score = Math.min(score, cd(length, i, j));
                }
                if (score > bestScore) {
                    bestScore = score;
                    best = i;
                }
            }
            if (best < 0) throw new Error(`cannot place ${sym}`);
            reel[best] = sym;
        }
    }

    const smallCounts = { ...target };
    fixed.forEach(([s]) => { delete smallCounts[s]; });
    Object.keys(smallCounts).forEach((k) => {
        if (!SMALL.includes(k)) delete smallCounts[k];
    });

    for (let i = 0; i < length; i += 1) {
        if (reel[i] !== null) continue;
        const order = [...SMALL].sort((a, b) => (smallCounts[b] || 0) - (smallCounts[a] || 0));
        let chosen = null;
        for (const sym of order) {
            if ((smallCounts[sym] || 0) <= 0) continue;
            if (canPlace(reel, i, sym)) {
                chosen = sym;
                break;
            }
        }
        if (!chosen) {
            for (const sym of order) {
                if ((smallCounts[sym] || 0) > 0) {
                    chosen = sym;
                    break;
                }
            }
        }
        reel[i] = chosen;
        smallCounts[chosen] -= 1;
    }

    return reel;
}

const reels = [];
for (let r = 0; r < 5; r += 1) {
    let best = null;
    for (let seed = 0; seed < 500; seed += 1) {
        try {
            const reel = buildStrip(TARGET_COUNTS[r], lengths[r], seed + r * 97);
            const c = count(reel);
            let ok = true;
            for (const [k, v] of Object.entries(TARGET_COUNTS[r])) {
                if ((c[k] || 0) !== v) ok = false;
            }
            if (!ok || violations(reel).length) continue;
            best = reel;
            break;
        } catch (e) {}
    }
    if (!best) {
        console.error('Failed reel', r + 1);
        process.exit(1);
    }
    reels.push(best);
}

reels.forEach((r, i) => {
    console.log(`// Rola ${i + 1}: violations=${violations(r).length}`);
    console.log(`['${r.join("', '")}'],`);
});
