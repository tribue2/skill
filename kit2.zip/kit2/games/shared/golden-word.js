(function (window) {
    'use strict';

    const SIZE = 6;
    const CLOSE_AFTER_WIN_MS = 4200;
    const CLOSE_AFTER_LOSE_MS = 1600;

    let activeSfx = null;
    let cells = [];
    let timerRaf = 0;

    const state = {
        open: false,
        locked: false,
        offerMode: false,
        grid: [],
        word: '',
        size: SIZE,
        token: '',
        durationMs: 5000,
        startedAt: 0,
        path: [],
        selecting: false,
        finished: false,
        closeTimer: null,
        isBlocked: () => false,
        getOffer: () => null,
        formatCredits: (value) => String(value),
        onRefundApplied: null,
        onOfferConsumed: null,
        isSoundEnabled: () => true,
    };

    function $(selector, root) {
        return (root || document).querySelector(selector);
    }

    function currentOffer() {
        const offer = state.getOffer?.();
        if (!offer || !offer.active) return null;
        return offer;
    }

    function getTerminalApiBase() {
        const server = localStorage.getItem('skill_terminal_server');
        if (!server) return null;
        return server.replace(/\/$/, '') + '/api/terminal';
    }

    function getTerminalHeaders() {
        const storage = localStorage.getItem('skill_terminal_credentials');
        if (!storage) return null;
        try {
            const credentials = JSON.parse(storage);
            return {
                'Content-Type': 'application/json',
                'X-Terminal-Code': credentials.terminal_code,
                'X-Terminal-Secret': credentials.api_secret,
            };
        } catch (error) {
            return null;
        }
    }

    function getSoundUrls(fileName) {
        const urls = [];
        const server = localStorage.getItem('skill_terminal_server');
        if (server) {
            urls.push(new URL(`sounds/${fileName}`, `${server.replace(/\/$/, '')}/`).href);
        }
        const parts = window.location.pathname.split('/').filter(Boolean);
        const gamesIdx = parts.indexOf('games');
        if (gamesIdx > 0) {
            const terminalRoot = `${window.location.origin}/${parts.slice(0, gamesIdx).join('/')}/`;
            urls.push(new URL(`sounds/${fileName}`, terminalRoot).href);
        }
        urls.push(new URL(`../../sounds/${fileName}`, window.location.href).href);
        return [...new Set(urls)];
    }

    function stopSfx() {
        if (!activeSfx) return;
        try {
            activeSfx.pause();
            activeSfx.currentTime = 0;
        } catch (error) {}
        activeSfx = null;
    }

    function playSfx(fileName) {
        if (!state.isSoundEnabled()) return;
        try {
            stopSfx();
            const urls = getSoundUrls(fileName);
            let urlIndex = 0;
            const audio = new Audio(urls[urlIndex]);
            activeSfx = audio;
            audio.volume = 0.75;
            audio.addEventListener('ended', () => {
                if (activeSfx === audio) activeSfx = null;
            });
            audio.addEventListener('error', () => {
                if (urlIndex + 1 < urls.length) {
                    urlIndex += 1;
                    audio.src = urls[urlIndex];
                    audio.load();
                    audio.play().catch(() => {});
                }
            });
            audio.play().catch(() => {});
        } catch (error) {}
    }

    function cellKey(r, c) {
        return r + ',' + c;
    }

    function parseCell(node) {
        if (!node || !node.dataset) return null;
        const r = Number(node.dataset.r);
        const c = Number(node.dataset.c);
        if (!Number.isInteger(r) || !Number.isInteger(c)) return null;
        return [r, c];
    }

    function letterAt(r, c) {
        const row = state.grid[r] || '';
        return row[c] || '';
    }

    function sameStep(path, next) {
        if (!path.length) return true;
        const last = path[path.length - 1];
        const dr = next[0] - last[0];
        const dc = next[1] - last[1];
        if (dr !== 0 || Math.abs(dc) !== 1) return false;
        if (path.length === 1) return true;
        const prev = path[path.length - 2];
        return dr === last[0] - prev[0] && dc === last[1] - prev[1];
    }

    function pathHas(path, r, c) {
        return path.some((cell) => cell[0] === r && cell[1] === c);
    }

    function selectedWord() {
        return state.path.map((cell) => letterAt(cell[0], cell[1])).join('');
    }

    function setStatus(text) {
        const node = $('#gwStatus');
        if (node) node.textContent = text || '';
    }

    function hideResult() {
        const card = $('#gwResult');
        if (!card) return;
        card.classList.add('is-hidden');
        card.classList.remove('is-win', 'is-lose');
    }

    function showResult(type, title, sub) {
        const card = $('#gwResult');
        if (!card) return;
        card.classList.remove('is-hidden', 'is-win', 'is-lose');
        card.classList.add(type === 'win' ? 'is-win' : 'is-lose');
        const titleNode = $('#gwResultTitle');
        const subNode = $('#gwResultSub');
        if (titleNode) titleNode.textContent = title;
        if (subNode) subNode.textContent = sub;
    }

    function paintPath() {
        cells.forEach((btn) => {
            const r = Number(btn.dataset.r);
            const c = Number(btn.dataset.c);
            btn.classList.toggle('is-on', pathHas(state.path, r, c));
        });
    }

    function markWinPath() {
        cells.forEach((btn) => {
            const r = Number(btn.dataset.r);
            const c = Number(btn.dataset.c);
            btn.classList.toggle('is-win', pathHas(state.path, r, c));
            btn.classList.remove('is-on');
        });
    }

    function renderGrid() {
        const board = $('#gwBoard');
        if (!board) return;
        const size = Number(state.size || SIZE);
        board.style.gridTemplateColumns = 'repeat(' + size + ', minmax(0, 1fr))';
        board.style.gridTemplateRows = 'repeat(' + size + ', minmax(0, 1fr))';
        board.innerHTML = '';
        cells = [];
        for (let r = 0; r < size; r += 1) {
            for (let c = 0; c < size; c += 1) {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'gw-cell';
                btn.dataset.r = String(r);
                btn.dataset.c = String(c);
                btn.textContent = letterAt(r, c);
                board.appendChild(btn);
                cells.push(btn);
            }
        }
    }

    function remainingMs() {
        return Math.max(0, state.durationMs - (performance.now() - state.startedAt));
    }

    function formatClock(ms) {
        const total = Math.ceil(ms / 1000);
        const s = Math.max(0, total);
        return '00:' + String(s).padStart(2, '0');
    }

    function paintTimer() {
        const left = remainingMs();
        const face = $('#gwTimerFace');
        const fg = $('#gwTimerFg');
        if (face) face.textContent = formatClock(left);
        if (fg) {
            const ratio = state.durationMs > 0 ? left / state.durationMs : 0;
            fg.style.strokeDashoffset = String(283 * (1 - ratio));
        }
    }

    function stopTimer() {
        if (timerRaf) {
            window.cancelAnimationFrame(timerRaf);
            timerRaf = 0;
        }
    }

    function tickTimer() {
        paintTimer();
        if (state.locked) return;
        if (remainingMs() <= 0) {
            void endRound(false);
            return;
        }
        timerRaf = window.requestAnimationFrame(tickTimer);
    }

    function updateOfferHint() {
        const prize = $('#gwPrize');
        const prizeValue = $('#gwPrizeValue');
        const offer = currentOffer();
        const refund = Math.floor(Number((offer && offer.betAmount) || 0) / 2);
        if (prizeValue) prizeValue.textContent = state.formatCredits(refund) + ' LEI';
        prize?.classList.remove('is-hidden');
    }

    async function fetchPuzzle() {
        const offer = currentOffer();
        const base = getTerminalApiBase();
        const headers = getTerminalHeaders();
        if (!offer || !base || !headers || !offer.sessionId) return null;
        try {
            const response = await fetch(base + '/quiz.php', {
                method: 'POST',
                headers,
                body: JSON.stringify({
                    action: 'start_word',
                    session_id: offer.sessionId,
                    game_id: offer.gameId,
                }),
            });
            const data = await response.json();
            if (!data || !data.ok || !Array.isArray(data.grid) || !data.word || !data.token) {
                return null;
            }
            return data;
        } catch (error) {
            return null;
        }
    }

    async function claimRefund(won) {
        const offer = currentOffer();
        const base = getTerminalApiBase();
        const headers = getTerminalHeaders();
        if (!won) {
            return { ok: true, correct: false, refund_credits: 0 };
        }
        if (offer && base && headers && offer.sessionId) {
            try {
                const response = await fetch(base + '/quiz.php', {
                    method: 'POST',
                    headers,
                    body: JSON.stringify({
                        action: 'claim_refund_xo',
                        session_id: offer.sessionId,
                        game_id: offer.gameId,
                        token: state.token,
                        path: state.path.map((cell) => ({ r: cell[0], c: cell[1] })),
                    }),
                });
                const data = await response.json();
                if (data && typeof data === 'object') return data;
            } catch (error) {}
        }
        return { ok: true, correct: false, refund_credits: 0 };
    }

    function clearCloseTimer() {
        if (state.closeTimer) {
            window.clearTimeout(state.closeTimer);
            state.closeTimer = null;
        }
    }

    function scheduleClose(won) {
        clearCloseTimer();
        const delay = won ? CLOSE_AFTER_WIN_MS : CLOSE_AFTER_LOSE_MS;
        state.closeTimer = window.setTimeout(() => {
            state.closeTimer = null;
            close();
        }, delay);
    }

    async function endRound(won) {
        if (state.finished) return;
        state.finished = true;
        state.locked = true;
        state.selecting = false;
        stopTimer();
        cells.forEach((cell) => { cell.disabled = true; });

        if (won) {
            playSfx('next.mp3');
            markWinPath();
            const refundData = await claimRefund(true);
            const refund = Number(refundData.refund_credits || 0);
            if (refund > 0) {
                state.onRefundApplied?.(refund, refundData.credits_balance);
            }
            showResult(
                'win',
                'Cuvant gasit',
                refund > 0
                    ? 'Recuperare: +' + state.formatCredits(refund) + ' LEI'
                    : 'Victorie inregistrata, fara recuperare pe sold'
            );
            setStatus('Excelent. Ai marcat cuvantul la timp.');
            if (state.offerMode) state.onOfferConsumed?.();
            scheduleClose(true);
            return;
        }

        playSfx('lose.mp3');
        showResult('lose', 'Timp expirat', 'Cuvantul nu a fost marcat in 5 secunde.');
        setStatus('Mai incearca la urmatoarea rotire fara castig.');
        await claimRefund(false);
        if (state.offerMode) state.onOfferConsumed?.();
        scheduleClose(false);
    }

    function tryComplete() {
        if (selectedWord() === state.word && state.path.length === state.word.length) {
            void endRound(true);
        }
    }

    function addCell(r, c) {
        if (state.locked) return;
        if (pathHas(state.path, r, c)) return;
        const next = [r, c];
        if (!sameStep(state.path, next)) {
            if (state.path.length) {
                state.path = [[r, c]];
            } else {
                state.path.push(next);
            }
        } else {
            state.path.push(next);
        }
        paintPath();
        setStatus(selectedWord() || 'Trage degetul peste litere');
        tryComplete();
    }

    function onPointerDown(event) {
        if (state.locked) return;
        const cell = event.target.closest('.gw-cell');
        const pos = parseCell(cell);
        if (!pos) return;
        event.preventDefault();
        state.selecting = true;
        state.path = [];
        addCell(pos[0], pos[1]);
        cell.setPointerCapture?.(event.pointerId);
    }

    function onPointerMove(event) {
        if (!state.selecting || state.locked) return;
        const node = document.elementFromPoint(event.clientX, event.clientY);
        const cell = node && node.closest ? node.closest('.gw-cell') : null;
        const pos = parseCell(cell);
        if (!pos) return;
        addCell(pos[0], pos[1]);
    }

    function onPointerUp() {
        if (!state.selecting) return;
        state.selecting = false;
        if (!state.locked) tryComplete();
    }

    async function beginRound() {
        state.locked = true;
        state.finished = false;
        state.path = [];
        state.grid = [];
        state.size = SIZE;
        state.word = '';
        hideResult();
        setStatus('Se pregateste grila...');
        const puzzle = await fetchPuzzle();
        if (!puzzle) {
            setStatus('Nu s-a putut deschide mini-jocul.');
            showResult('lose', 'Eroare', 'Incearca din nou din butonul Golden Word.');
            state.locked = true;
            return;
        }
        state.grid = puzzle.grid;
        state.size = Number(puzzle.size || SIZE);
        state.word = String(puzzle.word || '').toUpperCase();
        state.token = puzzle.token;
        state.durationMs = Number(puzzle.duration_ms || 5000);
        const wordNode = $('#gwWord');
        if (wordNode) wordNode.textContent = state.word;
        renderGrid();
        state.locked = false;
        state.startedAt = performance.now();
        paintTimer();
        setStatus('Gaseste cuvantul pe grila');
        stopTimer();
        timerRaf = window.requestAnimationFrame(tickTimer);
    }

    function setOpen(open) {
        const popup = $('#gwPopup');
        if (!popup) return;
        if (!open) {
            clearCloseTimer();
            stopTimer();
            stopSfx();
            state.selecting = false;
            if (state.open && state.offerMode && state.token && !state.finished) {
                state.finished = true;
                state.onOfferConsumed?.();
            }
        }
        state.open = open;
        state.offerMode = Boolean(open && currentOffer());
        popup.classList.toggle('is-hidden', !open);
        popup.setAttribute('aria-hidden', open ? 'false' : 'true');
        const halfBtn = $('#halfButton');
        if (halfBtn) halfBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (open) {
            updateOfferHint();
            void beginRound();
        }
    }

    function close() {
        setOpen(false);
    }

    function open() {
        if (state.isBlocked()) return;
        if (!currentOffer()) return;
        setOpen(true);
    }

    function ensureStyles() {
        if ($('#gwWordStyles')) return;
        const link = document.createElement('link');
        link.id = 'gwWordStyles';
        link.rel = 'stylesheet';
        const script = document.querySelector('script[src*="golden-word.js"]');
        const src = script && script.src ? script.src : '../shared/golden-word.js';
        link.href = src.replace(/golden-word\.js[^/]*$/i, 'golden-word.css?v=7');
        document.head.appendChild(link);
    }

    function ensureMarkup() {
        const popup = $('#gwPopup');
        if (!popup) return;
        if ($('#gwBoard')) return;
        const panel = popup.querySelector('.gw-panel') || popup;
        panel.innerHTML = '<div class="gw-shell">'
            + '<section class="gw-col gw-left">'
            + '<div class="gw-brand"><span class="gw-brain" aria-hidden="true">W</span>'
            + '<div class="gw-title" id="gwTitle"><small>Golden</small><strong>Word</strong></div></div>'
            + '<div class="gw-intro"><p class="gw-lead">Gaseste cuvantul</p>'
            + '<p class="gw-copy">Ai 5 secunde sa identifici in careul literele cuvantului afisat.</p></div>'
            + '<div class="gw-tips">'
            + '<div class="gw-tip"><i>→</i><span>Cuvantul e pe un rand, stanga → dreapta.</span></div>'
            + '<div class="gw-tip"><i>○</i><span>Trage degetul peste litere, in ordine.</span></div>'
            + '<div class="gw-tip"><i>⚡</i><span>Fii rapid. Ai doar 5 secunde.</span></div>'
            + '<div class="gw-tip"><i>★</i><span>Daca reusesti, recuperezi 50% din pariu.</span></div>'
            + '</div></section>'
            + '<section class="gw-col gw-center"><div class="gw-word-card">'
            + '<p class="gw-word-label">Cuvantul de gasit este:</p>'
            + '<p class="gw-word" id="gwWord">------</p>'
            + '<div class="gw-board" id="gwBoard" role="grid" aria-label="Grila Golden Word"></div>'
            + '<p class="gw-status" id="gwStatus">Pregateste-te</p>'
            + '<div class="gw-result is-hidden" id="gwResult"><strong id="gwResultTitle"></strong><span id="gwResultSub"></span></div>'
            + '</div></section>'
            + '<section class="gw-col gw-right">'
            + '<button type="button" class="gw-close" id="gwClose" aria-label="Inchide">&times;</button>'
            + '<div class="gw-timer-wrap"><div class="gw-timer-label">Timp ramas</div>'
            + '<div class="gw-timer"><svg viewBox="0 0 100 100" aria-hidden="true">'
            + '<defs><linearGradient id="gwTimerGrad" x1="0%" y1="0%" x2="100%" y2="100%">'
            + '<stop offset="0%" stop-color="#86efac"/><stop offset="100%" stop-color="#22c55e"/>'
            + '</linearGradient></defs>'
            + '<circle class="gw-timer-bg" cx="50" cy="50" r="45"></circle>'
            + '<circle class="gw-timer-fg" id="gwTimerFg" cx="50" cy="50" r="45"></circle>'
            + '</svg><div class="gw-timer-face" id="gwTimerFace">00:05</div></div></div>'
            + '<div class="gw-prize" id="gwPrize"><span class="gw-prize-icon" aria-hidden="true">↺</span>'
            + '<div class="gw-prize-text"><small>Recuperare 50% din pariu</small>'
            + '<strong id="gwPrizeValue">— LEI</strong></div></div>'
            + '<p class="gw-side-copy">Cuvinte · Idei · Victorie</p>'
            + '</section></div>';
    }

    function init(options) {
        if (options && typeof options.isBlocked === 'function') state.isBlocked = options.isBlocked;
        if (options && typeof options.getOffer === 'function') state.getOffer = options.getOffer;
        if (options && typeof options.formatCredits === 'function') state.formatCredits = options.formatCredits;
        if (options && typeof options.onRefundApplied === 'function') state.onRefundApplied = options.onRefundApplied;
        if (options && typeof options.onOfferConsumed === 'function') state.onOfferConsumed = options.onOfferConsumed;
        if (options && typeof options.isSoundEnabled === 'function') state.isSoundEnabled = options.isSoundEnabled;
        if (!$('#gwPopup')) return;
        ensureStyles();
        ensureMarkup();

        const board = $('#gwBoard');
        board?.addEventListener('pointerdown', onPointerDown);
        window.addEventListener('pointermove', onPointerMove);
        window.addEventListener('pointerup', onPointerUp);
        window.addEventListener('pointercancel', onPointerUp);

        $('#gwClose')?.addEventListener('click', close);
        $('#gwPopup')?.addEventListener('click', (event) => {
            if (event.target === $('#gwPopup')?.querySelector('.gw-backdrop')) close();
        });
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && state.open) close();
        });
    }

    window.GoldenWord = {
        init,
        open,
        close,
    };
}(window));
