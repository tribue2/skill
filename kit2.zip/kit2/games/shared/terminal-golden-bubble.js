(function (global) {
    'use strict';
    global.IqwinTerminalGoldenBubble = null;
})(window);
