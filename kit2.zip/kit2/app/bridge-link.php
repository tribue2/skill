<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>IQWIN Terminal</title>
    <link rel="stylesheet" href="css/terminal.css?v=<?php echo (int)@filemtime(__DIR__ . '/css/terminal.css'); ?>">
    <style>
        .bridge-link-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            background:
                radial-gradient(ellipse at 20% 10%, rgba(126, 184, 212, 0.18), transparent 45%),
                radial-gradient(ellipse at 80% 90%, rgba(201, 162, 39, 0.12), transparent 40%),
                #12151a;
        }
        .bridge-link-card {
            width: min(480px, 100%);
            padding: 28px 26px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(20, 24, 30, 0.92);
            color: #e8eef4;
            font-family: Georgia, "Times New Roman", serif;
        }
        .bridge-link-card h1 {
            margin: 0 0 10px;
            font-size: 1.55rem;
            color: #f0d78c;
            font-weight: 700;
        }
        .bridge-link-card p {
            margin: 0 0 14px;
            line-height: 1.45;
            color: #b7c2cc;
            font-size: 0.98rem;
        }
        .bridge-link-status {
            min-height: 1.4em;
            margin: 0 0 16px;
            font-weight: 700;
        }
        .bridge-link-status.ok { color: #7dcea0; }
        .bridge-link-status.err { color: #f0a0a0; }
        .bridge-link-status.wait { color: #c9a227; }
        .bridge-link-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .bridge-link-btn {
            border: 1px solid rgba(240, 215, 140, 0.45);
            background: #c9a227;
            color: #1a1408;
            font-weight: 700;
            padding: 10px 16px;
            cursor: pointer;
            font-family: inherit;
            text-decoration: none;
            display: inline-block;
        }
        .bridge-link-btn.secondary {
            background: transparent;
            color: #e8eef4;
            border-color: rgba(255, 255, 255, 0.25);
        }
    </style>
</head>
<body>
<div class="bridge-link-page">
    <div class="bridge-link-card">
        <h1>IQWIN Terminal</h1>
        <p>Pornire automata — nu trebuie sa faci nimic in browser.</p>
        <p class="bridge-link-status wait" id="bridgeStatus">Pornesc...</p>
        <div class="bridge-link-actions" id="bridgeActions" hidden>
            <button type="button" class="bridge-link-btn" id="bridgeRetryBtn">Incearca din nou</button>
            <a class="bridge-link-btn secondary" href="index.php">Deschide terminalul</a>
        </div>
    </div>
</div>
<script>
(function () {
    const statusEl = document.getElementById('bridgeStatus');
    const retryBtn = document.getElementById('bridgeRetryBtn');
    const actionsEl = document.getElementById('bridgeActions');
    const ports = [17891, 17892, 17893];

    function setStatus(text, cls) {
        statusEl.textContent = text;
        statusEl.className = 'bridge-link-status ' + cls;
    }

    function showActions() {
        if (actionsEl) actionsEl.hidden = false;
    }

    function resolveNext() {
        try {
            const params = new URLSearchParams(window.location.search || '');
            const next = String(params.get('next') || '').toLowerCase();
            if (next === 'top' || next === 'top-display' || next === 'info') {
                return { url: 'top-display.php', externalTop: false };
            }
            if (next === 'games' || next === 'dual' || next === 'terminal') {
                return { url: 'index.php', externalTop: true };
            }
        } catch (e) {}
        return { url: 'index.php', externalTop: true };
    }

    function applyCredentials(data) {
        if (!data || !data.terminal_code || !data.api_secret) {
            return false;
        }
        const server = String(data.server_url || window.location.origin).replace(/\/$/, '');
        localStorage.setItem('skill_terminal_server', server);
        localStorage.setItem('skill_terminal_credentials', JSON.stringify({
            id: 0,
            name: data.terminal_name || data.terminal_code,
            terminal_code: data.terminal_code,
            api_secret: data.api_secret
        }));
        const target = resolveNext();
        try {
            if (target.externalTop) {
                sessionStorage.setItem('iqwin_ext_top', '1');
            } else {
                sessionStorage.removeItem('iqwin_ext_top');
            }
        } catch (e) {}
        try {
            history.replaceState(null, '', window.location.pathname);
        } catch (e) {}
        setStatus('OK — deschid...', 'ok');
        setTimeout(function () {
            window.location.replace(target.url);
        }, 400);
        return true;
    }

    function applyFromHash() {
        const raw = String(window.location.hash || '');
        const m = raw.match(/[#&]iqwin=([^&]+)/);
        if (!m) return false;
        try {
            const json = decodeURIComponent(escape(atob(decodeURIComponent(m[1]))));
            const data = JSON.parse(json);
            return applyCredentials(data);
        } catch (e) {
            return false;
        }
    }

    window.addEventListener('message', function (event) {
        if (!event || !event.data || event.data.type !== 'iqwin-itl-credentials') return;
        applyCredentials(event.data.data);
    });

    async function tryFetch(port) {
        const controller = new AbortController();
        const timer = setTimeout(function () { controller.abort(); }, 1200);
        try {
            const response = await fetch('http://127.0.0.1:' + port + '/credentials', {
                method: 'GET',
                signal: controller.signal
            });
            clearTimeout(timer);
            if (!response.ok) return null;
            return await response.json();
        } catch (error) {
            clearTimeout(timer);
            return null;
        }
    }

    function tryPopup(port) {
        return new Promise(function (resolve) {
            const popup = window.open('http://127.0.0.1:' + port + '/link', 'iqwin_itl_link', 'width=420,height=240');
            if (!popup) {
                resolve(false);
                return;
            }
            const timer = setTimeout(function () {
                try { popup.close(); } catch (e) {}
                resolve(false);
            }, 2500);
            function onMsg(event) {
                if (!event || !event.data || event.data.type !== 'iqwin-itl-credentials') return;
                clearTimeout(timer);
                window.removeEventListener('message', onMsg);
                try { popup.close(); } catch (e) {}
                resolve(applyCredentials(event.data.data));
            }
            window.addEventListener('message', onMsg);
        });
    }

    async function syncFromBridge() {
        setStatus('Pornesc...', 'wait');
        if (applyFromHash()) return;

        for (let i = 0; i < ports.length; i += 1) {
            const data = await tryFetch(ports[i]);
            if (applyCredentials(data)) return;
        }

        for (let i = 0; i < ports.length; i += 1) {
            const ok = await tryPopup(ports[i]);
            if (ok) return;
        }

        showActions();
        setStatus('Kit-ul nu ruleaza. Pe PC: start-kit.bat', 'err');
    }

    if (retryBtn) retryBtn.addEventListener('click', syncFromBridge);
    syncFromBridge();
})();
</script>
</body>
</html>
