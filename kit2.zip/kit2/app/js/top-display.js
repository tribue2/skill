(() => {
    const CHANNEL = 'iqwin-terminal-top-display';
    const STORAGE_KEY = 'iqwin-top-display-state';
    const CREDENTIALS_KEY = 'skill_terminal_credentials';
    const SERVER_KEY = 'skill_terminal_server';
    const PAYTABLE_DWELL_MS = 30000;
    const DETAILS_DWELL_MS = 5000;
    const POLL_MS = 1000;
    const IDLE_LOGO_MS = 10000;
    const IDLE_SLIDE_FILE = 'slidevideo.mp4';
    const LOCAL_BRIDGE_PORTS = [17891, 17892, 17893];

    const state = {
        phase: 'lobby',
        slug: '',
        title: '',
        html: '',
        contestEnabled: false,
        contest: null,
        showingContestResult: false
    };

    const CONTEST_RESULT_DISPLAY_MS = 10000;

    const idlePanel = document.getElementById('topIdle');
    const idleSlideVideoPanel = document.getElementById('topIdleVideo');
    const idleSlideVideoEl = document.getElementById('topIdleVideoPlayer');
    const infoPanel = document.getElementById('topDisplayInfo');
    const titleNode = document.getElementById('topDisplayGameTitle');
    const track = document.getElementById('topDisplayTrack');
    const pager = document.getElementById('topDisplayPager');
    const contestPanel = document.getElementById('mpContest');
    const mpBadge = document.getElementById('mpBadge');
    const mpPrizeValue = document.getElementById('mpPrizeValue');
    const mpPrizeBox = document.getElementById('mpPrizeBox');
    const mpProgressTrack = document.querySelector('.mp-contest__progress-track');
    const mpBoard = document.getElementById('mpBoard');
    const mpSidePct = document.getElementById('mpSidePct');
    const mpRules = document.getElementById('mpRules');
    const mpBlitzValue = document.getElementById('mpBlitzValue');
    const mpProgressLabel = document.getElementById('mpProgressLabel');
    const mpProgressFill = document.getElementById('mpProgressFill');
    const mpRemaining = document.getElementById('mpRemaining');
    const mpWinBanner = document.getElementById('mpWinBanner');
    const mpWinText = document.getElementById('mpWinText');
    const mpWinTerminal = document.getElementById('mpWinTerminal');
    const mpWinPrize = document.getElementById('mpWinPrize');

    let pageIndex = 0;
    let rotateTimer = null;
    let pollTimer = null;
    let lastContestSignature = '';
    let contestResultRestoreTimer = null;
    let dismissedContestResultId = 0;
    let lastDisplaySignature = '';
    let lastWinContestId = 0;
    let lastTerminalState = { phase: 'lobby', slug: '', ts: 0 };
    let paytableLoaderFrame = null;
    let paytableLoaderSlug = '';
    let paytableLoaderTimer = null;
    let idleSlideVideoUrl = '';
    let idleSlideLogoTimer = null;
    const MP_WIN_SEEN_KEY = 'iqwin_mp_win_seen';
    const PAYTABLE_SLUGS = {
        'verga-gold': true,
        'boss-crown': true,
        'dodge-bomb': true,
        'logic-and-zeus': true,
        '40-burn-hot': true,
        'intelligent-book': true
    };

    function isGamePhaseActive() {
        return state.phase === 'game' || !!String(state.slug || '').trim();
    }

    function noteTerminalState(message) {
        if (!message || message.type !== 'state') {
            return;
        }
        const phase = String(message.phase || 'lobby').toLowerCase() === 'game' ? 'game' : 'lobby';
        lastTerminalState = {
            phase: phase,
            slug: String(message.slug || '').toLowerCase(),
            ts: Date.now()
        };
    }

    function showGameLoading() {
        if (!forceShowGameShell(state.title || '')) {
            return;
        }
        stopCarousel();
        pageIndex = 0;
        if (track) {
            track.innerHTML = '<div class="top-display-info__loading">Se incarca informatiile jocului...</div>';
            track.style.transform = 'translateX(0)';
        }
        if (pager) {
            pager.textContent = 'Se incarca...';
        }
        setLoading(true);
    }

    function paintGameInfo(html) {
        const body = absolutizePaytableHtml(html || state.html || '', state.slug);
        if (!body) {
            return false;
        }
        state.html = body;
        if (!forceShowGameShell(state.title || '')) {
            return false;
        }
        stopCarousel();
        paintPaytableHtml(body);
        setLoading(false);
        startCarousel({ resetPage: true });
        scheduleFitInfoPages();
        stopPaytableLoader();
        return true;
    }

    function trackHasLoadingPlaceholder() {
        const current = String(track && track.innerHTML || '').trim();
        return !!current && current.indexOf('top-display-info__loading') !== -1;
    }

    function trackHasPaytablePages() {
        const current = String(track && track.innerHTML || '').trim();
        return !!current
            && !trackHasLoadingPlaceholder()
            && current.indexOf('terminal-info-pages__page') !== -1;
    }

    function loadSeenMpWinIds() {
        try {
            const raw = sessionStorage.getItem(MP_WIN_SEEN_KEY);
            if (!raw) return [];
            const parsed = JSON.parse(raw);
            return Array.isArray(parsed) ? parsed.map(function (id) { return Number(id) || 0; }).filter(Boolean) : [];
        } catch (e) {
            return [];
        }
    }

    function markMpWinSeen(contestId) {
        const id = Number(contestId) || 0;
        if (!id) return;
        const ids = loadSeenMpWinIds();
        if (ids.indexOf(id) === -1) {
            ids.push(id);
        }
        try {
            sessionStorage.setItem(MP_WIN_SEEN_KEY, JSON.stringify(ids.slice(-30)));
        } catch (e) {}
    }

    function hasSeenMpWin(contestId) {
        const id = Number(contestId) || 0;
        if (!id) return false;
        return loadSeenMpWinIds().indexOf(id) !== -1;
    }
    let mpWinCountTimer = null;
    let blitzAnimFrame = null;
    let blitzShownValue = 0;
    let blitzTargetValue = 0;
    let countdownTimer = null;
    let countdownState = { mode: '', seconds: 0, totalSeconds: 300, syncedAt: 0 };
    let lastForfeitContestId = 0;

    function pages() {
        if (!track) return [];
        return Array.from(track.querySelectorAll('.terminal-info-pages__page'));
    }

    function pageCount() {
        return Math.max(1, pages().length);
    }

    function updatePager() {
        const total = pageCount();
        if (pageIndex >= total) {
            pageIndex = 0;
        }
        if (pager) {
            if (total <= 1) {
                pager.textContent = 'Tabel plati';
            } else if (pageIndex === 0) {
                pager.textContent = 'Tabel plati';
            } else {
                pager.textContent = 'Reguli & info';
            }
        }
        if (track) {
            track.style.transform = `translateX(-${pageIndex * 100}%)`;
        }
    }

    function collapseInfoPagesForTopDisplay(html) {
        const shared = window.IqwinTerminalInfoPagesContent;
        if (shared && typeof shared.collapseToTwoPages === 'function') {
            return shared.collapseToTwoPages(html);
        }
        return String(html || '');
    }

    function dwellForPage(index) {
        return index === 0 ? PAYTABLE_DWELL_MS : DETAILS_DWELL_MS;
    }

    function scheduleNextRotate() {
        stopCarousel();
        if (pageCount() <= 1) {
            return;
        }
        rotateTimer = window.setTimeout(() => {
            goNextPage();
            scheduleNextRotate();
        }, dwellForPage(pageIndex));
    }

    function fitInfoPages() {
        if (!track || isContestBlockingInfo()) return;
        if (!infoPanel || infoPanel.classList.contains('is-hidden')) return;

        const viewport = track.parentElement;
        if (!viewport) return;

        const avail = viewport.clientHeight;
        if (avail <= 0) return;

        const list = pages();
        list.forEach((page, index) => {
            page.style.setProperty('--fit-scale', '1');
            page.classList.remove('is-scaled');

            if (index !== pageIndex) {
                return;
            }

            // Pagina digest e deja compactă pe grid — nu o micșorăm agresiv.
            if (page.classList.contains('terminal-info-pages__page--digest')) {
                return;
            }

            const needed = page.scrollHeight;
            if (needed <= avail + 2) {
                return;
            }

            const scale = Math.max(0.52, Math.min(1, avail / needed));
            page.style.setProperty('--fit-scale', String(scale));
            page.classList.add('is-scaled');
        });
    }

    function scheduleFitInfoPages() {
        window.requestAnimationFrame(() => {
            fitInfoPages();
            window.setTimeout(fitInfoPages, 80);
            window.setTimeout(fitInfoPages, 320);
            window.setTimeout(fitInfoPages, 900);
        });
    }

    function goToPage(index) {
        pageIndex = Math.max(0, Math.min(pageCount() - 1, index));
        updatePager();
        scheduleFitInfoPages();
    }

    function goNextPage() {
        const total = pageCount();
        goToPage(total <= 1 ? 0 : (pageIndex + 1) % total);
    }

    function stopCarousel() {
        if (rotateTimer) {
            window.clearTimeout(rotateTimer);
            rotateTimer = null;
        }
    }

    function startCarousel(options) {
        const resetPage = !options || options.resetPage !== false;
        stopCarousel();
        if (resetPage) {
            pageIndex = 0;
        }
        updatePager();
        scheduleNextRotate();
    }

    function ensureCarousel() {
        if (pageCount() <= 1) {
            updatePager();
            return;
        }
        if (rotateTimer) {
            return;
        }
        scheduleNextRotate();
        updatePager();
    }

    function setLoading(isLoading) {
        if (!infoPanel) return;
        infoPanel.classList.toggle('is-ready', !isLoading);
    }

    function formatLei(value) {
        const num = Number(value) || 0;
        return num.toLocaleString('ro-RO', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function stopBlitzCountUp() {
        if (blitzAnimFrame) {
            cancelAnimationFrame(blitzAnimFrame);
            blitzAnimFrame = null;
        }
    }

    function setBlitzDisplay(value) {
        if (!mpBlitzValue) return;
        const num = Math.max(0, Number(value) || 0);
        blitzShownValue = num;
        mpBlitzValue.textContent = formatLei(num);
    }

    function animateBlitzTo(target) {
        if (!mpBlitzValue) return;
        const next = Math.max(0, Number(target) || 0);
        blitzTargetValue = next;

        if (Math.abs(next - blitzShownValue) < 0.005) {
            stopBlitzCountUp();
            setBlitzDisplay(next);
            mpBlitzValue.classList.remove('is-ticking');
            return;
        }

        stopBlitzCountUp();
        const from = blitzShownValue;
        const delta = Math.abs(next - from);
        const duration = Math.min(2200, Math.max(700, 450 + delta * 28));
        const start = performance.now();
        mpBlitzValue.classList.add('is-ticking');

        function easeOutExpo(t) {
            return t >= 1 ? 1 : 1 - Math.pow(2, -10 * t);
        }

        function tick(now) {
            if (blitzTargetValue !== next) return;
            const progress = Math.min(1, (now - start) / duration);
            const current = from + (next - from) * easeOutExpo(progress);
            blitzShownValue = current;
            mpBlitzValue.textContent = formatLei(current);
            if (progress < 1) {
                blitzAnimFrame = requestAnimationFrame(tick);
                return;
            }
            setBlitzDisplay(next);
            mpBlitzValue.classList.remove('is-ticking');
            blitzAnimFrame = null;
        }

        blitzAnimFrame = requestAnimationFrame(tick);
    }

    function medalClass(rank) {
        if (rank === 1) return 'is-gold';
        if (rank === 2) return 'is-silver';
        if (rank === 3) return 'is-bronze';
        return '';
    }

    const idleFloatWords = [
        'Distractiv',
        'IQ',
        'Skill',
        'Jocuri',
        'Blitz',
        'Abilitate',
        'Concurs',
        'Strategie',
        'IQWIN'
    ];
    // Zone in banda de sus (unde era logo).
    const idleFloatZones = [
        { x: 18, y: 38 },
        { x: 50, y: 32 },
        { x: 82, y: 40 },
        { x: 28, y: 58 },
        { x: 62, y: 52 },
        { x: 78, y: 62 },
        { x: 38, y: 44 },
        { x: 70, y: 36 }
    ];
    const idleFloatLayer = document.getElementById('topIdleFloatLayer');
    const idleSparklesLayer = document.getElementById('topIdleSparkles');
    const IDLE_STAR_COUNT = 36;
    let idleFloatTimer = null;
    let idleFloatIndex = 0;
    let idleFloatZoneIndex = 0;
    let idleFloatActive = null;
    let idleFloatRunning = false;
    let idleStars = [];
    let idleStarsTimer = null;
    let idleStarsRunning = false;

    function placeIdleStar(star) {
        const x = 4 + Math.random() * 92;
        const y = 4 + Math.random() * 92;
        const size = 1.2 + Math.random() * 2.8;
        const dur = 2.8 + Math.random() * 4.2;
        const delay = Math.random() * -dur;
        star.style.left = x + '%';
        star.style.top = y + '%';
        star.style.width = size + 'px';
        star.style.height = size + 'px';
        star.style.setProperty('--star-dur', dur.toFixed(2) + 's');
        star.style.setProperty('--star-delay', delay.toFixed(2) + 's');
    }

    function reshuffleIdleStars() {
        if (!idleStarsRunning || !idleStars.length) {
            return;
        }
        const count = 8 + Math.floor(Math.random() * 10);
        for (let i = 0; i < count; i += 1) {
            const star = idleStars[Math.floor(Math.random() * idleStars.length)];
            if (!star) continue;
            star.classList.remove('is-twinkle');
            placeIdleStar(star);
            window.requestAnimationFrame(() => {
                if (idleStarsRunning) {
                    star.classList.add('is-twinkle');
                }
            });
        }
        idleStarsTimer = window.setTimeout(reshuffleIdleStars, 2200 + Math.random() * 1800);
    }

    function stopIdleStars() {
        if (idleStarsTimer) {
            window.clearTimeout(idleStarsTimer);
            idleStarsTimer = null;
        }
        idleStarsRunning = false;
        idleStars = [];
        if (idleSparklesLayer) {
            idleSparklesLayer.innerHTML = '';
        }
    }

    function startIdleStars() {
        if (idleStarsRunning || !idleSparklesLayer) {
            return;
        }
        idleStarsRunning = true;
        idleSparklesLayer.innerHTML = '';
        idleStars = [];
        for (let i = 0; i < IDLE_STAR_COUNT; i += 1) {
            const star = document.createElement('span');
            star.className = 'top-idle__star is-twinkle';
            placeIdleStar(star);
            idleSparklesLayer.appendChild(star);
            idleStars.push(star);
        }
        idleStarsTimer = window.setTimeout(reshuffleIdleStars, 1800 + Math.random() * 1200);
    }

    function stopIdleFloatWords() {
        if (idleFloatTimer) {
            window.clearTimeout(idleFloatTimer);
            idleFloatTimer = null;
        }
        if (idleFloatLayer) {
            idleFloatLayer.innerHTML = '';
        }
        idleFloatActive = null;
        idleFloatRunning = false;
    }

    function spawnIdleFloatWord() {
        if (!idleFloatRunning || !idleFloatLayer || !document.body.classList.contains('has-top-idle')) {
            return;
        }

        if (idleFloatActive && idleFloatActive.parentNode) {
            idleFloatActive.classList.remove('is-in');
            idleFloatActive.classList.add('is-out');
            const old = idleFloatActive;
            window.setTimeout(() => {
                if (old && old.parentNode) {
                    old.parentNode.removeChild(old);
                }
            }, 1800);
        }

        const word = idleFloatWords[idleFloatIndex % idleFloatWords.length];
        idleFloatIndex += 1;

        const zone = idleFloatZones[idleFloatZoneIndex % idleFloatZones.length];
        idleFloatZoneIndex += 1;
        const x = Math.max(12, Math.min(88, zone.x + (Math.random() * 10 - 5)));
        const y = Math.max(28, Math.min(72, zone.y + (Math.random() * 8 - 4)));
        const sizes = ['is-sm', 'is-md', 'is-lg'];
        const sizeClass = sizes[Math.floor(Math.random() * sizes.length)];

        const node = document.createElement('span');
        node.className = 'top-idle__float-word ' + sizeClass;
        node.textContent = word;
        node.style.left = x + '%';
        node.style.top = y + '%';
        idleFloatLayer.appendChild(node);
        idleFloatActive = node;

        window.requestAnimationFrame(() => {
            node.classList.add('is-in');
        });

        idleFloatTimer = window.setTimeout(spawnIdleFloatWord, 6800);
    }

    function startIdleFloatWords() {
        if (idleFloatRunning) {
            return;
        }
        idleFloatRunning = true;
        idleFloatZoneIndex = Math.floor(Math.random() * idleFloatZones.length);
        spawnIdleFloatWord();
    }

    function isIdleSlideVideoShowing() {
        return !!(idleSlideVideoPanel && !idleSlideVideoPanel.classList.contains('is-hidden'));
    }

    function isLobbyIdleDisplayed() {
        if (state.phase !== 'lobby' || isContestBlockingInfo()) {
            return false;
        }
        if (isIdleSlideVideoShowing()) {
            return true;
        }
        if (idleSlideLogoTimer) {
            return true;
        }
        return document.body.classList.contains('has-top-idle')
            && idlePanel
            && !idlePanel.classList.contains('is-hidden')
            && (!infoPanel || infoPanel.classList.contains('is-hidden'))
            && (!contestPanel || contestPanel.classList.contains('is-hidden'));
    }

    function showIdle() {
        if (isIdleSlideVideoShowing()) {
            document.body.classList.add('has-top-idle');
            document.body.classList.add('has-top-idle-video');
            document.body.classList.remove('has-mp-contest');
            if (infoPanel) infoPanel.classList.add('is-hidden');
            if (contestPanel) contestPanel.classList.add('is-hidden');
            stopCarousel();
            return;
        }

        const alreadyIdle = document.body.classList.contains('has-top-idle')
            && idlePanel
            && !idlePanel.classList.contains('is-hidden');
        document.body.classList.add('has-top-idle');
        document.body.classList.remove('has-top-idle-video', 'has-mp-contest');
        if (idlePanel) idlePanel.classList.remove('is-hidden');
        if (infoPanel) infoPanel.classList.add('is-hidden');
        if (contestPanel) contestPanel.classList.add('is-hidden');
        stopCarousel();
        if (!alreadyIdle || !idleFloatRunning) {
            startIdleFloatWords();
        }
        if (!alreadyIdle || !idleStarsRunning) {
            startIdleStars();
        }
        if (idleSlideVideoUrl && canRunIdleSlideLoop() && !idleSlideLogoTimer) {
            scheduleIdleSlideLogoWait();
        }
    }

    function hideIdle() {
        stopIdleSlideLoop();
        document.body.classList.remove('has-top-idle');
        if (idlePanel) idlePanel.classList.add('is-hidden');
        stopIdleFloatWords();
        stopIdleStars();
    }

    function canRunIdleSlideLoop() {
        return state.phase === 'lobby'
            && !isContestBlockingInfo()
            && !!idleSlideVideoUrl;
    }

    function clearIdleSlideLogoWait() {
        if (idleSlideLogoTimer) {
            window.clearTimeout(idleSlideLogoTimer);
            idleSlideLogoTimer = null;
        }
    }

    function hideIdleSlideVideo() {
        document.body.classList.remove('has-top-idle-video');
        if (idleSlideVideoPanel) idleSlideVideoPanel.classList.add('is-hidden');
        if (!idleSlideVideoEl) return;
        idleSlideVideoEl.pause();
        try {
            idleSlideVideoEl.currentTime = 0;
        } catch (error) {
        }
    }

    function showIdleSlideVideo() {
        if (!idleSlideVideoPanel || !idleSlideVideoEl || !idleSlideVideoUrl) return;
        if (idlePanel) idlePanel.classList.add('is-hidden');
        stopIdleFloatWords();
        stopIdleStars();
        document.body.classList.add('has-top-idle');
        document.body.classList.add('has-top-idle-video');
        idleSlideVideoPanel.classList.remove('is-hidden');
        if (idleSlideVideoEl.getAttribute('data-src') !== idleSlideVideoUrl) {
            idleSlideVideoEl.src = idleSlideVideoUrl;
            idleSlideVideoEl.setAttribute('data-src', idleSlideVideoUrl);
        }
        idleSlideVideoEl.currentTime = 0;
        const playAttempt = idleSlideVideoEl.play();
        if (playAttempt && typeof playAttempt.catch === 'function') {
            playAttempt.catch(function () {
                idleSlideVideoEl.muted = true;
                idleSlideVideoEl.play().catch(function () {});
            });
        }
    }

    function scheduleIdleSlideLogoWait() {
        clearIdleSlideLogoWait();
        if (!canRunIdleSlideLoop()) return;
        idleSlideLogoTimer = window.setTimeout(function () {
            idleSlideLogoTimer = null;
            if (!canRunIdleSlideLoop()) return;
            showIdleSlideVideo();
        }, IDLE_LOGO_MS);
    }

    function stopIdleSlideLoop() {
        clearIdleSlideLogoWait();
        hideIdleSlideVideo();
    }

    function onIdleSlideVideoEnded() {
        if (!canRunIdleSlideLoop()) return;
        hideIdleSlideVideo();
        if (idlePanel) idlePanel.classList.remove('is-hidden');
        if (!idleFloatRunning) startIdleFloatWords();
        if (!idleStarsRunning) startIdleStars();
        scheduleIdleSlideLogoWait();
    }

    async function headOk(url) {
        try {
            const controller = new AbortController();
            const timer = window.setTimeout(function () {
                controller.abort();
            }, 2500);
            const response = await fetch(url, {
                method: 'HEAD',
                cache: 'no-store',
                signal: controller.signal
            });
            window.clearTimeout(timer);
            return response.ok;
        } catch (error) {
            return false;
        }
    }

    async function probeIdleSlideVideoUrl() {
        for (let i = 0; i < LOCAL_BRIDGE_PORTS.length; i += 1) {
            const port = LOCAL_BRIDGE_PORTS[i];
            const localUrl = 'http://127.0.0.1:' + port + '/media/slidevideo.mp4';
            if (await headOk(localUrl)) {
                idleSlideVideoUrl = localUrl;
                return localUrl;
            }
        }
        const serverUrl = window.location.origin + '/top-screen/' + IDLE_SLIDE_FILE;
        if (await headOk(serverUrl)) {
            idleSlideVideoUrl = serverUrl;
            return serverUrl;
        }
        return '';
    }

    function isContestWinner(win) {
        return !!(win && win.result_type === 'winner' && win.winner_terminal_id);
    }

    function isContestForfeit(win) {
        return !!(win && (win.result_type === 'forfeit' || win.is_forfeit));
    }

    function contestRecentResult(contest, isLive) {
        if (!contest || !contest.recent_win || isLive) {
            return null;
        }
        const liveId = Number(contest.contest_id) || 0;
        const resultId = Number(contest.recent_win.contest_id) || 0;
        if (liveId > 0 && resultId > 0 && liveId !== resultId) {
            return null;
        }
        return contest.recent_win;
    }

    function stopCountdown() {
        if (countdownTimer) {
            window.clearInterval(countdownTimer);
            countdownTimer = null;
        }
        if (mpPrizeBox) mpPrizeBox.classList.remove('is-urgent');
        if (mpProgressTrack) mpProgressTrack.classList.remove('is-urgent');
        if (mpProgressFill) mpProgressFill.classList.remove('is-urgent');
        if (mpProgressLabel) mpProgressLabel.classList.remove('is-urgent');
    }

    function getLocalCountdownRemaining() {
        const elapsed = Math.floor((Date.now() - countdownState.syncedAt) / 1000);
        return Math.max(0, countdownState.seconds - elapsed);
    }

    const COUNTDOWN_URGENT_SEC = 60;

    function applyCountdownUrgency(remaining) {
        const urgent = countdownState.mode === 'contest'
            && remaining > 0
            && remaining <= COUNTDOWN_URGENT_SEC;
        if (mpPrizeBox) mpPrizeBox.classList.toggle('is-urgent', urgent);
        if (mpProgressTrack) mpProgressTrack.classList.toggle('is-urgent', urgent);
        if (mpProgressFill) mpProgressFill.classList.toggle('is-urgent', urgent);
        if (mpProgressLabel) mpProgressLabel.classList.toggle('is-urgent', urgent);
    }

    function renderCountdownDisplay() {
        const remaining = getLocalCountdownRemaining();
        if (mpPrizeValue && (countdownState.mode === 'lobby' || countdownState.mode === 'contest')) {
            mpPrizeValue.textContent = formatCountdown(remaining);
        }
        applyCountdownUrgency(remaining);
        if (countdownState.mode === 'contest') {
            const total = Math.max(1, countdownState.totalSeconds);
            const progress = Math.min(100, Math.floor(((total - remaining) / total) * 100));
            if (mpProgressLabel) {
                mpProgressLabel.textContent = `PROGRES TIMP ${progress}%`;
            }
            if (mpProgressFill) {
                mpProgressFill.style.width = `${progress}%`;
            }
        }
    }

    function syncCountdownFromContest(contest, mode) {
        stopCountdown();
        if (!contest || mode === 'won' || mode === 'forfeit' || mode === 'draw') {
            return;
        }
        let seconds = 0;
        let totalSeconds = 300;
        if (mode === 'lobby') {
            seconds = Math.max(0, Math.floor(Number(contest.lobby_seconds_remaining) || 0));
        } else if (mode === 'contest') {
            seconds = Math.max(0, Math.floor(Number(contest.contest_seconds_remaining) || 0));
            totalSeconds = Math.max(1, Math.floor(Number(contest.contest_seconds_total) || 300));
        } else {
            return;
        }
        if (countdownTimer && countdownState.mode === mode) {
            countdownState.seconds = seconds;
            countdownState.totalSeconds = totalSeconds;
            countdownState.syncedAt = Date.now();
            renderCountdownDisplay();
            return;
        }
        stopCountdown();
        countdownState = {
            mode: mode,
            seconds: seconds,
            totalSeconds: totalSeconds,
            syncedAt: Date.now()
        };
        renderCountdownDisplay();
        countdownTimer = window.setInterval(renderCountdownDisplay, 1000);
    }

    function getContestResultId(contest) {
        if (!contest || typeof contest !== 'object') {
            return 0;
        }
        const recent = contest.recent_win;
        return Number(contest.contest_id || (recent && recent.contest_id)) || 0;
    }

    function isContestResultDismissed(contest) {
        const id = getContestResultId(contest);
        return id > 0 && id === dismissedContestResultId;
    }

    function finishContestResultDisplay() {
        const contestId = getContestResultId(state.contest);
        if (contestId) {
            dismissedContestResultId = contestId;
            markMpWinSeen(contestId);
            if (contestId === lastWinContestId || lastWinContestId === 0) {
                lastWinContestId = contestId;
            }
        }
        state.showingContestResult = false;
        state.contestEnabled = false;
        if (contestPanel) contestPanel.classList.add('is-hidden');
        if (mpWinBanner) {
            mpWinBanner.classList.add('is-hidden');
            mpWinBanner.classList.remove('is-celebrate', 'is-forfeit');
        }
        document.body.classList.remove('has-mp-contest', 'has-mp-win', 'has-mp-forfeit');
        stopCountdown();
        restorePrimaryDisplay();
    }

    function hideContest() {
        state.contestEnabled = false;
        state.showingContestResult = false;
        state.contest = null;
        lastContestSignature = '';
        lastForfeitContestId = 0;
        stopCountdown();
        if (mpWinCountTimer) {
            window.clearInterval(mpWinCountTimer);
            mpWinCountTimer = null;
        }
        stopBlitzCountUp();
        blitzShownValue = 0;
        blitzTargetValue = 0;
        if (mpBlitzValue) {
            mpBlitzValue.classList.remove('is-ticking');
            mpBlitzValue.textContent = formatLei(0);
        }
        if (mpWinBanner) {
            mpWinBanner.classList.add('is-hidden');
            mpWinBanner.classList.remove('is-celebrate', 'is-forfeit');
        }
        if (contestPanel) contestPanel.classList.add('is-hidden');
        document.body.classList.remove('has-mp-contest', 'has-mp-win', 'has-mp-forfeit');
    }

    function animateTopWinPrize(prizeLei) {
        if (!mpWinPrize) return;
        if (mpWinCountTimer) window.clearInterval(mpWinCountTimer);
        const target = Math.max(0, Math.round(Number(prizeLei) || 0));
        if (!(target > 0)) {
            mpWinPrize.textContent = '0 LEI';
            return;
        }
        let current = 0;
        const step = Math.max(1, Math.ceil(target / 32));
        mpWinPrize.textContent = '0 LEI';
        mpWinCountTimer = window.setInterval(function () {
            current = Math.min(target, current + step);
            mpWinPrize.textContent = current.toLocaleString('ro-RO') + ' LEI';
            if (current >= target) {
                window.clearInterval(mpWinCountTimer);
                mpWinCountTimer = null;
            }
        }, 45);
    }

    function showWinCelebration(win) {
        if (!win || !mpWinBanner) return;
        stopCountdown();
        const winId = Number(win.contest_id) || 0;
        const alreadySeen = winId && (hasSeenMpWin(winId) || winId === lastWinContestId);
        const name = String(win.winner_name || 'Terminal').toUpperCase();
        const prize = Number(win.prize_amount) || 0;
        const spinWin = Number(win.spin_winnings_credits) || 0;
        const spinLei = Number(win.spin_winnings_lei) || 0;
        const totalLei = Number(win.total_lei_awarded) || (prize + spinLei);
        const prizeText = prize % 1 === 0
            ? `${Math.round(prize)} LEI`
            : `${formatLei(prize)} LEI`;
        const spinText = spinLei > 0
            ? `${spinLei.toLocaleString('ro-RO', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} LEI din spinuri`
            : '';
        const totalText = totalLei % 1 === 0
            ? `${Math.round(totalLei)} LEI`
            : `${formatLei(totalLei)} LEI`;

        if (mpWinTerminal) mpWinTerminal.textContent = name;
        if (mpWinText) {
            mpWinText.textContent = spinText
                ? `Total ${totalText}: premiu Blitz ${prizeText} + ${spinText} pe soldul normal.`
                : `Terminalul ${name} a câștigat premiul de ${prizeText}!`;
        }
        if (mpBadge) mpBadge.textContent = 'CÂȘTIGĂTOR BLITZ';
        if (mpRemaining) {
            mpRemaining.textContent = spinText
                ? `TOTAL ${totalText} · BLITZ ${prizeText} · ${spinText.toUpperCase()}`
                : `PREMIU ACORDAT: ${prizeText}`;
        }
        if (mpProgressFill) mpProgressFill.style.width = '100%';
        if (mpProgressLabel) mpProgressLabel.textContent = 'PROGRES TOTAL CONCURS 100%';
        if (mpPrizeValue) mpPrizeValue.textContent = totalText;
        if (mpBlitzValue) {
            stopBlitzCountUp();
            setBlitzDisplay(totalLei);
            mpBlitzValue.classList.remove('is-ticking');
        }

        mpWinBanner.classList.remove('is-hidden', 'is-forfeit');
        if (alreadySeen) {
            if (winId) {
                lastWinContestId = winId;
            }
            mpWinBanner.classList.add('is-celebrate');
            if (mpWinPrize) {
                mpWinPrize.textContent = totalLei % 1 === 0
                    ? `${Math.round(totalLei)} LEI`
                    : `${formatLei(totalLei)} LEI`;
            }
        } else if (winId) {
            lastWinContestId = winId;
            mpWinBanner.classList.remove('is-celebrate');
            void mpWinBanner.offsetWidth;
            mpWinBanner.classList.add('is-celebrate');
            animateTopWinPrize(totalLei);
            markMpWinSeen(winId);
            playTopMpEpicSound();
        }
        document.body.classList.remove('has-mp-forfeit');
        document.body.classList.add('has-mp-win');
    }

    function showForfeitBanner(forfeit) {
        if (!forfeit || !mpWinBanner) return;
        stopCountdown();
        stopTopMpEpicSound();
        const forfeitId = Number(forfeit.contest_id) || 0;
        const message = String(forfeit.message || 'Terminalele au pierdut — niciun terminal nu a terminat cele 50 de spinuri in timpul de 5 minute al concursului.');

        if (mpWinTerminal) mpWinTerminal.textContent = 'TERMINALELE AU PIERDUT';
        if (mpWinText) mpWinText.textContent = message;
        if (mpWinPrize) mpWinPrize.textContent = 'PREMIU NEACORDAT';
        if (mpBadge) mpBadge.textContent = 'CONCURS INCHEIAT';
        if (mpRemaining) {
            mpRemaining.textContent = '50 SPINURI NEFINALIZATE IN 5 MINUTE';
        }
        if (mpProgressFill) mpProgressFill.style.width = '100%';
        if (mpProgressLabel) mpProgressLabel.textContent = 'TIMP CONCURS EXPIRAT';

        mpWinBanner.classList.remove('is-hidden', 'is-celebrate');
        mpWinBanner.classList.add('is-forfeit');
        if (forfeitId && forfeitId !== lastForfeitContestId) {
            lastForfeitContestId = forfeitId;
        }
        document.body.classList.remove('has-mp-win');
        document.body.classList.add('has-mp-forfeit');
    }

    let topMpEpicAudio = null;
    function stopTopMpEpicSound() {
        if (!topMpEpicAudio) return;
        try {
            topMpEpicAudio.pause();
            topMpEpicAudio.currentTime = 0;
        } catch (e) {}
        topMpEpicAudio = null;
    }
    function playTopMpEpicSound() {
        stopTopMpEpicSound();
        const urls = [
            '../games/shared/sounds/jackpot.mp3',
            '/games/shared/sounds/jackpot.mp3',
            '../games/shared/sounds/hugewin.mp3'
        ];
        let idx = 0;
        function tryNext() {
            if (idx >= urls.length) return;
            const url = urls[idx];
            idx += 1;
            try {
                topMpEpicAudio = new Audio(url);
                topMpEpicAudio.volume = 0.85;
                topMpEpicAudio.play().catch(tryNext);
                window.setTimeout(stopTopMpEpicSound, 12000);
            } catch (e) {
                tryNext();
            }
        }
        tryNext();
    }

    function hideWinCelebration() {
        if (mpWinCountTimer) {
            window.clearInterval(mpWinCountTimer);
            mpWinCountTimer = null;
        }
        if (mpBoard) mpBoard.classList.remove('is-win-board');
        if (mpWinBanner) {
            mpWinBanner.classList.add('is-hidden');
            mpWinBanner.classList.remove('is-celebrate', 'is-forfeit');
        }
        document.body.classList.remove('has-mp-win', 'has-mp-forfeit');
    }

    function showContest() {
        hideIdle();
        if (contestPanel) contestPanel.classList.remove('is-hidden');
        if (infoPanel) infoPanel.classList.add('is-hidden');
        stopCarousel();
        document.body.classList.add('has-mp-contest');
    }

    function showPaytable() {
        hideIdle();
        if (contestPanel) contestPanel.classList.add('is-hidden');
        if (infoPanel) infoPanel.classList.remove('is-hidden');
        document.body.classList.remove('has-mp-contest', 'has-mp-win');
    }

    function paintPaytableHtml(html) {
        if (!track || !html) return;
        track.innerHTML = collapseInfoPagesForTopDisplay(html);
        pageIndex = 0;
        track.querySelectorAll('img').forEach((img) => {
            if (img.complete) return;
            img.addEventListener('load', scheduleFitInfoPages, { once: true });
        });
    }

    function restorePrimaryDisplay() {
        if (isContestBlockingInfo()) {
            showContest();
            return;
        }

        if (isGamePhaseActive()) {
            state.phase = 'game';
            if (state.html) {
                paintGameInfo(state.html);
            } else {
                showGameLoading();
                ensurePaytableLoader(state.slug, state.title);
            }
            return;
        }

        applyLobby();
    }

    function isMpParticipant(contest) {
        if (!contest || typeof contest !== 'object') {
            return false;
        }
        return contest.is_participant === true || contest.is_participant === 1;
    }

    function isMpLobbyInvite(contest) {
        if (!contest || typeof contest !== 'object') {
            return false;
        }
        if (contest.lobby_invite === true) {
            return true;
        }
        if (contest.lobby_open === true && !isMpParticipant(contest)) {
            return true;
        }
        return String(contest.mode || '') === 'lobby' && !isMpParticipant(contest);
    }

    function isContestLive(contest) {
        if (!contest || typeof contest !== 'object') {
            return false;
        }
        const mode = String(contest.mode || '');
        // Doar lobby/concurs activ blocheaza paytable — nu "enabled"/ready.
        return mode === 'lobby' || mode === 'contest';
    }

    function isContestBlockingInfo() {
        if (state.showingContestResult) {
            return true;
        }
        return isContestLive(state.contest);
    }

    function forceShowGameShell(title) {
        hideIdle();
        if (isContestBlockingInfo()) {
            showContest();
            return false;
        }
        if (titleNode && title) {
            titleNode.textContent = title;
        }
        showPaytable();
        return true;
    }

    function absolutizePaytableHtml(html, slug) {
        const raw = String(html || '').trim();
        const gameSlug = String(slug || '').toLowerCase();
        if (!raw || !gameSlug) {
            return raw;
        }
        try {
            const base = new URL('../games/' + encodeURIComponent(gameSlug) + '/', window.location.href);
            const doc = new DOMParser().parseFromString('<div id="iqwin-pay-root">' + raw + '</div>', 'text/html');
            const root = doc.getElementById('iqwin-pay-root');
            if (!root) {
                return raw;
            }
            root.querySelectorAll('[src]').forEach((el) => {
                const src = el.getAttribute('src');
                if (!src || /^(https?:|data:|blob:|\/\/|\/)/i.test(src)) {
                    return;
                }
                el.setAttribute('src', new URL(src, base).href);
            });
            root.querySelectorAll('[srcset]').forEach((el) => {
                el.removeAttribute('srcset');
            });
            return root.innerHTML;
        } catch (error) {
            return raw;
        }
    }

    function stopPaytableLoader() {
        if (paytableLoaderTimer) {
            window.clearTimeout(paytableLoaderTimer);
            paytableLoaderTimer = null;
        }
        paytableLoaderSlug = '';
        if (paytableLoaderFrame) {
            try {
                paytableLoaderFrame.remove();
            } catch (error) {
            }
            paytableLoaderFrame = null;
        }
    }

    function ensurePaytableLoader(slug, title) {
        const gameSlug = String(slug || '').toLowerCase();
        if (!gameSlug || !PAYTABLE_SLUGS[gameSlug]) {
            return;
        }
        if (isContestBlockingInfo()) {
            return;
        }
        if (trackHasPaytablePages()) {
            return;
        }
        if (paytableLoaderSlug === gameSlug && paytableLoaderFrame) {
            return;
        }

        stopPaytableLoader();
        paytableLoaderSlug = gameSlug;
        forceShowGameShell(title || state.title || '');
        if (!trackHasLoadingPlaceholder()) {
            showGameLoading();
        }

        const frame = document.createElement('iframe');
        frame.setAttribute('title', 'paytable-loader');
        frame.setAttribute('aria-hidden', 'true');
        frame.tabIndex = -1;
        frame.style.cssText = 'position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;left:-20px;top:-20px;border:0;';
        frame.src = new URL(
            '../games/' + encodeURIComponent(gameSlug) + '/?iqwinPaytableExport=1&_=' + Date.now(),
            window.location.href
        ).href;
        document.body.appendChild(frame);
        paytableLoaderFrame = frame;

        // Safety: reincarca o data daca HTML-ul nu vine.
        paytableLoaderTimer = window.setTimeout(() => {
            if (trackHasPaytablePages() || paytableLoaderSlug !== gameSlug) {
                return;
            }
            if (paytableLoaderFrame) {
                paytableLoaderFrame.src = new URL(
                    '../games/' + encodeURIComponent(gameSlug) + '/?iqwinPaytableExport=1&_=' + Date.now(),
                    window.location.href
                ).href;
            }
        }, 6000);
    }

    function clearContestResultRestoreTimer() {
        if (contestResultRestoreTimer) {
            window.clearTimeout(contestResultRestoreTimer);
            contestResultRestoreTimer = null;
        }
    }

    function scheduleInfoRestoreAfterContestResult(delayMs) {
        clearContestResultRestoreTimer();
        contestResultRestoreTimer = window.setTimeout(function () {
            contestResultRestoreTimer = null;
            finishContestResultDisplay();
        }, Math.max(0, Number(delayMs) || CONTEST_RESULT_DISPLAY_MS));
    }

    function renderContest(contest) {
        if (!contest || typeof contest !== 'object') {
            const wasEnabled = !!state.contestEnabled;
            hideContest();
            if (wasEnabled) {
                restorePrimaryDisplay();
            }
            return;
        }

        const mode = String(contest.mode || '');
        const isLive = mode === 'lobby' || mode === 'contest';
        const recentResult = contestRecentResult(contest, isLive);
        const hasWin = isContestWinner(recentResult);
        const hasForfeit = isContestForfeit(recentResult);
        const hasRecentResult = hasWin || hasForfeit;

        if (!isLive && !hasRecentResult) {
            if (state.showingContestResult) {
                return;
            }
            const wasEnabled = !!state.contestEnabled;
            state.contest = contest;
            state.contestEnabled = false;
            if (wasEnabled && !dismissedContestResultId) {
                clearContestResultRestoreTimer();
                hideContest();
                restorePrimaryDisplay();
            }
            return;
        }

        state.contest = contest;

        if (!isLive && hasRecentResult) {
            if (isContestResultDismissed(contest)) {
                state.contest = contest;
                state.contestEnabled = false;
                state.showingContestResult = false;
                if (isGamePhaseActive()) {
                    restorePrimaryDisplay();
                }
                return;
            }
            if (state.showingContestResult) {
                state.contest = contest;
                return;
            }
            state.contestEnabled = false;
            state.showingContestResult = true;
            clearContestResultRestoreTimer();
            showContest();
            if (hasWin) {
                showWinCelebration(recentResult);
            } else {
                hideWinCelebration();
                showForfeitBanner(recentResult);
            }
            scheduleInfoRestoreAfterContestResult(CONTEST_RESULT_DISPLAY_MS);
            return;
        }

        clearContestResultRestoreTimer();
        state.contestEnabled = true;
        state.showingContestResult = false;
        showContest();
        hideWinCelebration();
        lastForfeitContestId = 0;

        const signature = JSON.stringify({
            id: contest.contest_id || null,
            pool: contest.pool_amount,
            terminals: contest.terminals,
            win: null,
            mode: contest.mode || null,
            enabled: isLive,
            lobby_invite: !!contest.lobby_invite,
            lobby_open: !!contest.lobby_open,
            is_participant: !!contest.is_participant,
            participants_count: contest.participants_count || 0,
            contest_revision: contest.contest_revision || 0,
            station_id: contest.station_id || 0
        });
        if (signature === lastContestSignature) {
            if (!hasWin && !hasForfeit) {
                syncCountdownFromContest(contest, mode);
                const lobbyInvite = isMpLobbyInvite(contest);
                if (contestPanel) {
                    contestPanel.classList.toggle('is-lobby-invite', !!lobbyInvite);
                }
            }
            return;
        }
        lastContestSignature = signature;

        if (mpBadge && !hasWin && !hasForfeit) {
            const lobbyInvite = isMpLobbyInvite(contest);
            if (contestPanel) {
                contestPanel.classList.toggle('is-lobby-invite', !!lobbyInvite);
            }
            if (mode === 'lobby') {
                mpBadge.textContent = lobbyInvite ? 'BLITZ DESCHIS' : 'LOBBY BLITZ';
            } else {
                contestPanel && contestPanel.classList.remove('is-lobby-invite');
                mpBadge.textContent = 'CONCURS BLITZ';
            }
        } else if (contestPanel) {
            contestPanel.classList.remove('is-lobby-invite');
        }

        if (mpPrizeBox) {
            mpPrizeBox.classList.toggle('is-lobby-timer', mode === 'lobby' && !hasWin && !hasForfeit);
        }

        if (mpPrizeValue && !hasWin && !hasForfeit) {
            const mpPrizeKicker = document.getElementById('mpPrizeKicker');
            const mpPrizeNote = document.getElementById('mpPrizeNote');
            if (mode === 'lobby') {
                if (mpPrizeKicker) mpPrizeKicker.textContent = 'LOBBY';
                if (mpPrizeNote) mpPrizeNote.textContent = `Așteptăm concurenți · intrare ${Math.round(Number(contest.entry_fee) || 0)} LEI`;
            } else if (mode === 'contest') {
                if (mpPrizeKicker) mpPrizeKicker.textContent = 'TIMP RĂMAS';
                const spinLei = Number(contest.spin_lei || (contest.tier && contest.tier.spin_lei)) || 1;
                if (mpPrizeNote) {
                    mpPrizeNote.textContent = '50 SPINURI × ' + spinLei.toLocaleString('ro-RO') + ' LEI · castigator = Blitz + spinuri';
                }
            }
            syncCountdownFromContest(contest, mode);
        }

        if (mpBlitzValue && isLive && !hasWin && !hasForfeit) {
            animateBlitzTo(Number(contest.pool_amount) || 0);
        }

        if (mpSidePct && !hasWin && !hasForfeit) {
            const fee = Number(contest.entry_fee) || 0;
            mpSidePct.textContent = fee > 0 ? `${Math.round(fee)} LEI` : '—';
        }

        if (mpRules) {
            const rules = Array.isArray(contest.rules) ? contest.rules : [];
            mpRules.innerHTML = rules.map((rule) => `<li>${escapeHtml(rule)}</li>`).join('');
        }

        if (mpBoard && Array.isArray(contest.terminals)) {
            mpBoard.classList.toggle('is-win-board', hasWin);
            const terminals = contest.terminals.slice(0, 3);
            const slots = [0, 1, 2].map((index) => terminals[index] || null);
            mpBoard.innerHTML = slots.map((entry, index) => {
                const rank = entry ? (Number(entry.rank) || (index + 1)) : (index + 1);
                if (!entry) {
                    return `
                        <li class="mp-contest__row is-empty ${medalClass(rank)}">
                            <span class="mp-contest__rank" aria-hidden="true">${rank}</span>
                            <div class="mp-contest__row-main">
                                <div class="mp-contest__row-head">
                                    <strong>LOC LIBER</strong>
                                    <span>SUMĂ: 0,00 LEI</span>
                                </div>
                                <div class="mp-contest__row-bar">
                                    <i style="width:0%"></i>
                                </div>
                                <div class="mp-contest__row-meta">Așteaptă un terminal</div>
                            </div>
                        </li>
                    `;
                }
                const pct = Math.max(0, Math.min(100, Number(entry.progress_pct) || 0));
                const spinsUsed = Number(entry.spins_used) || 0;
                const spinsReq = Number(entry.spins_required) || 50;
                const blitzWin = Number(entry.contest_winnings_lei) || Number(entry.contest_winnings) || 0;
                const isWinnerLive = hasWin && entry.is_winner;
                const barPct = isWinnerLive ? 100 : pct;
                const selfClass = entry.is_self ? ' is-self' : '';
                const winnerClass = entry.is_winner ? ' is-winner' : '';
                const winnerLiveClass = isWinnerLive ? ' is-winner-live' : '';
                let metaText = entry.is_winner ? 'CÂȘTIGĂTOR' : (hasForfeit ? (spinsUsed + '/' + spinsReq + ' SPINURI — INCOMPLET') : (spinsUsed + '/' + spinsReq + ' SPINURI'));
                if (entry.is_self && !entry.is_winner) {
                    metaText = 'TERMINALUL TĂU · ' + metaText;
                }
                const selfAria = entry.is_self ? ' aria-label="Pozitia ta in concurs"' : '';
                return `
                    <li class="mp-contest__row ${medalClass(rank)}${selfClass}${winnerClass}${winnerLiveClass}"${selfAria}>
                        <span class="mp-contest__rank" aria-hidden="true">${rank}</span>
                        <div class="mp-contest__row-main">
                            <div class="mp-contest__row-head">
                                <strong>${escapeHtml(entry.name || 'Terminal')}</strong>
                                <span>CÂȘTIG: ${Number(blitzWin).toLocaleString('ro-RO', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} LEI</span>
                            </div>
                            <div class="mp-contest__row-bar">
                                <i style="width:${barPct}%"></i>
                            </div>
                            <div class="mp-contest__row-meta">${metaText}</div>
                        </div>
                    </li>
                `;
            }).join('');
        }

        const progress = Math.max(0, Math.min(100, Number(contest.progress_pct) || 0));
        if (mpProgressLabel && !hasWin && !hasForfeit) {
            if (mode === 'lobby') {
                const count = Number(contest.participants_count) || 0;
                mpProgressLabel.textContent = `CONCURENȚI: ${count}`;
            } else if (countdownState.mode !== 'contest') {
                mpProgressLabel.textContent = `PROGRES TIMP ${progress}%`;
            }
        }
        if (mpProgressFill && !hasWin && !hasForfeit && countdownState.mode !== 'contest') {
            mpProgressFill.style.width = `${progress}%`;
        }
        if (mpRemaining && !hasWin && !hasForfeit) {
            if (mode === 'lobby') {
                const count = Number(contest.participants_count) || 0;
                const minCount = Number(contest.lobby_min_participants) || 2;
                if (count < minCount) {
                    mpRemaining.textContent = `MINIM ${minCount} TERMINALE PENTRU START`;
                } else {
                    mpRemaining.textContent = 'PORNEȘTE MANUAL SAU EXPIRARE TIMP';
                }
            } else {
                const pool = Number(contest.pool_amount) || 0;
                mpRemaining.textContent = `PREMIU BLITZ: ${formatLei(pool)} LEI`;
            }
        }
    }

    function formatCountdown(totalSeconds) {
        const s = Math.max(0, Math.floor(Number(totalSeconds) || 0));
        const m = Math.floor(s / 60);
        const r = s % 60;
        return String(m).padStart(2, '0') + ':' + String(r).padStart(2, '0');
    }

    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function applyLobby(options) {
        const opts = options || {};
        if (opts.noteLocal) {
            noteTerminalState({ type: 'state', phase: 'lobby' });
        }
        stopPaytableLoader();
        state.phase = 'lobby';
        state.slug = '';
        state.title = '';
        state.html = '';
        lastDisplaySignature = 'lobby';
        stopCarousel();
        if (track) track.innerHTML = '';
        if (titleNode) titleNode.textContent = '';
        setLoading(false);
        armPollTimer();

        if (isContestBlockingInfo()) {
            showContest();
            return;
        }

        if (isLobbyIdleDisplayed()) {
            return;
        }

        showIdle();
    }

    function applyGame(message, options) {
        const opts = options || {};
        if (opts.noteLocal) {
            noteTerminalState(message);
        }
        const slug = String(message.slug || '').toLowerCase();
        const title = String(message.title || '').trim();
        const prevSlug = String(state.slug || '').toLowerCase();

        if (state.phase === 'lobby' || (prevSlug && slug && prevSlug !== slug)) {
            state.html = '';
        }

        state.phase = 'game';
        state.slug = slug;
        if (title) state.title = title;

        if (isContestBlockingInfo()) {
            showContest();
            return;
        }

        if (state.html) {
            paintGameInfo(state.html);
            return;
        }

        showGameLoading();
        ensurePaytableLoader(slug || state.slug, title || state.title);
    }

    function applyInfoHtml(message, options) {
        const opts = options || {};
        const slug = String(message.slug || '').toLowerCase();
        if (!message.html) return;
        if (state.phase === 'game' && state.slug && slug && slug !== state.slug) return;

        state.phase = 'game';
        if (slug) state.slug = slug;
        state.html = message.html;
        if (message.title) state.title = message.title;
        if (opts.noteLocal) {
            lastTerminalState = {
                phase: 'game',
                slug: slug || state.slug,
                ts: Date.now()
            };
        }

        if (isContestBlockingInfo()) {
            return;
        }

        paintGameInfo(message.html);
    }

    function applyDisplayFromPoll(display) {
        if (!display || typeof display !== 'object') {
            return;
        }

        const phase = String(display.phase || 'lobby').toLowerCase() === 'game' ? 'game' : 'lobby';
        const slug = String(display.slug || '').toLowerCase();
        const title = String(display.title || '').trim();
        const html = String(display.html || '').trim();

        if (phase === 'lobby') {
            if (isLobbyIdleDisplayed()) {
                return;
            }
            applyLobby({ noteLocal: false });
            return;
        }

        // Fortat: iesi din logo imediat cand serverul zice "game" (fara concurs).
        const wasLobby = state.phase !== 'game';
        state.phase = 'game';
        if (slug) state.slug = slug;
        if (title) state.title = title;
        if (wasLobby) {
            armPollTimer();
        }
        forceShowGameShell(title || state.title || '');

        if (!html) {
            if (!trackHasPaytablePages()) {
                showGameLoading();
                ensurePaytableLoader(slug || state.slug, title || state.title);
            }
            return;
        }

        if (
            state.slug === slug
            && trackHasPaytablePages()
            && !isContestBlockingInfo()
            && infoPanel
            && !infoPanel.classList.contains('is-hidden')
            && !trackHasLoadingPlaceholder()
        ) {
            return;
        }

        applyInfoHtml({
            slug: slug || state.slug,
            title: title || state.title,
            html: html
        }, { noteLocal: false });
    }

    function handleMessage(message) {
        if (!message || !message.type) return;

        if (message.type === 'contest') {
            renderContest(message.contest || { enabled: false });
            return;
        }

        if (message.type === 'state') {
            if (message.phase === 'lobby') {
                applyLobby({ noteLocal: true });
                return;
            }
            if (message.phase === 'game') {
                applyGame(message, { noteLocal: true });
                return;
            }
        }

        if (message.type === 'info-html') {
            applyInfoHtml(message, { noteLocal: true });
        }
    }

    window.addEventListener('message', (event) => {
        const data = event && event.data;
        if (!data || (data.type !== 'info-html' && data.type !== 'iqwin-top-display-info')) {
            return;
        }
        if (!data.html) {
            return;
        }
        const slug = String(data.slug || '').toLowerCase();
        if (state.phase === 'game' && state.slug && slug && slug !== state.slug) {
            return;
        }
        // Iframe-ul de export NU e semnal BC local — nu bloca lobby-ul ulterior.
        applyInfoHtml({
            slug: slug || state.slug,
            title: data.title || state.title,
            html: data.html
        }, { noteLocal: false });
    });

    function readStoredState() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) return;
            const message = JSON.parse(raw);
            if (!message || !message.type) return;
            if (message.type === 'contest') return;
            handleMessage(message);
        } catch (error) {
        }
    }

    function apiBase() {
        const stored = localStorage.getItem(SERVER_KEY);
        if (stored) {
            return stored.replace(/\/$/, '') + '/api/terminal';
        }
        return window.location.origin + '/api/terminal';
    }

    function loadCredentials() {
        try {
            const raw = localStorage.getItem(CREDENTIALS_KEY);
            return raw ? JSON.parse(raw) : null;
        } catch (error) {
            return null;
        }
    }

    async function pollTopState() {
        const credentials = loadCredentials();
        if (!credentials || !credentials.terminal_code || !credentials.api_secret) {
            if (!state.contestEnabled && state.phase !== 'game' && !isLobbyIdleDisplayed()) {
                showIdle();
            }
            return;
        }

        try {
            const url = new URL(apiBase() + '/contest.php', window.location.href);
            url.searchParams.set('terminal_code', credentials.terminal_code);
            url.searchParams.set('api_secret', credentials.api_secret);
            const response = await fetch(url.toString(), {
                method: 'GET',
                headers: {
                    'X-Terminal-Code': credentials.terminal_code,
                    'X-Terminal-Secret': credentials.api_secret
                },
                cache: 'no-store'
            });
            const data = await response.json();
            if (!response.ok || !data || !data.ok) {
                return;
            }

            if (data.display) {
                applyDisplayFromPoll(data.display);
            }

            renderContest(data.contest || { enabled: false });
        } catch (error) {
        }
    }

    function currentPollMs() {
        // In joc poll mai des ca la close lobby-ul sa apara aproape instant.
        return state.phase === 'game' || !!String(state.slug || '').trim() ? 250 : POLL_MS;
    }

    function armPollTimer() {
        if (pollTimer) {
            window.clearInterval(pollTimer);
        }
        const ms = currentPollMs();
        pollTimer = window.setInterval(pollTopState, ms);
    }

    function startPolling() {
        pollTopState();
        armPollTimer();
    }

    try {
        const channel = new BroadcastChannel(CHANNEL);
        channel.addEventListener('message', (event) => {
            handleMessage(event.data);
        });
    } catch (error) {
    }

    window.addEventListener('storage', (event) => {
        if (event.key !== STORAGE_KEY || !event.newValue) return;
        try {
            const message = JSON.parse(event.newValue);
            if (!message || message.type === 'contest') return;
            handleMessage(message);
        } catch (error) {
        }
    });

    readStoredState();
    if (!state.contestEnabled && state.phase !== 'game') {
        applyLobby();
    }

    if (idleSlideVideoEl) {
        idleSlideVideoEl.addEventListener('ended', onIdleSlideVideoEnded);
    }

    probeIdleSlideVideoUrl().then(function () {
        if (!canRunIdleSlideLoop()) return;
        if (!idleSlideLogoTimer && !isIdleSlideVideoShowing()) {
            scheduleIdleSlideLogoWait();
        }
    });

    startPolling();

    function tryEnterFullscreen() {
        const root = document.documentElement;
        if (!root.requestFullscreen || document.fullscreenElement) return;
        root.requestFullscreen().catch(() => {});
    }

    window.addEventListener('load', () => {
        window.setTimeout(tryEnterFullscreen, 350);
        scheduleFitInfoPages();
    });

    window.addEventListener('resize', () => {
        scheduleFitInfoPages();
    });
})();
