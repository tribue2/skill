(() => {
    const CHANNEL = 'iqwin-terminal-top-display';
    const STORAGE_KEY = 'iqwin-top-display-state';
    const WINDOW_NAME = 'iqwin-top-display';
    const CREDENTIALS_KEY = 'skill_terminal_credentials';
    const SERVER_KEY = 'skill_terminal_server';

    let topDisplayWindow = null;
    let launcherInitialized = false;
    let pushTimer = null;
    let lastPushSignature = '';
    const paytableCache = Object.create(null);

    function resolveGameSlug(game) {
        if (!game) return '';
        const slug = String(game.slug || '').toLowerCase();
        if (slug) return slug;
        const iconKey = String(game.icon_key || '').toLowerCase();
        if (iconKey) return iconKey;
        const title = String(game.title || '');
        if (/verga\s*gold|golden\s*brain|brain\s*way/i.test(title)) return 'verga-gold';
        if (/boss\s*crown|millionaire\s*crown/i.test(title)) return 'boss-crown';
        if (/dodge\s*bomb/i.test(title)) return 'dodge-bomb';
        if (/logic\s*and\s*zeus|fire\s*scatter/i.test(title)) return 'logic-and-zeus';
        if (/40\s*burn\s*hot|wild\s*clover/i.test(title)) return '40-burn-hot';
        if (/intelligent\s*book|cartea\s*inteligent|book\s*of\s*knowledge/i.test(title)) return 'intelligent-book';
        return '';
    }

    function loadCredentials() {
        try {
            const raw = localStorage.getItem(CREDENTIALS_KEY);
            return raw ? JSON.parse(raw) : null;
        } catch (error) {
            return null;
        }
    }

    function apiBase() {
        const stored = localStorage.getItem(SERVER_KEY);
        if (stored) {
            return stored.replace(/\/$/, '') + '/api/terminal';
        }
        return window.location.origin + '/api/terminal';
    }

    function sendChannel(message) {
        const payload = Object.assign({}, message, { ts: Date.now() });
        try {
            const channel = new BroadcastChannel(CHANNEL);
            channel.postMessage(payload);
            channel.close();
        } catch (error) {
        }
        return payload;
    }

    function send(message) {
        const payload = sendChannel(message);
        if (message && (message.type === 'state' || message.type === 'info-html')) {
            try {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
            } catch (error) {
            }
        }
        return payload;
    }

    function pushDisplayToServer(display, options) {
        const credentials = loadCredentials();
        if (!credentials || !credentials.terminal_code || !credentials.api_secret) {
            return Promise.resolve(false);
        }

        const force = !!(options && options.force);
        const body = {
            phase: display.phase === 'game' ? 'game' : 'lobby',
            slug: String(display.slug || ''),
            title: String(display.title || ''),
            html: display.phase === 'game' ? String(display.html || '') : '',
            terminal_code: credentials.terminal_code,
            api_secret: credentials.api_secret
        };

        const payload = JSON.stringify(body);
        const signature = JSON.stringify({
            phase: body.phase,
            slug: body.slug,
            title: body.title,
            htmlLen: body.html.length,
            htmlHead: body.html.slice(0, 120)
        });
        if (!force && signature === lastPushSignature) {
            return Promise.resolve(true);
        }
        lastPushSignature = signature;

        const url = apiBase() + '/display.php';
        // keepalive are limita 64KB pe body — HTML-ul paytable o depaseste si fetch-ul
        // esueaza silent. Folosim keepalive doar pentru payload-uri mici (lobby / game gol).
        const useKeepalive = payload.length < 60000;

        return fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Terminal-Code': credentials.terminal_code,
                'X-Terminal-Secret': credentials.api_secret
            },
            body: payload,
            cache: 'no-store',
            keepalive: useKeepalive
        }).then((response) => {
            if (!response.ok) {
                lastPushSignature = '';
                return false;
            }
            return true;
        }).catch(() => {
            lastPushSignature = '';
            return false;
        });
    }

    function queueDisplayPush(display, options) {
        const opts = options || {};
        if (opts.immediate) {
            if (pushTimer) {
                window.clearTimeout(pushTimer);
                pushTimer = null;
            }
            return pushDisplayToServer(display, { force: true });
        }
        if (pushTimer) {
            window.clearTimeout(pushTimer);
        }
        pushTimer = window.setTimeout(() => {
            pushTimer = null;
            pushDisplayToServer(display, { force: !!opts.force });
        }, display && display.html ? 120 : 20);
        return Promise.resolve(false);
    }

    function buildTopDisplayUrl() {
        return new URL('top-display.php', window.location.href).href;
    }

    function isUsableTopDisplayWindow(win) {
        if (!win || win.closed) return false;
        try {
            return String(win.location.pathname || '').includes('top-display');
        } catch (error) {
            return true;
        }
    }

    async function resolveSecondaryScreen() {
        if (window.getScreenDetails) {
            try {
                const details = await window.getScreenDetails();
                const screens = Array.from(details.screens || []);
                if (screens.length > 1) {
                    const current = details.currentScreen;
                    return screens.find((screen) => screen !== current) || screens[1];
                }
            } catch (error) {
            }
        }

        const current = window.screen;
        return {
            availLeft: (current.availLeft || 0) + (current.availWidth || window.innerWidth),
            availTop: current.availTop || 0,
            availWidth: current.availWidth || window.innerWidth,
            availHeight: current.availHeight || window.innerHeight
        };
    }

    function buildWindowFeatures(screen) {
        const left = Math.round(screen.availLeft ?? screen.left ?? 0);
        const top = Math.round(screen.availTop ?? screen.top ?? 0);
        const width = Math.round(screen.availWidth ?? screen.width ?? window.innerWidth);
        const height = Math.round(screen.availHeight ?? screen.height ?? window.innerHeight);

        return [
            `left=${left}`,
            `top=${top}`,
            `width=${width}`,
            `height=${height}`,
            'menubar=no',
            'toolbar=no',
            'location=no',
            'status=no',
            'scrollbars=no',
            'resizable=yes'
        ].join(',');
    }

    function positionTopDisplayWindow(win, screen) {
        if (!win || win.closed || !screen) return;
        try {
            win.moveTo(
                Math.round(screen.availLeft ?? screen.left ?? 0),
                Math.round(screen.availTop ?? screen.top ?? 0)
            );
            win.resizeTo(
                Math.round(screen.availWidth ?? screen.width ?? window.innerWidth),
                Math.round(screen.availHeight ?? screen.height ?? window.innerHeight)
            );
            win.focus();
        } catch (error) {
        }
    }

    async function ensureTopDisplayWindow() {
        if (isUsableTopDisplayWindow(topDisplayWindow)) {
            positionTopDisplayWindow(topDisplayWindow, await resolveSecondaryScreen());
            return topDisplayWindow;
        }

        const existing = window.open('', WINDOW_NAME);
        if (isUsableTopDisplayWindow(existing)) {
            topDisplayWindow = existing;
            positionTopDisplayWindow(topDisplayWindow, await resolveSecondaryScreen());
            return topDisplayWindow;
        }

        const secondaryScreen = await resolveSecondaryScreen();
        const opened = window.open(
            buildTopDisplayUrl(),
            WINDOW_NAME,
            buildWindowFeatures(secondaryScreen)
        );

        if (!opened) {
            return null;
        }

        topDisplayWindow = opened;
        window.setTimeout(() => {
            positionTopDisplayWindow(topDisplayWindow, secondaryScreen);
        }, 120);
        window.setTimeout(() => {
            positionTopDisplayWindow(topDisplayWindow, secondaryScreen);
        }, 900);

        return topDisplayWindow;
    }

    function bindTopDisplayRetry() {
        const retry = () => {
            ensureTopDisplayWindow();
            document.removeEventListener('pointerdown', retry, true);
            document.removeEventListener('keydown', retry, true);
        };

        document.addEventListener('pointerdown', retry, true);
        document.addEventListener('keydown', retry, true);
    }

    function initTopDisplayLauncher() {
        if (launcherInitialized) return;
        launcherInitialized = true;

        ensureTopDisplayWindow().then((win) => {
            if (!win) {
                bindTopDisplayRetry();
            }
        });
    }

    window.TerminalDisplaySync = {
        initTopDisplayLauncher,

        ensureTopDisplayWindow() {
            return ensureTopDisplayWindow();
        },

        broadcastLobby() {
            send({ type: 'state', phase: 'lobby' });
            queueDisplayPush({ phase: 'lobby', slug: '', title: '', html: '' }, { immediate: true });
        },

        broadcastGame(game) {
            const slug = resolveGameSlug(game);
            const title = String(game && game.title ? game.title : '');
            const cached = slug && paytableCache[slug] ? paytableCache[slug] : null;
            const html = cached && cached.html ? cached.html : '';
            const pushTitle = cached && cached.title ? cached.title : title;
            if (html) {
                send({
                    type: 'info-html',
                    slug,
                    title: pushTitle,
                    html
                });
            }
            send({
                type: 'state',
                phase: 'game',
                slug,
                title
            });
            // Fortat + imediat: top-display (alt profil) iese din logo la urmatorul poll.
            queueDisplayPush({
                phase: 'game',
                slug,
                title: pushTitle,
                html
            }, { immediate: true });
            [500, 1500, 3500, 7000].forEach((delay) => {
                window.setTimeout(() => {
                    const again = slug && paytableCache[slug] ? paytableCache[slug] : null;
                    const nextHtml = again && again.html ? again.html : html;
                    // Nu re-trimite HTML gol — poate bloca / intarzia paytable-ul real.
                    if (!nextHtml) {
                        return;
                    }
                    queueDisplayPush({
                        phase: 'game',
                        slug,
                        title: again && again.title ? again.title : pushTitle,
                        html: nextHtml
                    }, { immediate: true });
                }, delay);
            });
        },

        broadcastContest(contest) {
            sendChannel({
                type: 'contest',
                contest: contest && typeof contest === 'object' ? contest : { enabled: false }
            });
        },

        forwardInfoHtml(data) {
            if (!data || !data.html) return;
            const slug = String(data.slug || '').toLowerCase();
            const title = String(data.title || '');
            const html = String(data.html || '');
            if (!html.trim()) return;
            if (slug) {
                paytableCache[slug] = { title, html };
            }
            send({
                type: 'info-html',
                slug,
                title,
                html
            });
            const payload = { phase: 'game', slug, title, html };
            queueDisplayPush(payload, { immediate: true }).then((ok) => {
                if (ok) return;
                // Retry daca primul push a picat (ex. race / retea).
                window.setTimeout(() => {
                    queueDisplayPush(payload, { immediate: true });
                }, 700);
                window.setTimeout(() => {
                    queueDisplayPush(payload, { immediate: true });
                }, 2200);
            });
        },

        requestGameInfo(frame) {
            if (!frame || !frame.contentWindow) return;

            const notify = () => {
                try {
                    frame.contentWindow.postMessage({ type: 'iqwin-top-display-request' }, '*');
                } catch (error) {
                }
            };

            notify();
            frame.addEventListener('load', notify, { once: true });
            [700, 2200, 4500, 8000, 12000].forEach((delay) => {
                window.setTimeout(notify, delay);
            });
        }
    };
})();
