(function () {
    const canvas = document.querySelector('.kiosk-starfield-canvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let stars = [];
    let meteors = [];
    let width = 0;
    let height = 0;
    let dpr = 1;
    let lastTime = 0;
    let nextMeteorAt = 0;
    let rafId = null;
    let resizeTimer = null;

    function getStarColor() {
        const roll = Math.random();
        if (roll < 0.55) return { r: 255, g: 255, b: 255 };
        if (roll < 0.72) return { r: 255, g: 248, b: 220 };
        if (roll < 0.86) return { r: 232, g: 210, b: 170 };
        if (roll < 0.94) return { r: 245, g: 230, b: 168 };
        return { r: 255, g: 235, b: 190 };
    }

    function createStar() {
        const magnitude = Math.random();
        let radius;
        let brightness;
        let twinkleAmount;
        let hasGlow = false;
        let hasSpikes = false;

        if (magnitude < 0.42) {
            radius = 0.55 + Math.random() * 0.55;
            brightness = 0.18 + Math.random() * 0.24;
            twinkleAmount = 0.1;
        } else if (magnitude < 0.72) {
            radius = 0.85 + Math.random() * 0.85;
            brightness = 0.38 + Math.random() * 0.3;
            twinkleAmount = 0.16;
        } else if (magnitude < 0.9) {
            radius = 1.2 + Math.random() * 1.05;
            brightness = 0.62 + Math.random() * 0.24;
            twinkleAmount = 0.22;
            hasGlow = true;
            hasSpikes = Math.random() < 0.22;
        } else {
            radius = 1.65 + Math.random() * 1.35;
            brightness = 0.82 + Math.random() * 0.18;
            twinkleAmount = 0.12;
            hasGlow = true;
            hasSpikes = Math.random() < 0.55;
        }

        const depth = magnitude >= 0.72 ? 2 : magnitude >= 0.42 ? 1 : 0;
        const driftBase = [0.02, 0.035, 0.055][depth];

        return {
            x: Math.random() * width,
            y: Math.random() * height,
            radius,
            baseBrightness: brightness,
            twinkleSpeed: 0.0014 + Math.random() * 0.004,
            twinkleOffset: Math.random() * Math.PI * 2,
            twinkleAmount,
            color: getStarColor(),
            hasGlow,
            hasSpikes,
            spikeLength: 4.2 + Math.random() * 5.2,
            vx: (Math.random() - 0.5) * 0.009,
            vy: driftBase + Math.random() * driftBase * 0.65
        };
    }

    function createMeteor() {
        const angle = (36 + Math.random() * 14) * (Math.PI / 180);
        const speed = 3.8 + Math.random() * 3.2;
        return {
            x: Math.random() * width * 0.88,
            y: Math.random() * height * 0.38,
            angle,
            speed,
            tailLength: 42 + Math.random() * 34,
            opacity: 1,
            headRadius: 0.95 + Math.random() * 0.45,
            fadeRate: 0.00042 + Math.random() * 0.00024,
            particles: []
        };
    }

    function emitMeteorParticles(meteor) {
        if (Math.random() > 0.72) return;
        meteor.particles.push({
            x: meteor.x + (Math.random() - 0.5) * 1.1,
            y: meteor.y + (Math.random() - 0.5) * 1.1,
            vx: -Math.sin(meteor.angle) * meteor.speed * 0.07 + (Math.random() - 0.5) * 0.28,
            vy: -Math.cos(meteor.angle) * meteor.speed * 0.07 + (Math.random() - 0.5) * 0.28,
            life: 0.5 + Math.random() * 0.32,
            decay: 0.02 + Math.random() * 0.014,
            radius: 0.28 + Math.random() * 0.55
        });
        if (meteor.particles.length > 22) {
            meteor.particles.splice(0, meteor.particles.length - 22);
        }
    }

    function updateMeteorParticles(meteor, delta) {
        const step = delta / 16;
        for (let i = meteor.particles.length - 1; i >= 0; i -= 1) {
            const particle = meteor.particles[i];
            particle.life -= particle.decay * step;
            particle.x += particle.vx * step;
            particle.y += particle.vy * step;
            if (particle.life <= 0) meteor.particles.splice(i, 1);
        }
    }

    function drawMeteorParticles(meteor) {
        meteor.particles.forEach((particle) => {
            const alpha = meteor.opacity * particle.life * 0.5;
            if (alpha < 0.015) return;
            const glow = ctx.createRadialGradient(
                particle.x,
                particle.y,
                0,
                particle.x,
                particle.y,
                particle.radius * 2
            );
            glow.addColorStop(0, `rgba(255, 255, 255, ${alpha})`);
            glow.addColorStop(0.45, `rgba(255, 246, 214, ${alpha * 0.42})`);
            glow.addColorStop(1, 'rgba(232, 197, 71, 0)');
            ctx.beginPath();
            ctx.arc(particle.x, particle.y, particle.radius * 2, 0, Math.PI * 2);
            ctx.fillStyle = glow;
            ctx.fill();
        });
    }

    function drawMeteor(meteor) {
        const headX = meteor.x;
        const headY = meteor.y;
        const tailX = headX - Math.sin(meteor.angle) * meteor.tailLength;
        const tailY = headY - Math.cos(meteor.angle) * meteor.tailLength;
        const alpha = meteor.opacity;

        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.lineCap = 'round';

        const haloGrad = ctx.createLinearGradient(tailX, tailY, headX, headY);
        haloGrad.addColorStop(0, 'rgba(232, 197, 71, 0)');
        haloGrad.addColorStop(0.42, `rgba(245, 228, 170, ${alpha * 0.07})`);
        haloGrad.addColorStop(0.78, `rgba(255, 248, 220, ${alpha * 0.24})`);
        haloGrad.addColorStop(1, `rgba(255, 255, 255, ${alpha * 0.82})`);
        ctx.beginPath();
        ctx.moveTo(tailX, tailY);
        ctx.lineTo(headX, headY);
        ctx.strokeStyle = haloGrad;
        ctx.lineWidth = meteor.headRadius * 2.1;
        ctx.stroke();

        const coreGrad = ctx.createLinearGradient(tailX, tailY, headX, headY);
        coreGrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
        coreGrad.addColorStop(0.58, `rgba(255, 255, 255, ${alpha * 0.32})`);
        coreGrad.addColorStop(1, `rgba(255, 255, 255, ${alpha})`);
        ctx.beginPath();
        ctx.moveTo(tailX, tailY);
        ctx.lineTo(headX, headY);
        ctx.strokeStyle = coreGrad;
        ctx.lineWidth = meteor.headRadius * 0.75;
        ctx.stroke();

        drawMeteorParticles(meteor);

        const bloom = ctx.createRadialGradient(headX, headY, 0, headX, headY, meteor.headRadius * 2.8);
        bloom.addColorStop(0, `rgba(255, 255, 255, ${alpha})`);
        bloom.addColorStop(0.22, `rgba(255, 248, 220, ${alpha * 0.58})`);
        bloom.addColorStop(1, 'rgba(232, 197, 71, 0)');
        ctx.beginPath();
        ctx.arc(headX, headY, meteor.headRadius * 2.8, 0, Math.PI * 2);
        ctx.fillStyle = bloom;
        ctx.fill();

        ctx.beginPath();
        ctx.arc(headX, headY, meteor.headRadius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.fill();

        ctx.restore();
    }

    function updateMeteors(delta) {
        const step = delta / 16;
        for (let i = meteors.length - 1; i >= 0; i -= 1) {
            const meteor = meteors[i];
            meteor.x += Math.sin(meteor.angle) * meteor.speed * step;
            meteor.y += Math.cos(meteor.angle) * meteor.speed * step;
            meteor.opacity -= meteor.fadeRate * step;
            emitMeteorParticles(meteor);
            updateMeteorParticles(meteor, delta);

            if (meteor.opacity <= 0 || meteor.x > width + 80 || meteor.y > height + 80) {
                meteors.splice(i, 1);
                continue;
            }

            drawMeteor(meteor);
        }
    }

    function populateStars() {
        const area = width * height;
        const count = Math.max(65, Math.min(210, Math.floor(area / 7800)));
        stars = Array.from({ length: count }, createStar);
    }

    function resize() {
        dpr = Math.min(window.devicePixelRatio || 1, 2);
        width = window.innerWidth;
        height = window.innerHeight;
        canvas.width = Math.max(1, Math.floor(width * dpr));
        canvas.height = Math.max(1, Math.floor(height * dpr));
        canvas.style.width = `${width}px`;
        canvas.style.height = `${height}px`;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        populateStars();
    }

    function scheduleResize() {
        window.clearTimeout(resizeTimer);
        resizeTimer = window.setTimeout(resize, 120);
    }

    function updateStars(delta) {
        if (reducedMotion) return;
        stars.forEach((star) => {
            star.x += star.vx * delta;
            star.y += star.vy * delta;
            if (star.y > height + 16) {
                star.y = -16;
                star.x = Math.random() * width;
            }
            if (star.x > width + 16) star.x = -16;
            if (star.x < -16) star.x = width + 16;
        });
    }

    function drawSpikes(star, x, y, radius, alpha) {
        const len = radius * star.spikeLength;
        const lineWidth = Math.max(0.45, radius * 0.3);
        const { r, g, b } = star.color;

        for (let i = 0; i < 4; i += 1) {
            const angle = (i * Math.PI) / 2;
            const endX = x + Math.sin(angle) * len;
            const endY = y - Math.cos(angle) * len;
            const grad = ctx.createLinearGradient(x, y, endX, endY);
            grad.addColorStop(0, `rgba(${r}, ${g}, ${b}, ${alpha * 0.88})`);
            grad.addColorStop(0.35, `rgba(${r}, ${g}, ${b}, ${alpha * 0.22})`);
            grad.addColorStop(1, `rgba(${r}, ${g}, ${b}, 0)`);
            ctx.strokeStyle = grad;
            ctx.lineWidth = lineWidth;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(endX, endY);
            ctx.stroke();
        }
    }

    function drawStar(star, timeMs) {
        let brightness = star.baseBrightness;
        if (!reducedMotion) {
            const twinkle = Math.sin(timeMs * star.twinkleSpeed + star.twinkleOffset);
            brightness = star.baseBrightness + twinkle * star.twinkleAmount * star.baseBrightness * 0.52;
        }

        let radius = star.radius;
        if (star.hasGlow && !reducedMotion) {
            radius *= Math.sin(timeMs * 0.001 + star.twinkleOffset) * 0.12 + 1;
        }

        const { r, g, b } = star.color;
        const alpha = Math.max(0.08, Math.min(1, brightness));
        const x = star.x;
        const y = star.y;

        if (star.hasGlow) {
            const glow = ctx.createRadialGradient(x, y, 0, x, y, radius * 6);
            glow.addColorStop(0, `rgba(${r}, ${g}, ${b}, ${alpha * 0.62})`);
            glow.addColorStop(0.22, `rgba(${r}, ${g}, ${b}, ${alpha * 0.2})`);
            glow.addColorStop(1, `rgba(${r}, ${g}, ${b}, 0)`);
            ctx.beginPath();
            ctx.arc(x, y, radius * 6, 0, Math.PI * 2);
            ctx.fillStyle = glow;
            ctx.fill();
        }

        if (star.hasSpikes) drawSpikes(star, x, y, radius, alpha);

        ctx.beginPath();
        ctx.arc(x, y, Math.max(0.45, radius), 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`;
        ctx.fill();
    }

    function drawBackground() {
        const grad = ctx.createLinearGradient(0, 0, 0, height);
        grad.addColorStop(0, '#0a0a0a');
        grad.addColorStop(0.45, '#080808');
        grad.addColorStop(1, '#060606');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        const glow = ctx.createRadialGradient(width * 0.5, height * 0.08, 0, width * 0.5, height * 0.08, width * 0.65);
        glow.addColorStop(0, 'rgba(201, 162, 39, 0.1)');
        glow.addColorStop(1, 'rgba(201, 162, 39, 0)');
        ctx.fillStyle = glow;
        ctx.fillRect(0, 0, width, height);
    }

    function tick(timeMs) {
        const delta = lastTime ? Math.min(32, timeMs - lastTime) : 16;
        lastTime = timeMs;

        if (!reducedMotion && timeMs >= nextMeteorAt) {
            meteors.push(createMeteor());
            nextMeteorAt = timeMs + 5000 + Math.random() * 5000;
        }

        updateStars(delta);
        drawBackground();
        stars.forEach((star) => drawStar(star, timeMs));
        if (!reducedMotion) updateMeteors(delta);

        rafId = window.requestAnimationFrame(tick);
    }

    resize();
    nextMeteorAt = performance.now() + 4000;
    window.addEventListener('resize', scheduleResize);
    rafId = window.requestAnimationFrame(tick);

    window.addEventListener('pagehide', () => {
        if (rafId) window.cancelAnimationFrame(rafId);
    });
})();
