(function () {
    const grid = document.getElementById('gamesGrid');
    if (!grid) return;

    const canvas = grid.querySelector('.frame-grid-smoke-canvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const MAX_PARTICLES = 220;
    const MOTION = 3.2;
    const themeRoot = document.documentElement;

    function themeVar(name, fallback) {
        const value = getComputedStyle(themeRoot).getPropertyValue(name).trim();
        return value || fallback;
    }

    function parseRgbTriplet(value) {
        const parts = value.split(',').map(function (part) {
            return parseInt(part.trim(), 10);
        });
        return { r: parts[0] || 0, g: parts[1] || 0, b: parts[2] || 0 };
    }

    function buildPalette() {
        return [
            themeVar('--games-smoke-p0', '62, 205, 95'),
            themeVar('--games-smoke-p1', '78, 228, 118'),
            themeVar('--games-smoke-p2', '50, 185, 78'),
            themeVar('--games-smoke-p3', '92, 242, 132'),
            themeVar('--games-smoke-p4', '42, 170, 68'),
            themeVar('--games-smoke-p5', '68, 218, 108')
        ].map(parseRgbTriplet);
    }

    let palette = buildPalette();
    let w = 0;
    let h = 0;
    let rafId = null;
    let ready = false;
    const particles = [];

    function randomFromPalette() {
        return palette[Math.floor(Math.random() * palette.length)];
    }

    function Particle() {
        this.reset();
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.random() * 120;
        this.x = w / 2 + Math.cos(angle) * dist;
        this.y = h / 2 + Math.sin(angle) * dist * 0.6;
        this.size = 2 + Math.random() * 6;
        this.speed = 0.3 + Math.random() * 0.6;
        this.driftX = (Math.random() - 0.5) * 0.3;
        this.driftY = -(0.2 + Math.random() * 0.5);
        this.life = 1.0;
        this.decay = 0.0025 + Math.random() * 0.004;
        const col = randomFromPalette();
        this.r = col.r;
        this.g = col.g;
        this.b = col.b;
        this.alpha = 0.4 + Math.random() * 0.38;
        this.wobble = Math.random() * 100;
        this.wobbleSpeed = 0.01 + Math.random() * 0.02;
        this.wobbleAmp = 0.2 + Math.random() * 0.6;
    }

    Particle.prototype.reset = function () {
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.random() * 80;
        this.x = w / 2 + Math.cos(angle) * dist;
        this.y = h / 2 + Math.sin(angle) * dist * 0.5 - 20;
        this.size = 2 + Math.random() * 8;
        this.speed = 0.3 + Math.random() * 0.7;
        this.driftX = (Math.random() - 0.5) * 0.4;
        this.driftY = -(0.2 + Math.random() * 0.6);
        this.life = 0.7 + Math.random() * 0.3;
        this.decay = 0.002 + Math.random() * 0.004;
        const col = randomFromPalette();
        this.r = col.r;
        this.g = col.g;
        this.b = col.b;
        this.alpha = 0.34 + Math.random() * 0.44;
        this.wobble = Math.random() * 100;
        this.wobbleSpeed = 0.01 + Math.random() * 0.025;
        this.wobbleAmp = 0.2 + Math.random() * 0.8;
    };

    Particle.prototype.update = function () {
        this.wobble += this.wobbleSpeed * MOTION;
        const wobX = Math.sin(this.wobble) * this.wobbleAmp;
        this.x += (this.driftX + wobX * 0.15) * MOTION;
        this.y += this.driftY * this.speed * MOTION;
        this.size += 0.008 * MOTION;
        this.life -= this.decay;
        this.alpha = Math.min(this.alpha + 0.001, 0.8);
        if (this.life <= 0 || this.y < -50 || this.x < -50 || this.x > w + 50 || this.y > h + 50) {
            this.reset();
            this.y = h * 0.7 + Math.random() * h * 0.3;
            this.x = w / 2 + (Math.random() - 0.5) * w * 0.6;
            this.life = 0.8 + Math.random() * 0.2;
        }
    };

    Particle.prototype.draw = function () {
        const alpha = this.life * this.alpha * 0.92;
        const radius = this.size * (0.5 + this.life * 0.5);
        const grad = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, radius);
        grad.addColorStop(0, 'rgba(' + this.r + ', ' + this.g + ', ' + this.b + ', ' + (alpha * 0.9) + ')');
        grad.addColorStop(0.4, 'rgba(' + this.r + ', ' + this.g + ', ' + this.b + ', ' + (alpha * 0.6) + ')');
        grad.addColorStop(1, 'rgba(' + this.r + ', ' + this.g + ', ' + this.b + ', 0)');
        ctx.beginPath();
        ctx.arc(this.x, this.y, radius, 0, Math.PI * 2);
        ctx.fillStyle = grad;
        ctx.fill();
        if (this.life > 0.6 && this.size > 3) {
            ctx.beginPath();
            ctx.arc(this.x, this.y, radius * 0.2, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(' + Math.min(this.r + 60, 255) + ', ' + Math.min(this.g + 30, 255) + ', ' + Math.min(this.b + 30, 255) + ', ' + (alpha * 0.2) + ')';
            ctx.fill();
        }
    };

    function drawBackground() {
        const grad = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w * 0.7);
        grad.addColorStop(0, themeVar('--games-smoke-bg-center', '#1a5028'));
        grad.addColorStop(0.35, themeVar('--games-smoke-bg-mid', '#123820'));
        grad.addColorStop(0.7, themeVar('--games-smoke-bg-deep', '#0a2818'));
        grad.addColorStop(1, themeVar('--games-smoke-bg-edge', '#101210'));
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
    }

    function drawGlow() {
        const glowA = parseRgbTriplet(themeVar('--games-smoke-glow-a', '72, 225, 115'));
        const glowB = parseRgbTriplet(themeVar('--games-smoke-glow-b', '48, 185, 88'));
        ctx.globalCompositeOperation = 'screen';
        const glow = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w * 0.5);
        glow.addColorStop(0, 'rgba(' + glowA.r + ', ' + glowA.g + ', ' + glowA.b + ', 0.19)');
        glow.addColorStop(0.5, 'rgba(' + glowB.r + ', ' + glowB.g + ', ' + glowB.b + ', 0.11)');
        glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = glow;
        ctx.fillRect(0, 0, w, h);
        ctx.globalCompositeOperation = 'source-over';
    }

    function resize() {
        const rect = grid.getBoundingClientRect();
        if (rect.width < 20 || rect.height < 20) {
            ready = false;
            return false;
        }
        w = canvas.width = Math.floor(rect.width);
        h = canvas.height = Math.floor(rect.height);
        canvas.style.width = w + 'px';
        canvas.style.height = h + 'px';
        ready = true;
        return true;
    }

    function initParticles() {
        palette = buildPalette();
        particles.length = 0;
        for (let i = 0; i < MAX_PARTICLES; i += 1) {
            const p = new Particle();
            p.x = Math.random() * w;
            p.y = Math.random() * h;
            p.life = Math.random() * 0.8 + 0.2;
            p.size = 2 + Math.random() * 10;
            particles.push(p);
        }
    }

    function clampParticles() {
        particles.forEach(function (p) {
            p.x = Math.min(Math.max(p.x, 0), w);
            p.y = Math.min(Math.max(p.y, 0), h);
        });
    }

    function frame() {
        drawBackground();
        particles.forEach(function (p) {
            p.update();
            p.draw();
        });
        drawGlow();
    }

    function animate() {
        if (!ready) {
            if (resize()) initParticles();
            rafId = requestAnimationFrame(animate);
            return;
        }
        frame();
        rafId = requestAnimationFrame(animate);
    }

    function start() {
        if (resize()) initParticles();
        if (rafId) cancelAnimationFrame(rafId);
        if (reducedMotion) {
            frame();
            return;
        }
        rafId = requestAnimationFrame(animate);
    }

    function stop() {
        if (rafId) {
            cancelAnimationFrame(rafId);
            rafId = null;
        }
    }

    if (typeof ResizeObserver !== 'undefined') {
        const observer = new ResizeObserver(function () {
            if (resize()) clampParticles();
        });
        observer.observe(grid);
    } else {
        window.addEventListener('resize', function () {
            if (resize()) clampParticles();
        });
    }

    window.addEventListener('iqwin-games-rendered', function () {
        if (resize()) clampParticles();
    });

    document.addEventListener('visibilitychange', function () {
        if (document.hidden) stop();
        else start();
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }
})();
