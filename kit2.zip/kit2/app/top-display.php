<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>IQWIN — Ecran superior</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../games/shared/terminal-info-pages.css?v=<?php echo (int)@filemtime(__DIR__ . '/../games/shared/terminal-info-pages.css'); ?>">
    <link rel="stylesheet" href="css/top-display.css?v=<?php echo (int)@filemtime(__DIR__ . '/css/top-display.css'); ?>">
</head>
<body class="top-display-body">
<div class="top-display-stage">
    <section class="top-idle" id="topIdle" aria-label="IQWIN">
        <div class="top-idle__bg" aria-hidden="true">
            <div class="top-idle__veil"></div>
            <div class="top-idle__arc top-idle__arc--top"></div>
            <div class="top-idle__arc top-idle__arc--bottom"></div>
            <div class="top-idle__sparkles" id="topIdleSparkles" aria-hidden="true"></div>
            <div class="top-idle__floor-glow"></div>
        </div>
        <div class="top-idle__site">www.iqwin.eu <span class="top-idle__site-ver">(V-1.0.0.3.9)</span></div>

        <div class="top-idle__words">
            <div class="top-idle__words-band" id="topIdleFloatLayer" aria-hidden="true"></div>
        </div>

        <header class="top-idle__brand">
            <img class="top-idle__logo" src="../images/logo.webp?v=4" alt="IQWIN — Skill Beats Luck" width="994" height="184" decoding="async">
        </header>

        <footer class="top-idle__footer">
            <strong class="top-idle__mp-title">MULTIPLAYER</strong>
        </footer>
    </section>

    <section class="top-idle-video is-hidden" id="topIdleVideo" aria-label="Video promotional IQWIN">
        <video class="top-idle-video__player" id="topIdleVideoPlayer" playsinline preload="auto"></video>
    </section>

    <section class="top-display-info is-hidden" id="topDisplayInfo" aria-live="polite">
        <header class="top-display-info__header">
            <h1 class="top-display-info__title" id="topDisplayGameTitle"></h1>
        </header>
        <aside class="terminal-info-pages top-display-info__pages" aria-label="Informatii joc">
            <div class="terminal-info-pages__viewport">
                <div class="terminal-info-pages__track" id="topDisplayTrack"></div>
            </div>
            <footer class="terminal-info-pages__footer">
                <div class="terminal-info-pages__pager" id="topDisplayPager">Pagina 1/1</div>
            </footer>
        </aside>
    </section>

    <section class="mp-contest is-hidden" id="mpContest" aria-live="polite">
        <div class="mp-contest__bg" aria-hidden="true">
            <div class="mp-bg-veil"></div>
            <div class="mp-bg-ribbons">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="mp-bg-mesh"></div>
            <div class="mp-bg-sheen"></div>
        </div>
        <header class="mp-contest__top">
            <div class="mp-contest__top-bg" aria-hidden="true">
                <span class="mp-contest__top-shimmer"></span>
            </div>
            <div class="mp-contest__badge" id="mpBadge">CONCURS BLITZ</div>
            <img class="mp-contest__logo" src="../images/logo2.webp?v=<?php echo (int)@filemtime(__DIR__ . '/../images/logo2.webp'); ?>" alt="IQWIN — Skill beats luck" width="994" height="184" decoding="async">
            <div class="mp-contest__site">www.iqwin.eu</div>
        </header>

        <div class="mp-contest__body">
            <div class="mp-contest__main">
                <div class="mp-contest__hero">
                    <p class="mp-contest__kicker">CONCURS</p>
                    <h1 class="mp-contest__title">CONCUREAZĂ ȘI CÂȘTIGĂ!</h1>
                    <div class="mp-contest__prize" id="mpPrizeBox">
                        <span id="mpPrizeKicker">TIMP RĂMAS</span>
                        <strong id="mpPrizeValue">05:00</strong>
                    </div>
                    <p class="mp-contest__prize-note" id="mpPrizeNote">CONCURS BLITZ — 50 SPINURI × 1 LEU</p>
                </div>
                <ol class="mp-contest__board" id="mpBoard"></ol>
            </div>
            <aside class="mp-contest__side">
                <div class="mp-contest__side-card">
                    <span class="mp-contest__side-label">INTRARE CONCURS</span>
                    <strong id="mpSidePct">100 LEI</strong>
                    <em>50% PREMIU BLITZ · 50% SPINURI</em>
                </div>
                <div class="mp-contest__side-card mp-contest__side-card--rules">
                    <h2>CUM FUNCȚIONEAZĂ?</h2>
                    <ul id="mpRules"></ul>
                    <div class="mp-contest__blitz" id="mpBlitz" aria-live="polite">
                        <div class="mp-contest__blitz-ring" aria-hidden="true">
                            <span class="mp-contest__blitz-ring-halo"></span>
                            <span class="mp-contest__blitz-ring-outer"></span>
                            <div class="mp-contest__blitz-ring-spin">
                                <span class="mp-contest__blitz-ring-dash"></span>
                                <i class="mp-contest__blitz-ring-mark mp-contest__blitz-ring-mark--n"></i>
                                <i class="mp-contest__blitz-ring-mark mp-contest__blitz-ring-mark--e"></i>
                                <i class="mp-contest__blitz-ring-mark mp-contest__blitz-ring-mark--s"></i>
                                <i class="mp-contest__blitz-ring-mark mp-contest__blitz-ring-mark--w"></i>
                            </div>
                        </div>
                        <div class="mp-contest__blitz-core">
                            <em>PREMIU BLITZ</em>
                            <strong id="mpBlitzValue">0,00</strong>
                            <span class="mp-contest__blitz-unit">LEI</span>
                        </div>
                    </div>
                </div>
            </aside>
        </div>

        <footer class="mp-contest__footer">
            <div class="mp-contest__progress-head">
                <span id="mpProgressLabel">PROGRES TOTAL CONCURS 0%</span>
            </div>
            <div class="mp-contest__progress-track" aria-hidden="true">
                <div class="mp-contest__progress-fill" id="mpProgressFill"></div>
            </div>
            <p class="mp-contest__remaining" id="mpRemaining">MAI RĂMÂN: 0,00 LEI PÂNĂ LA ATINGEREA PREMIULUI</p>
        </footer>

        <div class="mp-contest__win is-hidden" id="mpWinBanner" role="status" aria-live="assertive">
            <div class="mp-win__backdrop" aria-hidden="true"></div>
            <div class="mp-win__fx" aria-hidden="true">
                <span class="mp-win__burst"></span>
                <span class="mp-win__burst mp-win__burst--b"></span>
                <span class="mp-win__burst mp-win__burst--c"></span>
                <i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>
                <i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>
            </div>
            <div class="mp-win__card">
                <p class="mp-win__kicker">PREMIU MULTIPLAYER</p>
                <h2 class="mp-win__title">CÂȘTIGĂTOR BLITZ</h2>
                <p class="mp-win__terminal" id="mpWinTerminal">TERMINAL</p>
                <p class="mp-win__prize" id="mpWinPrize">0 LEI</p>
                <p class="mp-win__sub" id="mpWinText">Felicitări! Premiul a fost acordat.</p>
            </div>
        </div>
    </section>
</div>
<script src="../games/shared/terminal-info-pages-content.js?v=<?php echo (int)@filemtime(__DIR__ . '/../games/shared/terminal-info-pages-content.js'); ?>"></script>
<script src="js/top-display.js?v=<?php echo (int)@filemtime(__DIR__ . '/js/top-display.js'); ?>"></script>
</body>
</html>
