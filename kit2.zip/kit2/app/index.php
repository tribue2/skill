<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Iqwin Games Terminal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/terminal.css?v=<?php echo (int)@filemtime(__DIR__ . '/css/terminal.css'); ?>">
</head>
<body class="kiosk-body">
<svg aria-hidden="true" style="position:absolute;width:0;height:0;">
    <defs>
        <clipPath id="terminal-notch-clip" clipPathUnits="objectBoundingBox">
            <path fill="black" d="M 0,0 L 0.27,0 Q 0.31,0.32 0.35,0.32 L 0.65,0.32 Q 0.69,0.32 0.73,0 L 1,0 L 1,1 L 0,1 Z"/>
        </clipPath>
    </defs>
</svg>
<div class="kiosk-stage">
    <div class="terminal-frame">
        <div class="frame-head">
            <div class="frame-head-bg" aria-hidden="true">
                <span class="frame-head-gradient"></span>
                <span class="frame-head-mesh"></span>
                <span class="frame-head-shimmer"></span>
                <span class="frame-head-led frame-head-led-top"></span>
                <span class="frame-head-led frame-head-led-bottom"></span>
                <div class="frame-head-symbols" aria-hidden="true">
                    <img class="frame-head-symbol frame-head-symbol--s1" src="images/slot-symbols/7.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s2" src="images/slot-symbols/cireasa.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s3" src="images/slot-symbols/portocala.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s4" src="images/slot-symbols/lamaie.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s5" src="images/slot-symbols/strugure.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s6" src="images/slot-symbols/pepene.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s7" src="images/slot-symbols/7.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s8" src="images/slot-symbols/cireasa.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s9" src="images/slot-symbols/portocala.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s10" src="images/slot-symbols/lamaie.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s11" src="images/slot-symbols/strugure.webp" alt="" decoding="async">
                    <img class="frame-head-symbol frame-head-symbol--s12" src="images/slot-symbols/pepene.webp" alt="" decoding="async">
                </div>
            </div>
            <div class="kiosk-brand" aria-label="IQWIN">
                <img class="kiosk-brand-logo" src="../images/logo.webp?v=4" alt="IQWIN" width="994" height="184" decoding="async">
            </div>
        </div>

        <div class="frame-meta">
            <span class="frame-meta-left">
                <span class="status-dot" id="statusDot"></span>
                <span id="terminalName">Terminal</span>
            </span>
            <div class="frame-marquee" id="terminalMarquee" hidden aria-live="polite">
                <div class="frame-marquee-shell">
                    <span class="frame-marquee-led frame-marquee-led-left" aria-hidden="true"></span>
                    <div class="frame-marquee-viewport" id="terminalMarqueeViewport"></div>
                    <span class="frame-marquee-led frame-marquee-led-right" aria-hidden="true"></span>
                </div>
            </div>
        </div>

        <div class="terminal-stacker-alert" id="terminalStackerAlert" hidden role="status" aria-live="polite">
            <strong id="terminalStackerAlertTitle">Receptor</strong>
            <span id="terminalStackerAlertText"></span>
        </div>

        <div class="frame-grid" id="gamesGrid">
            <div class="frame-grid-loader" id="gameGridLoader" hidden aria-live="polite" aria-busy="true">
                <div class="frame-grid-spinner" aria-hidden="true">
                    <i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>
                </div>
            </div>
        </div>

        <div class="terminal-bottom-bar-wrap">
            <div class="terminal-bottom-bar">
                <svg class="terminal-notch-stroke" viewBox="0 0 1 1" preserveAspectRatio="none" aria-hidden="true">
                    <path fill="none" stroke="#c9a227" stroke-width="0.004" stroke-linecap="round" stroke-linejoin="round" d="M 0.27,0 Q 0.31,0.32 0.35,0.32 L 0.65,0.32 Q 0.69,0.32 0.73,0"/>
                </svg>
                <div class="terminal-bottom-row">
                    <div class="terminal-foot-box">
                        <span class="terminal-foot-box-label">Sold</span>
                        <div class="terminal-foot-box-credits">
                            <strong class="terminal-foot-box-value" id="creditsValue">0,00</strong>
                            <span class="terminal-foot-box-lei" id="creditsLeiValue">(0,00 lei)</span>
                        </div>
                    </div>
                    <div class="terminal-foot-center">
                        <p class="terminal-foot-skill-tagline">Jocuri bazate pe <strong>SKILL</strong> – nu pe noroc</p>
                    </div>
                    <div class="terminal-foot-right">
                        <div class="terminal-foot-box terminal-foot-clock" id="terminalClock" aria-live="polite">
                            <span class="frame-foot-clock-time" id="terminalClockTime">00:00:00</span>
                            <span class="frame-foot-clock-sep" aria-hidden="true"></span>
                            <span class="frame-foot-clock-date-wrap">
                                <span class="frame-foot-clock-date-main" id="terminalClockDateMain">---</span>
                                <span class="frame-foot-clock-date-sub" id="terminalClockDateSub">---</span>
                            </span>
                        </div>
                        <p class="terminal-foot-partner">
                            Vrei și tu să fii partener? Trimite un e-mail la:
                            <a href="mailto:office@iqwin.eu">office@iqwin.eu</a>.
                        </p>
                    </div>
                </div>
            </div>
            <div class="terminal-extra-menu-bar">
                <div class="terminal-extra-menu-inner">
                    <div class="terminal-extra-menu-side terminal-extra-menu-left">
                        <div class="frame-credits-bar">
                            <button type="button" class="credit-action credit-in" id="creditInBtn" aria-label="Sold In">
                                <i class="fas fa-circle-down" aria-hidden="true"></i>
                                <span>SOLD IN</span>
                            </button>
                            <button type="button" class="credit-action credit-out" id="creditOutBtn" aria-label="Sold Out">
                                <span>Sold Out</span>
                                <i class="fas fa-circle-up" aria-hidden="true"></i>
                            </button>
                        </div>
                    </div>
                    <div class="terminal-extra-menu-center">
                        <button type="button" class="terminal-multiplayer-btn" id="multiplayerBtn" hidden aria-label="Porneste Multiplayer">
                            <i class="fas fa-users" aria-hidden="true"></i>
                            <span id="multiplayerBtnLabel">MULTIPLAYER</span>
                        </button>
                        <button type="button" class="terminal-extra-menu-btn terminal-extra-menu-btn-home" id="terminalHomeBtn" aria-label="Acasa">
                            <svg class="terminal-extra-menu-icon" viewBox="0 0 24 24" aria-hidden="true">
                                <path fill="currentColor" d="M12 3L2 12h2v9h6v-6h4v6h6v-9h2L12 3z"/>
                            </svg>
                        </button>
                        <button type="button" class="terminal-extra-menu-btn terminal-extra-menu-btn-sound" id="terminalSoundBtn" aria-label="Sunet pornit">
                            <svg class="terminal-extra-menu-icon terminal-extra-menu-icon-sound-on" viewBox="0 0 24 24" aria-hidden="true">
                                <path fill="currentColor" d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>
                            </svg>
                            <svg class="terminal-extra-menu-icon terminal-extra-menu-icon-sound-off" viewBox="0 0 24 24" aria-hidden="true" hidden>
                                <path fill="currentColor" d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>
                            </svg>
                        </button>
                    </div>
                    <div class="terminal-extra-menu-side terminal-extra-menu-right">
                        <button type="button" class="terminal-extra-menu-btn terminal-extra-menu-btn-connect" id="terminalConnectBtn" aria-label="Conectare aparat">
                            <svg class="terminal-extra-menu-icon" viewBox="0 0 24 24" aria-hidden="true">
                                <path fill="currentColor" d="M8 2h8a2 2 0 0 1 2 2v1H6V4a2 2 0 0 1 2-2zm-2 4h12v11a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V6zm2 2v7h8V8H8zm1 10h6v2H9v-2z"/>
                                <path fill="currentColor" d="M10 10h1.5v1.5H10V10zm2.5 0H14v1.5h-1.5V10zm-2.5 2.5h1.5V14H10v-1.5zm2.5 0H14V14h-1.5v-1.5z" opacity="0.85"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
            <span class="terminal-select-game-text">Selectează joc</span>
        </div>
    </div>
</div>

<div class="credit-modal" id="mpEntryModal" hidden>
    <div class="credit-modal-panel mp-entry-panel" role="dialog" aria-labelledby="mpEntryTitle" aria-modal="true">
        <div class="mp-entry-hero">
            <div class="mp-entry-hero-icon" aria-hidden="true">
                <i class="fa-solid fa-bolt"></i>
            </div>
            <h2 class="credit-modal-title mp-entry-title" id="mpEntryTitle">Deschide Concurs Blitz</h2>
            <p class="credit-modal-sub mp-entry-sub" id="mpEntrySub">Alege varianta de intrare. Jumatate merge la premiul Blitz, jumatate la cele 50 de spinuri.</p>
        </div>
        <div class="mp-entry-tiers" id="mpEntryGrid"></div>
        <div class="mp-entry-win-info">
            <span class="mp-entry-win-icon" aria-hidden="true"><i class="fa-solid fa-shield-check"></i></span>
            <p id="mpEntryWinInfo">Daca castigi, primesti premiul Blitz plus castigurile acumulate din cele 50 spinuri pe soldul normal.</p>
        </div>
        <button type="button" class="mp-entry-cancel-btn" id="mpEntryCancelBtn">Anuleaza</button>
    </div>
</div>

<div class="credit-modal" id="mpJoinConfirmModal" hidden>
    <div class="credit-modal-panel mp-entry-panel mp-join-panel" role="dialog" aria-labelledby="mpJoinTitle" aria-modal="true">
        <div class="mp-entry-hero">
            <div class="mp-entry-hero-icon" aria-hidden="true">
                <i class="fa-solid fa-bolt"></i>
            </div>
            <h2 class="credit-modal-title mp-entry-title" id="mpJoinTitle">Intrare Concurs Blitz</h2>
            <p class="credit-modal-sub mp-entry-sub mp-join-question" id="mpJoinQuestion">Accepti sa intri in concursul Blitz?</p>
        </div>
        <div class="mp-join-details" id="mpJoinDetails"></div>
        <div class="mp-entry-win-info mp-join-win-info">
            <span class="mp-entry-win-icon" aria-hidden="true"><i class="fa-solid fa-shield-check"></i></span>
            <p id="mpJoinWinInfo">Daca castigi, primesti premiul Blitz plus castigurile acumulate din cele 50 spinuri pe soldul normal.</p>
        </div>
        <div class="mp-join-actions">
            <button type="button" class="mp-entry-cancel-btn mp-join-confirm" id="mpJoinConfirmBtn">Da, accept si intru</button>
            <button type="button" class="mp-join-decline-btn" id="mpJoinCancelBtn">Nu, anulez</button>
        </div>
    </div>
</div>

<div class="credit-modal" id="creditInModal" hidden>
    <div class="credit-modal-panel" role="dialog" aria-labelledby="creditInTitle" aria-modal="true">
        <h2 class="credit-modal-title" id="creditInTitle">Introducere bani</h2>
                        <p class="credit-modal-sub" id="creditInHint">IN manual sau ITL Bridge pe PC. 1 RON = 1 LEI pe sold.</p>
        <div class="credit-quick-grid" id="creditQuickGrid"></div>
        <div class="credit-custom-row">
            <input type="number" id="creditCustomAmount" min="1" step="1" inputmode="numeric" placeholder="Alta suma (RON)">
            <button type="button" class="credit-custom-btn" id="creditCustomBtn">Adauga</button>
        </div>
        <button type="button" class="credit-modal-cancel" id="creditInCancelBtn">Anuleaza</button>
    </div>
</div>

<div class="credit-modal" id="creditOutModal" hidden>
    <div class="credit-modal-panel credit-out-modal-panel" role="dialog" aria-labelledby="creditOutTitle" aria-modal="true">
        <h2 class="credit-modal-title" id="creditOutTitle">Retragere bani</h2>
        <p class="credit-modal-sub" id="creditOutSub">Alege suma de retras.</p>
        <div class="credit-out-amount-grid" id="creditOutAmountGrid"></div>
        <p class="credit-out-tax-notice" id="creditOutTaxNotice" hidden></p>
        <p class="credit-out-summary" id="creditOutSummary"></p>
        <div class="credit-modal-actions">
            <button type="button" class="credit-modal-cancel" id="creditOutCancelBtn">Anuleaza</button>
            <button type="button" class="credit-modal-confirm credit-out-confirm" id="creditOutConfirmBtn">Confirma OUT</button>
        </div>
    </div>
</div>

<div class="credit-modal forced-withdraw-modal" id="forcedWithdrawModal" hidden>
    <div class="credit-modal-panel credit-out-modal-panel forced-withdraw-panel" role="dialog" aria-labelledby="forcedWithdrawTitle" aria-modal="true">
        <h2 class="credit-modal-title" id="forcedWithdrawTitle">Retragere obligatorie</h2>
        <p class="credit-modal-sub" id="forcedWithdrawSub">Soldul depaseste plafonul de 1.000 LEI. Alege suma de retras.</p>
        <div class="credit-out-amount-grid" id="forcedWithdrawAmountGrid"></div>
        <p class="credit-out-tax-notice" id="forcedWithdrawTaxNotice" hidden></p>
        <p class="credit-out-summary" id="forcedWithdrawSummary"></p>
        <div class="credit-modal-actions forced-withdraw-actions">
            <button type="button" class="credit-modal-confirm credit-out-confirm" id="forcedWithdrawConfirmBtn">Confirma retragerea</button>
        </div>
    </div>
</div>

<div class="credit-modal credit-out-result-modal" id="creditOutResultModal" hidden>
    <div class="credit-modal-panel credit-out-result-panel" role="dialog" aria-labelledby="creditOutResultTitle" aria-modal="true">
        <div class="credit-out-result-icon" id="creditOutResultIcon" aria-hidden="true">
            <i class="fa-solid fa-circle-check"></i>
        </div>
        <h2 class="credit-modal-title" id="creditOutResultTitle">Retragere efectuata</h2>
        <p class="credit-modal-sub credit-out-result-sub" id="creditOutResultSub">Suma a fost eliberata cu succes.</p>
        <div class="credit-out-result-amount" id="creditOutResultAmount" hidden></div>
        <p class="credit-out-result-balance" id="creditOutResultBalance" hidden></p>
        <p class="credit-out-result-note" id="creditOutResultNote" hidden></p>
        <button type="button" class="credit-modal-confirm credit-out-confirm credit-out-result-ok" id="creditOutResultOkBtn">OK</button>
    </div>
</div>

<div class="game-overlay" id="gameOverlay">
    <div class="game-overlay-bar">
        <strong id="overlayTitle">Joc</strong>
        <button type="button" class="overlay-btn" id="closeGameBtn">Inapoi</button>
    </div>
    <iframe id="gameFrame" title="Joc skill"></iframe>
</div>

<div class="terminal-operator-overlay" id="terminalOperatorOverlay" aria-hidden="true">
    <div class="terminal-operator-popup-wrap">
        <div class="terminal-operator-popup" role="dialog" aria-modal="true" aria-labelledby="terminalOperatorTitle">
            <div class="terminal-operator-popup-head">
                <button type="button" class="terminal-operator-close" id="terminalOperatorCloseBtn" aria-label="Inchide">&times;</button>
            </div>
            <div class="terminal-operator-terminal-card">
                <span class="terminal-operator-card-label">Terminal conectat</span>
                <strong class="terminal-operator-terminal-name" id="operatorTerminalName">Terminal</strong>
                <span class="terminal-operator-terminal-code" id="operatorTerminalCode">---</span>
                <span class="terminal-operator-station-name" id="operatorStationName"></span>
            </div>
            <h2 class="terminal-operator-title" id="terminalOperatorTitle">Autentificare operator</h2>
            <p class="terminal-operator-sub">Introdu utilizatorul și parola contului cu acces la acest terminal.</p>
            <form class="terminal-operator-form" id="terminalOperatorForm" autocomplete="off" data-lpignore="true" data-form-type="other">
                <div class="terminal-operator-field">
                    <label for="operatorUsername">Utilizator</label>
                    <input type="text" id="operatorUsername" name="iq_ident" required autocomplete="off" autocapitalize="none" autocorrect="off" spellcheck="false" inputmode="none" readonly maxlength="80" data-lpignore="true" data-1p-ignore="true" data-form-type="other">
                </div>
                <div class="terminal-operator-field">
                    <label for="operatorPassword">Parolă</label>
                    <input type="text" id="operatorPassword" name="iq_code" required autocomplete="off" autocapitalize="none" autocorrect="off" spellcheck="false" inputmode="none" readonly maxlength="64" data-iq-mask data-lpignore="true" data-1p-ignore="true" data-form-type="other">
                </div>
                <p class="terminal-operator-error" id="terminalOperatorError" role="alert" hidden></p>
                <button type="submit" class="terminal-operator-submit">Conectare</button>
            </form>
        </div>
        <div class="terminal-operator-numpad-wrap">
            <div class="terminal-operator-letters" id="terminalOperatorLetters" aria-hidden="true">
                <button type="button" class="terminal-numpad-btn" data-key="q">Q</button>
                <button type="button" class="terminal-numpad-btn" data-key="w">W</button>
                <button type="button" class="terminal-numpad-btn" data-key="e">E</button>
                <button type="button" class="terminal-numpad-btn" data-key="r">R</button>
                <button type="button" class="terminal-numpad-btn" data-key="t">T</button>
                <button type="button" class="terminal-numpad-btn" data-key="y">Y</button>
                <button type="button" class="terminal-numpad-btn" data-key="u">U</button>
                <button type="button" class="terminal-numpad-btn" data-key="i">I</button>
                <button type="button" class="terminal-numpad-btn" data-key="o">O</button>
                <button type="button" class="terminal-numpad-btn" data-key="p">P</button>
                <button type="button" class="terminal-numpad-btn" data-key="a">A</button>
                <button type="button" class="terminal-numpad-btn" data-key="s">S</button>
                <button type="button" class="terminal-numpad-btn" data-key="d">D</button>
                <button type="button" class="terminal-numpad-btn" data-key="f">F</button>
                <button type="button" class="terminal-numpad-btn" data-key="g">G</button>
                <button type="button" class="terminal-numpad-btn" data-key="h">H</button>
                <button type="button" class="terminal-numpad-btn" data-key="j">J</button>
                <button type="button" class="terminal-numpad-btn" data-key="k">K</button>
                <button type="button" class="terminal-numpad-btn" data-key="l">L</button>
                <button type="button" class="terminal-numpad-btn" data-key="z">Z</button>
                <button type="button" class="terminal-numpad-btn" data-key="x">X</button>
                <button type="button" class="terminal-numpad-btn" data-key="c">C</button>
                <button type="button" class="terminal-numpad-btn" data-key="v">V</button>
                <button type="button" class="terminal-numpad-btn" data-key="b">B</button>
                <button type="button" class="terminal-numpad-btn" data-key="n">N</button>
                <button type="button" class="terminal-numpad-btn" data-key="m">M</button>
                <button type="button" class="terminal-numpad-btn terminal-numpad-shift" data-key="shift" aria-pressed="false">ABC</button>
                <button type="button" class="terminal-numpad-btn" data-key="-">-</button>
                <button type="button" class="terminal-numpad-btn" data-key="_">_</button>
                <button type="button" class="terminal-numpad-btn" data-key=".">.</button>
            </div>
            <div class="terminal-operator-numpad" id="terminalOperatorNumpad" aria-hidden="true">
                <button type="button" class="terminal-numpad-btn" data-digit="1">1</button>
                <button type="button" class="terminal-numpad-btn" data-digit="2">2</button>
                <button type="button" class="terminal-numpad-btn" data-digit="3">3</button>
                <button type="button" class="terminal-numpad-btn" data-digit="4">4</button>
                <button type="button" class="terminal-numpad-btn" data-digit="5">5</button>
                <button type="button" class="terminal-numpad-btn" data-digit="6">6</button>
                <button type="button" class="terminal-numpad-btn" data-digit="7">7</button>
                <button type="button" class="terminal-numpad-btn" data-digit="8">8</button>
                <button type="button" class="terminal-numpad-btn" data-digit="9">9</button>
                <button type="button" class="terminal-numpad-btn" data-digit="0">0</button>
                <button type="button" class="terminal-numpad-btn terminal-numpad-backspace" data-digit="backspace" aria-label="Sterge">&#9003;</button>
            </div>
        </div>
    </div>
</div>

<div class="terminal-operator-overlay terminal-report-overlay" id="terminalReportOverlay" aria-hidden="true">
    <div class="terminal-report-popup" role="dialog" aria-modal="true" aria-labelledby="terminalReportTitle">
        <div class="terminal-report-head">
            <div class="terminal-report-head-main">
                <h2 class="terminal-report-title" id="terminalReportTitle">Situația financiară</h2>
                <p class="terminal-report-meta" id="terminalReportMeta"></p>
            </div>
            <div class="terminal-report-head-actions">
                <button type="button" class="terminal-report-action-btn" id="terminalStackerResetBtn">
                    <i class="fas fa-box-open" aria-hidden="true"></i>
                    <span>Receptor golit</span>
                </button>
                <button type="button" class="terminal-report-action-btn" id="terminalReportPrintBtn">
                    <i class="fas fa-print" aria-hidden="true"></i>
                    <span>Print</span>
                </button>
                <button type="button" class="terminal-report-action-btn" id="terminalReportLogoutBtn">
                    <i class="fas fa-right-from-bracket" aria-hidden="true"></i>
                    <span>Iesire</span>
                </button>
            </div>
        </div>
        <div class="terminal-report-periods" id="terminalReportPeriods"></div>
        <div class="terminal-report-body" id="terminalReportPrintArea">
            <div class="terminal-reg-stack" id="terminalReportRegister"></div>
        </div>
    </div>
</div>

<div class="terminal-mp-lobby" id="terminalMpLobby" hidden aria-live="polite">
    <div class="terminal-mp-lobby__backdrop" aria-hidden="true"></div>
    <div class="terminal-mp-lobby__panel mp-entry-panel">
        <div class="terminal-mp-lobby__glow" aria-hidden="true"></div>
        <div class="terminal-mp-lobby__sparkles" aria-hidden="true"></div>
        <div class="mp-entry-hero terminal-mp-lobby__hero">
            <div class="mp-entry-hero-icon" aria-hidden="true">
                <i class="fa-solid fa-bolt"></i>
            </div>
            <p class="terminal-mp-lobby__kicker">Concurs Blitz</p>
            <h2 class="terminal-mp-lobby__title mp-entry-title">Se asteapta concurenti</h2>
            <p class="terminal-mp-lobby__sub mp-entry-sub" id="terminalMpLobbySub">Din acelasi shop. Minim 2 concurenti — apasa Porneste sau asteapta expirarea timpului.</p>
        </div>
        <div class="terminal-mp-lobby__timer-row">
            <p class="terminal-mp-lobby__timer" id="terminalMpLobbyTimer">01:00</p>
            <button type="button" class="terminal-mp-lobby__start-btn" id="terminalMpLobbyStartBtn" hidden>Porneste</button>
        </div>
        <div class="terminal-mp-lobby__tier" id="terminalMpLobbyTierCard"></div>
        <p class="terminal-mp-lobby__fee-note" id="terminalMpLobbyFee"></p>
        <div class="mp-entry-win-info terminal-mp-lobby__rules">
            <span class="mp-entry-win-icon" aria-hidden="true"><i class="fa-solid fa-shield-check"></i></span>
            <p id="terminalMpLobbyWinInfo">Daca castigi, primesti premiul Blitz plus castigurile acumulate din cele 50 spinuri pe soldul normal.</p>
        </div>
        <div class="mp-entry-win-info terminal-mp-lobby__footer">
            <span class="mp-entry-win-icon" aria-hidden="true"><i class="fa-solid fa-users"></i></span>
            <p id="terminalMpLobbyCount">Concurenti inscrisi: 1</p>
        </div>
    </div>
</div>

<div class="terminal-mp-win" id="terminalMpWin" hidden aria-live="assertive">
    <div class="terminal-mp-win__backdrop" aria-hidden="true"></div>
    <div class="terminal-mp-win__fx" aria-hidden="true">
        <span class="terminal-mp-win__burst"></span>
        <span class="terminal-mp-win__burst terminal-mp-win__burst--b"></span>
        <i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>
        <i></i><i></i><i></i><i></i>
    </div>
    <div class="terminal-mp-win__card">
        <p class="terminal-mp-win__kicker">PREMIU MULTIPLAYER</p>
        <h2 class="terminal-mp-win__title">CÂȘTIGĂTOR BLITZ</h2>
        <p class="terminal-mp-win__you" id="terminalMpWinYou">AI CÂȘTIGAT!</p>
        <p class="terminal-mp-win__prize" id="terminalMpWinPrize">0 LEI</p>
        <p class="terminal-mp-win__credits" id="terminalMpWinCredits"></p>
        <p class="terminal-mp-win__sub" id="terminalMpWinSub">Premiul a intrat pe sold.</p>
    </div>
</div>

<script src="js/terminal-display-sync.js?v=<?php echo (int)@filemtime(__DIR__ . '/js/terminal-display-sync.js'); ?>"></script>
<script src="js/terminal.js?v=<?php echo (int)@filemtime(__DIR__ . '/js/terminal.js'); ?>"></script>
</body>
</html>
