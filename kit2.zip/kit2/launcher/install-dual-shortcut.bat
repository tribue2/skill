@echo off
setlocal

set "LAUNCHER=%~dp0start-dual-terminal.bat"
set "SHORTCUT_NAME=IQWIN Terminal Dual"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; " ^
  "$desktop = [Environment]::GetFolderPath('Desktop'); " ^
  "$shortcut = $ws.CreateShortcut((Join-Path $desktop '%SHORTCUT_NAME%.lnk')); " ^
  "$shortcut.TargetPath = '%LAUNCHER%'; " ^
  "$shortcut.WorkingDirectory = '%~dp0'; " ^
  "$shortcut.WindowStyle = 1; " ^
  "$shortcut.Description = 'Porneste IQWIN terminal + ecran casino pe 2 monitoare'; " ^
  "$shortcut.Save(); " ^
  "Write-Host 'Shortcut creat pe Desktop: %SHORTCUT_NAME%.lnk'"

echo.
echo Editeaza start-dual-terminal.bat daca URL-ul nu este corect.
echo Prima pornire a terminalului poate cere setup / pairing.
pause
