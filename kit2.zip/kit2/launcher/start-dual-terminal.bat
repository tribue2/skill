@echo off
setlocal EnableExtensions

rem ============================================================
rem  IQWIN - Pornire terminal dual-monitor (jos + sus / casino)
rem  Monitor 1 (principal) = terminal jocuri
rem  Monitor 2 (secundar)  = ecran info / casino
rem ============================================================

set "TERMINAL_URL=https://iqwin.eu/app/index.php?dualLauncher=1"
set "TOP_DISPLAY_URL=https://iqwin.eu/app/top-display.php"
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"

if not exist "%CHROME%" (
    set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
)
if not exist "%CHROME%" (
    set "CHROME=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
)
if not exist "%CHROME%" (
    echo [EROARE] Chrome nu a fost gasit.
    echo Editeaza start-dual-terminal.bat si seteaza calea corecta la CHROME.
    pause
    exit /b 1
)

echo Pornesc IQWIN pe 2 monitoare...
echo Terminal: %TERMINAL_URL%
echo Ecran sus: %TOP_DISPLAY_URL%
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Add-Type -AssemblyName System.Windows.Forms; " ^
  "$chrome = '%CHROME%'; " ^
  "$terminalUrl = '%TERMINAL_URL%'; " ^
  "$topUrl = '%TOP_DISPLAY_URL%'; " ^
  "$screens = [System.Windows.Forms.Screen]::AllScreens; " ^
  "$primary = [System.Windows.Forms.Screen]::PrimaryScreen; " ^
  "$secondary = $screens | Where-Object { -not $_.Primary } | Select-Object -First 1; " ^
  "function Start-Kiosk([string]$url, [System.Windows.Forms.Screen]$screen) { " ^
  "  $b = $screen.WorkingArea; " ^
  "  $args = @( " ^
  "    '--new-window', " ^
  "    '--kiosk', " ^
  "    '--start-fullscreen', " ^
  "    '--disable-popup-blocking', " ^
  "    '--disable-infobars', " ^
  "    '--no-first-run', " ^
  "    '--no-default-browser-check', " ^
  "    ('--window-position={0},{1}' -f $b.Left, $b.Top), " ^
  "    ('--window-size={0},{1}' -f $b.Width, $b.Height), " ^
  "    ('--app=' + $url) " ^
  "  ); " ^
  "  Start-Process -FilePath $chrome -ArgumentList $args | Out-Null; " ^
  "} " ^
  "Write-Host ('Monitoare detectate: ' + $screens.Count); " ^
  "Write-Host ('Terminal pe monitor principal: ' + $primary.DeviceName); " ^
  "Start-Kiosk $terminalUrl $primary; " ^
  "Start-Sleep -Seconds 2; " ^
  "if ($secondary) { " ^
  "  Write-Host ('Ecran casino pe monitor secundar: ' + $secondary.DeviceName); " ^
  "  Start-Kiosk $topUrl $secondary; " ^
  "} else { " ^
  "  Write-Host 'Un singur monitor detectat - deschid ecranul casino in dreapta.'; " ^
  "  $fallback = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea; " ^
  "  $args = @( " ^
  "    '--new-window', " ^
  "    '--kiosk', " ^
  "    '--start-fullscreen', " ^
  "    '--disable-popup-blocking', " ^
  "    ('--window-position={0},{1}' -f ($fallback.Left + $fallback.Width), $fallback.Top), " ^
  "    ('--window-size={0},{1}' -f $fallback.Width, $fallback.Height), " ^
  "    ('--app=' + $topUrl) " ^
  "  ); " ^
  "  Start-Process -FilePath $chrome -ArgumentList $args | Out-Null; " ^
  "} " ^
  "Write-Host 'Gata.';"

if errorlevel 1 (
    echo [EROARE] Nu s-a putut porni launcher-ul.
    pause
    exit /b 1
)

endlocal
