@echo off
setlocal

set "APP_URL=https://iqwin.eu/app/index.php"
set "SHORTCUT_NAME=Skill Games Terminal"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $desktop = [Environment]::GetFolderPath('Desktop'); ^
   $shortcut = $ws.CreateShortcut((Join-Path $desktop '%SHORTCUT_NAME%.lnk')); ^
   $shortcut.TargetPath = 'C:\Program Files\Google\Chrome\Application\chrome.exe'; ^
   $shortcut.Arguments = '--kiosk --app=%APP_URL%'; ^
   $shortcut.WorkingDirectory = '%USERPROFILE%'; ^
   $shortcut.Save(); ^
   Write-Host 'Shortcut creat pe Desktop.'"

echo.
echo Daca Chrome nu este in locatia standard, editeaza installer.bat cu calea corecta.
echo Prima pornire va deschide setup.php pentru cod pairing.
pause
