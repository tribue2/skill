'use strict';

const fs = require('fs');
const { execFile } = require('child_process');

const POLL_MS = 1500;
const SKIP = { 'C:': true };

function listDriveLetters() {
  const found = {};
  for (let code = 65; code <= 90; code += 1) {
    const letter = String.fromCharCode(code) + ':';
    if (SKIP[letter]) {
      continue;
    }
    try {
      if (fs.existsSync(letter + '\\')) {
        found[letter] = true;
      }
    } catch (error) {}
  }
  return found;
}

function authHeaders(cfg) {
  return {
    'Content-Type': 'application/json',
    'X-Terminal-Code': String(cfg.terminal_code || ''),
    'X-Terminal-Secret': String(cfg.api_secret || '')
  };
}

async function reportDevice(cfg, payload) {
  const url = String(cfg.server_url || '').replace(/\/$/, '') + '/api/terminal/usb-alert.php';
  const response = await fetch(url, {
    method: 'POST',
    headers: authHeaders(cfg),
    body: JSON.stringify(Object.assign({
      terminal_code: String(cfg.terminal_code || ''),
      api_secret: String(cfg.api_secret || ''),
      event: 'inserted'
    }, payload || {})),
    redirect: 'manual'
  });
  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch (error) {
    throw new Error('Raspuns invalid: ' + String(text).slice(0, 120));
  }
  if (!response.ok || !data || !data.ok) {
    throw new Error((data && data.message) || ('HTTP ' + response.status));
  }
  return data;
}

function isExternalInputId(instanceId) {
  const id = String(instanceId || '').toUpperCase();
  if (!id) {
    return false;
  }
  if (id.indexOf('ROOT\\') === 0 || id.indexOf('SWD\\') === 0) {
    return false;
  }
  if (id.indexOf('USB\\') === 0) {
    return true;
  }
  if (id.indexOf('HID\\VID_') === 0) {
    return true;
  }
  if (id.indexOf('BTHENUM\\') === 0 || id.indexOf('BTHLE\\') === 0 || id.indexOf('BTHLEDEVICE\\') === 0) {
    return true;
  }
  if (id.indexOf('BLUETOOTH') !== -1) {
    return true;
  }
  return false;
}

function listUsbInputDevices() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') {
      resolve([]);
      return;
    }

    const script = [
      "$ErrorActionPreference='SilentlyContinue';",
      "Get-PnpDevice -PresentOnly |",
      "  Where-Object {",
      "    ($_.Class -eq 'Keyboard' -or $_.Class -eq 'Mouse') -and",
      "    $_.Status -eq 'OK'",
      "  } |",
      "  Select-Object InstanceId, Class, FriendlyName |",
      "  ConvertTo-Json -Compress"
    ].join(' ');

    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
      { windowsHide: true, timeout: 10000, maxBuffer: 1024 * 1024 },
      (error, stdout) => {
        if (error) {
          resolve([]);
          return;
        }
        const raw = String(stdout || '').trim();
        if (!raw) {
          resolve([]);
          return;
        }
        try {
          const parsed = JSON.parse(raw);
          const rows = Array.isArray(parsed) ? parsed : [parsed];
          const out = [];
          for (let i = 0; i < rows.length; i += 1) {
            const row = rows[i] || {};
            const id = String(row.InstanceId || '').trim();
            const cls = String(row.Class || '').trim().toLowerCase();
            if (!id || (cls !== 'keyboard' && cls !== 'mouse')) {
              continue;
            }
            if (!isExternalInputId(id)) {
              continue;
            }
            out.push({
              id: id,
              kind: cls,
              name: String(row.FriendlyName || '').trim()
            });
          }
          resolve(out);
        } catch (parseError) {
          resolve([]);
        }
      }
    );
  });
}

function pickByKind(devices) {
  const found = { keyboard: null, mouse: null };
  for (let i = 0; i < devices.length; i += 1) {
    const device = devices[i];
    if (!found[device.kind]) {
      found[device.kind] = device;
    }
  }
  return found;
}

async function reportInputKinds(cfg, log, byKind, label) {
  const kinds = ['keyboard', 'mouse'];
  for (let i = 0; i < kinds.length; i += 1) {
    const kind = kinds[i];
    const device = byKind[kind];
    if (!device) {
      continue;
    }
    try {
      await reportDevice(cfg, {
        device_kind: kind,
        device_id: device.id.slice(0, 160),
        drive_letter: '',
        model: device.name || (kind === 'mouse' ? 'Mouse' : 'Tastatura'),
        volume_name: ''
      });
      if (typeof log === 'function') {
        log((label || 'Event') + ' ' + kind + ': ' + (device.name || device.id));
      }
    } catch (error) {
      if (typeof log === 'function') {
        log((label || 'Event') + ' ' + kind + ' fail: ' + (error.message || error));
      }
    }
  }
}

function startDriveGuard(cfg, log) {
  if (!cfg || !cfg.server_url || !cfg.terminal_code || !cfg.api_secret) {
    return null;
  }

  let knownDrives = listDriveLetters();
  let knownInputs = {};
  let inputsReady = false;
  let busy = false;

  listUsbInputDevices().then(async (devices) => {
    const map = {};
    for (let i = 0; i < devices.length; i += 1) {
      map[devices[i].id] = true;
    }
    knownInputs = map;
    inputsReady = true;
    if (devices.length > 0) {
      await reportInputKinds(cfg, log, pickByKind(devices), 'Prezent');
    }
  });

  const timer = setInterval(async () => {
    if (busy) {
      return;
    }
    busy = true;
    try {
      const currentDrives = listDriveLetters();
      const driveLetters = Object.keys(currentDrives);
      for (let i = 0; i < driveLetters.length; i += 1) {
        const letter = driveLetters[i];
        if (knownDrives[letter]) {
          continue;
        }
        try {
          await reportDevice(cfg, {
            device_kind: 'usb',
            device_id: 'DRIVE:' + letter,
            drive_letter: letter,
            model: '',
            volume_name: ''
          });
          if (typeof log === 'function') {
            log('Event host: ' + letter);
          }
        } catch (error) {
          if (typeof log === 'function') {
            log('Event host fail: ' + (error.message || error));
          }
        }
      }
      knownDrives = currentDrives;

      if (inputsReady) {
        const devices = await listUsbInputDevices();
        const currentInputs = {};
        const newByKind = { keyboard: null, mouse: null };
        for (let i = 0; i < devices.length; i += 1) {
          const device = devices[i];
          currentInputs[device.id] = true;
          if (knownInputs[device.id]) {
            continue;
          }
          if (!newByKind[device.kind]) {
            newByKind[device.kind] = device;
          }
        }
        await reportInputKinds(cfg, log, newByKind, 'Event');
        knownInputs = currentInputs;
      }
    } catch (error) {
      if (typeof log === 'function') {
        log('Host scan: ' + (error.message || error));
      }
    }
    busy = false;
  }, POLL_MS);

  if (typeof timer.unref === 'function') {
    timer.unref();
  }

  return timer;
}

module.exports = { startDriveGuard, listDriveLetters, listUsbInputDevices };
