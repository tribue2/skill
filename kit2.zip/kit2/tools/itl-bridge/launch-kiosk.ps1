param(
  [string]$Url = 'http://127.0.0.1:17891/boot'
)

$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms

$vs = [System.Windows.Forms.SystemInformation]::VirtualScreen
$x = [int]$vs.X
$y = [int]$vs.Y
$w = [int]$vs.Width
$h = [int]$vs.Height

$chromeCandidates = @(
  (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
  (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
  (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
)
$edgeCandidates = @(
  (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
)

$browser = $chromeCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
$isEdge = $false
if (-not $browser) {
  $browser = $edgeCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
  $isEdge = [bool]$browser
}

if (-not $browser) {
  Start-Process $Url | Out-Null
  exit 0
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataDir = Join-Path $root 'chrome-kiosk-profile'
if (-not (Test-Path $dataDir)) {
  New-Item -ItemType Directory -Path $dataDir | Out-Null
}

Get-CimInstance Win32_Process -Filter "Name = 'chrome.exe' OR Name = 'msedge.exe'" |
  Where-Object { $_.CommandLine -and ($_.CommandLine -like '*chrome-kiosk-profile*') } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }

Start-Sleep -Milliseconds 400

$argList = @(
  "--user-data-dir=$dataDir",
  '--no-first-run',
  '--no-default-browser-check',
  '--disable-infobars',
  '--disable-session-crashed-bubble',
  '--disable-restore-session-state',
  '--disable-features=TranslateUI,InfiniteSessionRestore',
  '--autoplay-policy=no-user-gesture-required',
  '--allow-running-insecure-content',
  '--disable-features=TranslateUI,InfiniteSessionRestore,BlockInsecurePrivateNetworkRequests',
  "--window-position=$x,$y",
  "--window-size=$w,$h"
)

if ($isEdge) {
  $argList += @('--kiosk', '--edge-kiosk-type=fullscreen', $Url)
} else {
  $argList += @('--kiosk', $Url)
}

Start-Process -FilePath $browser -ArgumentList $argList | Out-Null

Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class IqwinKiosk {
  public delegate bool EnumProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
  [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
  [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int X, int Y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  public const int GWL_STYLE = -16;
  public const int WS_CAPTION = 0x00C00000;
  public const int WS_THICKFRAME = 0x00040000;
  public const int WS_BORDER = 0x00800000;
  public const int WS_SYSMENU = 0x00080000;
  public const int SWP_FRAMECHANGED = 0x0020;
  public const int SWP_SHOWWINDOW = 0x0040;
  public const int SW_SHOW = 5;
  public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
}
"@

function Get-KioskWindowHandle {
  $script:kioskPids = New-Object 'System.Collections.Generic.HashSet[uint32]'
  Get-CimInstance Win32_Process -Filter "Name = 'chrome.exe' OR Name = 'msedge.exe'" |
    Where-Object { $_.CommandLine -and ($_.CommandLine -like '*chrome-kiosk-profile*') } |
    ForEach-Object { [void]$script:kioskPids.Add([uint32]$_.ProcessId) }

  if ($script:kioskPids.Count -eq 0) { return [IntPtr]::Zero }

  $script:bestHwnd = [IntPtr]::Zero
  $script:bestArea = 0
  $callback = [IqwinKiosk+EnumProc]{
    param([IntPtr]$hwnd, [IntPtr]$lParam)
    if (-not [IqwinKiosk]::IsWindowVisible($hwnd)) { return $true }
    $pid = [uint32]0
    [void][IqwinKiosk]::GetWindowThreadProcessId($hwnd, [ref]$pid)
    if (-not $script:kioskPids.Contains($pid)) { return $true }
    $rect = New-Object IqwinKiosk+RECT
    if (-not [IqwinKiosk]::GetWindowRect($hwnd, [ref]$rect)) { return $true }
    $ww = [Math]::Abs($rect.Right - $rect.Left)
    $hh = [Math]::Abs($rect.Bottom - $rect.Top)
    $area = $ww * $hh
    if ($ww -ge 200 -and $hh -ge 200 -and $area -gt $script:bestArea) {
      $script:bestArea = $area
      $script:bestHwnd = $hwnd
    }
    return $true
  }
  [void][IqwinKiosk]::EnumWindows($callback, [IntPtr]::Zero)
  return $script:bestHwnd
}

$hwnd = [IntPtr]::Zero
for ($i = 0; $i -lt 40; $i++) {
  Start-Sleep -Milliseconds 250
  $hwnd = Get-KioskWindowHandle
  if ($hwnd -ne [IntPtr]::Zero) { break }
}

if ($hwnd -ne [IntPtr]::Zero) {
  $style = [IqwinKiosk]::GetWindowLong($hwnd, [IqwinKiosk]::GWL_STYLE)
  $style = $style -band (-bnot [IqwinKiosk]::WS_CAPTION)
  $style = $style -band (-bnot [IqwinKiosk]::WS_THICKFRAME)
  $style = $style -band (-bnot [IqwinKiosk]::WS_BORDER)
  $style = $style -band (-bnot [IqwinKiosk]::WS_SYSMENU)
  [void][IqwinKiosk]::SetWindowLong($hwnd, [IqwinKiosk]::GWL_STYLE, $style)
  [void][IqwinKiosk]::ShowWindow($hwnd, [IqwinKiosk]::SW_SHOW)
  [void][IqwinKiosk]::SetWindowPos(
    $hwnd,
    [IntPtr]::Zero,
    $x, $y, $w, $h,
    ([IqwinKiosk]::SWP_FRAMECHANGED -bor [IqwinKiosk]::SWP_SHOWWINDOW)
  )
}

Write-Host ("Kiosk: {0}x{1} @ {2},{3}" -f $w, $h, $x, $y)
exit 0
