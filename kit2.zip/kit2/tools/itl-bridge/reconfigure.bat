@echo off
cd /d "%~dp0"
title IQWIN Agent - Reconfigurare
call "%~dp0set-runtime.bat"
if errorlevel 1 (
  pause
  exit /b 1
)
if not exist node_modules\serialport (
  if defined IQWIN_NPM (
    call "%IQWIN_NPM%" install --no-fund --no-audit
  ) else (
    call npm install --no-fund --no-audit
  )
)
"%IQWIN_NODE%" wizard.js
pause
