@echo off
cd /d "%~dp0"
title IQWIN Agent Bridge
call "%~dp0set-runtime.bat"
if errorlevel 1 (
  pause
  exit /b 1
)
if not exist config.json (
  echo Lipseste config.json.
  echo Ruleaza install.bat sau IQWIN-Setup.exe.
  echo.
  pause
  exit /b 1
)
echo Inchide Validator Manager daca e deschis (COM trebuie liber).
echo.
if not exist node_modules\serialport (
  if defined IQWIN_NPM (
    call "%IQWIN_NPM%" install --no-fund --no-audit
  ) else (
    call npm install --no-fund --no-audit
  )
)
"%IQWIN_NODE%" bridge.js
pause
