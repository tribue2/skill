@echo off
cd /d "%~dp0"
title IQWIN Agent - Instalare
setlocal EnableExtensions
echo.
echo ========================================
echo   IQWIN Agent - Instalare
echo ========================================
echo.
echo O singura data: pairing + alegere COM/model acceptor
echo Apoi zilnic: Porneste.bat
echo Inchide Validator Manager inainte.
echo.

call "%~dp0set-runtime.bat"
if errorlevel 1 (
  pause
  exit /b 1
)

echo Node:
"%IQWIN_NODE%" -v
echo.

if exist "%~dp0runtime\node.exe" goto :deps

set "NODE_MAJOR="
"%IQWIN_NODE%" -p "process.versions.node.split('.')[0]" > "%TEMP%\iqwin-node-major.txt" 2>nul
set /p NODE_MAJOR=<"%TEMP%\iqwin-node-major.txt"
del /f /q "%TEMP%\iqwin-node-major.txt" >nul 2>nul
if not defined NODE_MAJOR set NODE_MAJOR=0

if %NODE_MAJOR% GEQ 21 (
  echo Node %NODE_MAJOR% e prea nou pentru kit.
  echo Foloseste kit-ul IQWIN Agent (cu runtime inclus).
  pause
  exit /b 1
)
if %NODE_MAJOR% LSS 18 (
  echo Node e prea vechi.
  echo Foloseste kit-ul IQWIN Agent (cu runtime inclus).
  pause
  exit /b 1
)

:deps
if not exist "node_modules\serialport" (
  if not exist "node_modules\@serialport" (
    echo Instalez dependentele...
    if defined IQWIN_NPM (
      call "%IQWIN_NPM%" install --no-fund --no-audit
    ) else (
      call npm install --no-fund --no-audit
    )
    if errorlevel 1 (
      echo.
      echo npm install a esuat.
      echo Descarca din nou kit-ul IQWIN Agent din admin.
      echo.
      pause
      exit /b 1
    )
    echo.
  )
)

"%IQWIN_NODE%" agent.js --install
if errorlevel 1 (
  echo.
  pause
  exit /b 1
)

echo.
echo Instalare finalizata.
pause
endlocal
exit /b 0
