'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');

const PID_PATH = path.join(__dirname, 'bridge.pid');

const liveBalance = {
  credits_balance: null,
  pending_money: 0,
  seq: 0,
  updated_at: 0
};

let moneyInFlight = 0;

function touchLive() {
  liveBalance.seq += 1;
  liveBalance.updated_at = Date.now();
}

function corsHeaders(extra) {
  return Object.assign({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Private-Network': 'true'
  }, extra || {});
}

function setLiveBalance(credits) {
  const value = Number(credits);
  if (!Number.isFinite(value)) {
    return;
  }
  if (moneyInFlight > 0 && liveBalance.credits_balance != null && value < liveBalance.credits_balance) {
    return;
  }
  liveBalance.credits_balance = value;
  liveBalance.pending_money = 0;
  touchLive();
}

function bumpLiveByMoney(amountMoney, creditRate) {
  const money = Number(amountMoney);
  if (!(money > 0)) {
    return;
  }
  const rate = Number(creditRate) > 0 ? Number(creditRate) : 0.1;
  moneyInFlight += 1;
  if (liveBalance.credits_balance == null) {
    liveBalance.pending_money = Number(liveBalance.pending_money || 0) + money;
    touchLive();
    return;
  }
  liveBalance.credits_balance = liveBalance.credits_balance + Math.floor(money / rate);
  liveBalance.pending_money = 0;
  touchLive();
}

function confirmLiveBalance(credits) {
  moneyInFlight = Math.max(0, moneyInFlight - 1);
  const value = Number(credits);
  if (!Number.isFinite(value)) {
    return;
  }
  if (moneyInFlight > 0) {
    if (liveBalance.credits_balance == null || value > liveBalance.credits_balance) {
      liveBalance.credits_balance = value;
    }
  } else {
    liveBalance.credits_balance = value;
    liveBalance.pending_money = 0;
  }
  touchLive();
}

function revertLiveByMoney(amountMoney, creditRate) {
  moneyInFlight = Math.max(0, moneyInFlight - 1);
  const money = Number(amountMoney);
  const rate = Number(creditRate) > 0 ? Number(creditRate) : 0.1;
  const credits = Math.floor(money / rate);
  if (liveBalance.credits_balance != null && credits > 0) {
    liveBalance.credits_balance = Math.max(0, liveBalance.credits_balance - credits);
  } else if (money > 0) {
    liveBalance.pending_money = Math.max(0, Number(liveBalance.pending_money || 0) - money);
  }
  touchLive();
}

function startLocalApi(cfg, log) {
  const port = Math.max(1024, Number(cfg.local_port || 17891));
  const payloadObj = {
    ok: true,
    server_url: cfg.server_url,
    terminal_code: cfg.terminal_code,
    api_secret: cfg.api_secret,
    terminal_name: cfg.terminal_name || '',
    com_port: cfg.com_port || '',
    bridge: true
  };
  const payload = JSON.stringify(payloadObj);

  const linkHtml = `<!DOCTYPE html>
<html lang="ro"><head><meta charset="UTF-8"><title>IQWIN Bridge</title></head>
<body style="font-family:sans-serif;background:#12151a;color:#e8eef4;padding:24px;">
<p>Trimit credentialele catre terminal...</p>
<script>
(function () {
  var data = ${payload};
  if (window.opener && !window.opener.closed) {
    window.opener.postMessage({ type: 'iqwin-itl-credentials', data: data }, '*');
    document.body.innerHTML = '<p style="color:#7dcea0">OK — poti inchide aceasta fereastra.</p>';
    setTimeout(function () { window.close(); }, 600);
  } else {
    document.body.innerHTML = '<p>Ruleaza start-kit.bat pe acest PC.</p>';
  }
})();
</script>
</body></html>`;

  function makeBootHtml(nextTarget, titleText, msgText) {
    return `<!DOCTYPE html>
<html lang="ro"><head><meta charset="UTF-8"><title>${titleText}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
html,body{margin:0;height:100%;background:#0e1116;color:#e8eef4;font-family:Segoe UI,sans-serif;display:grid;place-items:center}
.box{text-align:center;padding:24px}
h1{margin:0 0 8px;font-size:1.4rem;color:#f0d78c}
p{margin:0;color:#9aa7b3}
</style></head>
<body>
<div class="box">
  <h1>IQWIN Agent</h1>
  <p id="msg">${msgText}</p>
</div>
<script>
(function () {
  var data = ${payload};
  var server = String(data.server_url || '').replace(/\\/$/, '');
  if (!server || !data.terminal_code || !data.api_secret) {
    document.getElementById('msg').textContent = 'Config incomplet. Ruleaza install.bat.';
    return;
  }
  var token = btoa(unescape(encodeURIComponent(JSON.stringify(data))));
  var next = ${JSON.stringify(nextTarget)};
  window.location.replace(server + '/app/bridge-link.php?next=' + encodeURIComponent(next) + '#iqwin=' + encodeURIComponent(token));
})();
</script>
</body></html>`;
  }

  const bootHtml = makeBootHtml('games', 'IQWIN Agent', 'Pornesc jocurile...');
  const bootTopHtml = makeBootHtml('top', 'IQWIN Agent', 'Pornesc ecranul info...');

  function resolveSlideVideoPath() {
    const candidates = [
      path.join(__dirname, 'top-screen', 'slidevideo.mp4'),
      path.join(__dirname, '..', 'top-screen', 'slidevideo.mp4'),
      path.join(__dirname, '..', '..', 'top-screen', 'slidevideo.mp4'),
    ];
    for (let i = 0; i < candidates.length; i += 1) {
      const file = candidates[i];
      try {
        if (fs.existsSync(file) && fs.statSync(file).isFile()) {
          return file;
        }
      } catch (error) {}
    }
    return null;
  }

  function serveMediaFile(req, res, filePath) {
    let stat;
    try {
      stat = fs.statSync(filePath);
    } catch (error) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }

    const total = stat.size;
    const range = req.headers.range;
    const contentType = 'video/mp4';

    if (range) {
      const parts = String(range).replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : total - 1;
      if (Number.isNaN(start) || start >= total || end >= total) {
        res.writeHead(416, { 'Content-Range': 'bytes */' + total });
        res.end();
        return;
      }
      const chunkSize = end - start + 1;
      res.writeHead(206, {
        'Content-Range': 'bytes ' + start + '-' + end + '/' + total,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunkSize,
        'Content-Type': contentType,
      });
      fs.createReadStream(filePath, { start, end }).pipe(res);
      return;
    }

    res.writeHead(200, {
      'Content-Length': total,
      'Content-Type': contentType,
      'Accept-Ranges': 'bytes',
    });
    fs.createReadStream(filePath).pipe(res);
  }

  const server = http.createServer((req, res) => {
    const origin = req.headers.origin || '*';
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Vary', 'Origin');

    if (req.method === 'OPTIONS') {
      res.writeHead(204, corsHeaders());
      res.end();
      return;
    }

    const url = String(req.url || '').split('?')[0];
    if (req.method === 'GET' && url === '/balance') {
      res.writeHead(200, corsHeaders({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }));
      res.end(JSON.stringify({
        ok: true,
        credits_balance: liveBalance.credits_balance,
        pending_money: Number(liveBalance.pending_money || 0),
        seq: liveBalance.seq,
        updated_at: liveBalance.updated_at
      }));
      return;
    }

    if (req.method === 'GET' && (url === '/credentials' || url === '/status' || url === '/')) {
      res.writeHead(200, corsHeaders({ 'Content-Type': 'application/json; charset=utf-8' }));
      res.end(payload);
      return;
    }

    if (req.method === 'GET' && (url === '/boot' || url === '/kit')) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(bootHtml);
      return;
    }

    if (req.method === 'GET' && (url === '/boot-top' || url === '/kit-top')) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(bootTopHtml);
      return;
    }

    if (req.method === 'GET' && url === '/link') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(linkHtml);
      return;
    }

    if ((req.method === 'GET' || req.method === 'HEAD') && url === '/media/slidevideo.mp4') {
      const mediaPath = resolveSlideVideoPath();
      if (!mediaPath) {
        res.writeHead(404, { 'Content-Type': 'application/json; charset=utf-8' });
        if (req.method === 'HEAD') {
          res.end();
        } else {
          res.end(JSON.stringify({ ok: false, message: 'Media not found' }));
        }
        return;
      }
      if (req.method === 'HEAD') {
        const stat = fs.statSync(mediaPath);
        res.writeHead(200, {
          'Content-Length': stat.size,
          'Content-Type': 'video/mp4',
          'Accept-Ranges': 'bytes',
        });
        res.end();
        return;
      }
      serveMediaFile(req, res, mediaPath);
      return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: false, message: 'Not found' }));
  });

  server.listen(port, '127.0.0.1', () => {
    if (typeof log === 'function') {
      log('API local: http://127.0.0.1:' + port + '/credentials');
    }
  });

  server.on('error', (error) => {
    if (typeof log === 'function') {
      log('API local indisponibil: ' + (error.message || error));
    }
  });

  return server;
}

function writePidFile() {
  try {
    fs.writeFileSync(PID_PATH, String(process.pid), 'utf8');
  } catch (error) {}
}

function clearPidFile() {
  try {
    if (fs.existsSync(PID_PATH)) {
      fs.unlinkSync(PID_PATH);
    }
  } catch (error) {}
}

module.exports = {
  startLocalApi,
  setLiveBalance,
  bumpLiveByMoney,
  confirmLiveBalance,
  revertLiveByMoney,
  writePidFile,
  clearPidFile,
  PID_PATH
};
