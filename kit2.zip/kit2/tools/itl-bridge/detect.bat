@echo off
cd /d "%~dp0"
title IQWIN Agent - Detectie acceptori
echo.
echo Inchide Validator Manager / softurile JCM inainte de scan.
echo.

call "%~dp0set-runtime.bat"
if errorlevel 1 (
  pause
  exit /b 1
)

if not exist node_modules\@toopago (
  if not exist node_modules\serialport (
    echo Instalez dependentele...
    if defined IQWIN_NPM (
      call "%IQWIN_NPM%" install --no-fund --no-audit
    ) else (
      call npm install --no-fund --no-audit
    )
  )
)

"%IQWIN_NODE%" detect-acceptors.js
echo.
pause
