'use strict';

const fs = require('fs');
const path = require('path');
const { startLocalApi, writePidFile, clearPidFile } = require('./local-api');

const CONFIG_PATH = path.join(__dirname, 'config.json');

function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    throw new Error('Lipseste config.json. Ruleaza install.bat o singura data pe acest PC.');
  }
  const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  const cfg = JSON.parse(raw);
  if (process.argv.includes('--simulate')) {
    cfg.simulate = true;
  }
  cfg.server_url = String(cfg.server_url || '').replace(/\/$/, '');
  cfg.com_port = String(cfg.com_port || 'COM3');
  cfg.baud_rate = Number(cfg.baud_rate || 9600);
  cfg.poll_ms = Math.max(80, Number(cfg.poll_ms || 200));
  cfg.local_port = Number(cfg.local_port || 17891);
  cfg.fixed_key = String(cfg.fixed_key || '0123456701234567').replace(/^0x/i, '');
  cfg.device_type = String(cfg.device_type || 'itl').toLowerCase();
  if (cfg.device_type === 'uba10' || cfg.device_type === 'jcm' || cfg.device_type === 'id003') {
    cfg.device_type = 'uba';
  }
  if (cfg.acceptor_enabled == null) {
    cfg.acceptor_enabled = !!(cfg.com_port && String(cfg.com_port).trim());
  } else {
    cfg.acceptor_enabled = cfg.acceptor_enabled === true || cfg.acceptor_enabled === 1 || cfg.acceptor_enabled === '1';
  }
  if (!String(cfg.com_port || '').trim()) {
    cfg.acceptor_enabled = false;
  }
  cfg.channels = cfg.channels || {
    '1': 1,
    '2': 5,
    '3': 10,
    '4': 50,
    '5': 100,
    '6': 200,
    '7': 500
  };
  return cfg;
}

function authHeaders(cfg) {
  return {
    'Content-Type': 'application/json',
    'X-Terminal-Code': String(cfg.terminal_code || ''),
    'X-Terminal-Secret': String(cfg.api_secret || '')
  };
}

function authPayload(cfg, extra) {
  return Object.assign({
    terminal_code: String(cfg.terminal_code || ''),
    api_secret: String(cfg.api_secret || '')
  }, extra || {});
}

async function parseJsonResponse(response, label) {
  if (response.status >= 300 && response.status < 400) {
    throw new Error('Redirect de la server (' + response.status + '). Verifica server_url in config.json.');
  }
  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch (error) {
    throw new Error((label || 'API') + ' raspuns invalid: ' + String(text).slice(0, 120));
  }
  if (!response.ok || !data || !data.ok) {
    throw new Error((data && data.message) || ('HTTP ' + response.status));
  }
  return data;
}

const moneyQueue = [];
let moneyPumping = false;

async function postMoneyInHttp(cfg, amountMoney, notes) {
  const url = cfg.server_url + '/api/terminal/credits.php';
  const response = await fetch(url, {
    method: 'POST',
    headers: authHeaders(cfg),
    body: JSON.stringify(authPayload(cfg, {
      action: 'money_in',
      amount_money: amountMoney,
      game_overlay_open: false,
      notes: notes || 'itl_validator',
      event_id: 'bill:' + Date.now() + ':' + String(amountMoney) + ':' + Math.floor(process.hrtime.bigint() % 1000000n)
    })),
    redirect: 'manual'
  });
  return parseJsonResponse(response, 'credits.php');
}

function postMoneyIn(cfg, amountMoney, notes) {
  try {
    require('./local-api').bumpLiveByMoney(amountMoney, cfg.credit_rate || 0.1);
  } catch (error) {}
  return new Promise((resolve, reject) => {
    moneyQueue.push({ cfg, amountMoney, notes, resolve, reject });
    pumpMoneyQueue();
  });
}

async function pumpMoneyQueue() {
  if (moneyPumping) {
    return;
  }
  moneyPumping = true;
  while (moneyQueue.length) {
    const job = moneyQueue.shift();
    try {
      const data = await postMoneyInHttp(job.cfg, job.amountMoney, job.notes);
      try {
        require('./local-api').confirmLiveBalance(data.credits_balance);
      } catch (error) {}
      if (data && data.credits_added > 0 && job.amountMoney > 0) {
        job.cfg.credit_rate = Number(job.amountMoney) / Number(data.credits_added);
      }
      job.resolve(data);
    } catch (error) {
      try {
        require('./local-api').revertLiveByMoney(job.amountMoney, job.cfg.credit_rate || 0.1);
      } catch (revertError) {}
      job.reject(error);
    }
  }
  moneyPumping = false;
}

async function postStackerReset(cfg, notes) {
  const url = cfg.server_url + '/api/terminal/credits.php';
  const response = await fetch(url, {
    method: 'POST',
    headers: authHeaders(cfg),
    body: JSON.stringify(authPayload(cfg, {
      action: 'stacker_reset',
      notes: notes || 'cashbox_removed'
    })),
    redirect: 'manual'
  });
  return parseJsonResponse(response, 'credits.php');
}

async function verifyCredentials(cfg) {
  const url = cfg.server_url + '/api/terminal/credits.php';
  const response = await fetch(url, {
    method: 'POST',
    headers: authHeaders(cfg),
    body: JSON.stringify(authPayload(cfg, {
      action: 'ping'
    })),
    redirect: 'manual'
  });
  return parseJsonResponse(response, 'credits.php ping');
}

function log(msg) {
  const stamp = new Date().toISOString().replace('T', ' ').slice(0, 19);
  console.log('[' + stamp + '] ' + msg);
}

function resolveAmount(channel, channelMap, setupValues) {
  const key = String(channel);
  if (channelMap[key] != null && Number(channelMap[key]) > 0) {
    return Number(channelMap[key]);
  }
  if (setupValues[key] != null && Number(setupValues[key]) > 0) {
    let value = Number(setupValues[key]);
    if (value >= 100 && value % 100 === 0 && value <= 50000) {
      value = value / 100;
    }
    return value;
  }
  return 0;
}

async function runSimulate(cfg) {
  log('Mod SIMULARE — fara COM. Tasteaza suma in RON (ex: 10) + Enter. "q" = iesire.');
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', async (chunk) => {
    const line = String(chunk || '').trim().toLowerCase();
    if (!line) return;
    if (line === 'q' || line === 'quit' || line === 'exit') {
      process.exit(0);
    }
    const amount = Number(line.replace(',', '.'));
    if (!Number.isFinite(amount) || amount < 1) {
      log('Suma invalida.');
      return;
    }
    try {
      const data = await postMoneyIn(cfg, amount);
      log('IN OK: +' + amount + ' RON → sold ' + data.credits_balance + ' credite');
    } catch (error) {
      log('EROARE IN: ' + (error.message || error));
    }
  });
}

async function runPlainSerial(cfg) {
  const { SspHost, extractCredits, extractCashboxEvents, CMD } = require('./ssp');
  const { openSerialPort, closeSerialPort } = require('./serial-util');

  log('IMPORTANT: inchide Validator Manager inainte (COM trebuie liber).');
  log('ITL NV9/NV10 fara criptare pe ' + cfg.com_port);

  const port = await openSerialPort(cfg.com_port, {
    baudRate: Number(cfg.baud_rate || 9600),
    dataBits: 8,
    stopBits: 2,
    parity: 'none'
  });
  log('Deschis ' + cfg.com_port + ' @ ' + Number(cfg.baud_rate || 9600) + ' 8N2');
  await new Promise((resolve) => setTimeout(resolve, 1500));

  const host = new SspHost(port);
  let synced = false;
  for (let i = 0; i < 8; i += 1) {
    const reply = await host.sync();
    if (reply && reply.data && reply.data.length && (reply.data[0] === 0xf0 || reply.data[0] === 0xf8)) {
      synced = true;
      break;
    }
    await host.sleep(400);
  }
  if (!synced) {
    await closeSerialPort(port);
    throw new Error('ITL nu raspunde la SYNC pe ' + cfg.com_port);
  }
  log('ITL SYNC OK');

  try {
    await host.sendCommand([CMD.HOST_PROTOCOL_VERSION, 6], 400);
  } catch (error) {}

  await host.enable();
  log('ITL enable — astept bancnote...');

  let lastCashboxResetAt = 0;
  let running = true;

  const shutdown = async () => {
    running = false;
    try { await host.disable(); } catch (e) {}
    await closeSerialPort(port);
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  while (running) {
    try {
      const poll = await host.poll();
      let disabled = false;
      if (Array.isArray(poll)) {
        for (let p = 0; p < poll.length; p += 1) {
          if (poll[p] === 0xe8) {
            disabled = true;
          }
        }
      }
      if (disabled) {
        await host.enable();
      }
      const credits = extractCredits(poll, cfg.channels);
      for (let i = 0; i < credits.length; i += 1) {
        const amount = Number(credits[i].amount || 0);
        if (!(amount > 0)) continue;
        log('Bancnota canal ' + credits[i].channel + ' = ' + amount + ' RON');
        postMoneyIn(cfg, amount).then((data) => {
          const foi = (data.stacker_bills != null)
            ? (' · foi ' + data.stacker_bills + '/' + data.stacker_capacity)
            : '';
          log('IN OK: +' + amount + ' RON → sold ' + data.credits_balance + ' credite' + foi);
        }).catch((error) => {
          log('EROARE IN: ' + (error.message || error));
        });
      }
      const box = extractCashboxEvents(poll);
      if (box.indexOf('removed') >= 0) {
        const now = Date.now();
        if (now - lastCashboxResetAt > 5000) {
          lastCashboxResetAt = now;
          log('Caseta scoasa → reset foi');
          try {
            const data = await postStackerReset(cfg, 'cashbox_removed');
            log('Stacker reset OK: ' + (data.stacker_bills || 0) + '/' + (data.stacker_capacity || 1000));
          } catch (error) {
            log('EROARE reset stacker: ' + (error.message || error));
          }
        }
      }
    } catch (error) {
      log('ITL poll: ' + (error.message || error));
      await host.sleep(400);
    }
    await host.sleep(Math.max(40, Number(cfg.poll_ms || 80)));
  }
}

async function runEncryptedSerial(cfg) {
  let SspLib;
  try {
    SspLib = require('@toopago/essp');
  } catch (error) {
    throw new Error('Lipseste @toopago/essp. Ruleaza install.bat (npm install).');
  }

  const { patchEsspDh, patchEsspSerialPort, patchEsspKeepEnabled } = require('./patch-essp-dh');
  SspLib = patchEsspKeepEnabled(patchEsspSerialPort(patchEsspDh(SspLib)));

  log('IMPORTANT: inchide Validator Manager inainte (COM trebuie liber).');
  log('Dispozitiv asteptat: SMART Payout / NV cu eSSP Encryption.');

  const setupValues = {};
  let lastCashboxResetAt = 0;

  const eSSP = new SspLib({
    id: 0x00,
    debug: false,
    timeout: 5000,
    encryptAllCommand: true,
    fixedKey: cfg.fixed_key
  });

  eSSP.on('CREDIT_NOTE', (result) => {
    const channel = Number((result && result.channel) || 0);
    const amount = resolveAmount(channel, cfg.channels, setupValues);
    if (!(amount > 0)) {
      log('CREDIT canal ' + channel + ' — suma necunoscuta (completeaza channels in config.json)');
      return;
    }
    log('Bancnota canal ' + channel + ' = ' + amount + ' RON');
    postMoneyIn(cfg, amount).then((data) => {
      const foi = (data.stacker_bills != null)
        ? (' · foi ' + data.stacker_bills + '/' + data.stacker_capacity)
        : '';
      log('IN OK: +' + amount + ' RON → sold ' + data.credits_balance + ' credite' + foi);
    }).catch((error) => {
      log('EROARE IN: ' + (error.message || error));
    });
  });

  eSSP.on('CASHBOX_REMOVED', async () => {
    const now = Date.now();
    if (now - lastCashboxResetAt <= 5000) return;
    lastCashboxResetAt = now;
    log('Caseta scoasa → reset foi');
    try {
      const data = await postStackerReset(cfg, 'cashbox_removed');
      log('Stacker reset OK: ' + (data.stacker_bills || 0) + '/' + (data.stacker_capacity || 1000));
    } catch (error) {
      log('EROARE reset stacker: ' + (error.message || error));
    }
  });

  eSSP.on('DISABLED', () => {
    log('ITL DISABLED — repornesc enable');
    eSSP.enable().catch((error) => {
      log('ENABLE: ' + (error.message || error));
    });
  });

  eSSP.on('NOTE_REJECTED', () => {
    log('Bancnota respinsa');
  });

  eSSP.on('STACKER_FULL', () => {
    log('Receptor plin (STACKER_FULL)');
  });

  eSSP.on('CLOSE', () => {
    log('Port inchis');
  });

  const serialPortConfig = {
    baudrate: cfg.baud_rate,
    databits: 8,
    stopbits: 2,
    parity: 'none'
  };

  await eSSP.open(cfg.com_port, serialPortConfig);
  log('Deschis ' + cfg.com_port + ' @ ' + cfg.baud_rate + ' (eSSP)');

  await eSSP.command('SYNC');
  await eSSP.command('HOST_PROTOCOL_VERSION', { version: 6 });
  await eSSP.initEncryption();
  log('Criptare eSSP OK');

  try {
    const serial = await eSSP.command('GET_SERIAL_NUMBER');
    if (serial && serial.info && serial.info.serial_number != null) {
      log('Serial: ' + serial.info.serial_number);
    }
  } catch (error) {
    log('GET_SERIAL_NUMBER: ' + (error.message || error));
  }

  try {
    const setup = await eSSP.command('SETUP_REQUEST');
    const info = (setup && setup.info) || {};
    const channels = info.channel_value || [];
    const values = info.expanded_channel_value || info.channel_value || [];
    for (let i = 0; i < values.length; i += 1) {
      const ch = Number(channels[i] != null ? channels[i] : (i + 1));
      let value = Number(values[i] || 0);
      if (value >= 100 && value % 100 === 0 && value <= 50000 && !cfg.channels[String(ch)]) {
        value = value / 100;
      }
      if (ch > 0 && value > 0) {
        setupValues[String(ch)] = value;
      }
    }
    const mapLog = Object.keys(setupValues).sort((a, b) => Number(a) - Number(b)).map((ch) => {
      const configured = cfg.channels[ch] != null ? cfg.channels[ch] : setupValues[ch];
      return ch + '=' + configured + 'RON';
    }).join(', ');
    if (mapLog) {
      log('Canale: ' + mapLog);
    }
  } catch (error) {
    log('SETUP_REQUEST: ' + (error.message || error) + ' — folosesc channels din config.json');
  }

  try {
    await eSSP.command('SET_CHANNEL_INHIBITS', {
      channels: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    });
  } catch (error) {
    log('SET_CHANNEL_INHIBITS: ' + (error.message || error));
  }

  try {
    await eSSP.command('DISPLAY_ON');
  } catch (error) {}

  try {
    await eSSP.command('DISABLE_PAYOUT_DEVICE');
    log('Payout store dezactivat — bancnotele merg in cashbox/receptor');
  } catch (error) {
    log('DISABLE_PAYOUT_DEVICE: ' + (error.message || error));
  }

  const enabled = await eSSP.enable();
  if (enabled && enabled.status && String(enabled.status).toUpperCase() !== 'OK') {
    log('ENABLE status: ' + enabled.status);
  }
  try {
    await eSSP.command('DISPLAY_ON');
  } catch (error) {}
  log('SMART Payout enable — astept bancnote...');

  const shutdown = async () => {
    try {
      await eSSP.disable();
    } catch (error) {}
    try {
      await eSSP.close();
    } catch (error) {}
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

async function main() {
  const cfg = loadConfig();
  if (!cfg.server_url || !cfg.terminal_code || !cfg.api_secret) {
    log('Config incomplet. Ruleaza install.bat sau reconfigure.bat');
    process.exit(1);
  }

  writePidFile();
  process.on('exit', clearPidFile);
  process.on('SIGINT', function () { clearPidFile(); process.exit(0); });
  process.on('SIGTERM', function () { clearPidFile(); process.exit(0); });

  startLocalApi(cfg, log);

  try {
    const { startDriveGuard } = require('./drive-guard');
    startDriveGuard(cfg, log);
  } catch (error) {
    log('Guard: ' + (error.message || error));
  }

  log('Server: ' + cfg.server_url);
  log('Terminal: ' + cfg.terminal_code + (cfg.terminal_name ? ' (' + cfg.terminal_name + ')' : ''));
  if (cfg.acceptor_enabled) {
    log('COM: ' + cfg.com_port);
    log('Acceptor: ' + (cfg.device_type === 'uba' ? 'JCM UBA-10 (ID-003)' : 'ITL eSSP'));
  } else {
    log('Acceptor: dezactivat (fara COM) — doar jocuri');
  }

  let authOk = false;
  try {
    const boot = await verifyCredentials(cfg);
    authOk = true;
    try {
      require('./local-api').setLiveBalance(boot.credits_balance);
    } catch (error) {}
    log('Auth OK — sold ' + (boot.credits_balance != null ? boot.credits_balance : ((boot.terminal && boot.terminal.credits_balance) || 0)) + ' credite');
  } catch (error) {
    log('AUTH ESUAT: ' + (error.message || error));
    log('Ruleaza Instaleaza.bat din nou pentru pairing.');
    log('Kit-ul poate deschide jocurile, dar acceptorul NU creditaza pana la Auth OK.');
  }

  if (!authOk) {
    await new Promise(function () {});
    return;
  }

  if (!cfg.acceptor_enabled) {
    log('Astept — jocurile pot rula fara acceptor.');
    await new Promise(function () {});
    return;
  }

  if (cfg.simulate) {
    await runSimulate(cfg);
    return;
  }

  if (cfg.device_type === 'uba') {
    try {
      const { runUbaId003 } = require('./uba-id003');
      await runUbaId003(cfg, {
        log: log,
        resolveAmount: resolveAmount,
        postMoneyIn: postMoneyIn,
        postStackerReset: postStackerReset
      });
      return;
    } catch (error) {
      log('UBA esuat: ' + (error.message || error));
      log('Incerc ITL eSSP pe ' + cfg.com_port + '...');
    }
  }

  try {
    await runEncryptedSerial(cfg);
    return;
  } catch (error) {
    log('eSSP criptat esuat: ' + (error.message || error));
    log('Incerc ITL NV fara criptare...');
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }

  await runPlainSerial(cfg);
}

main().catch((error) => {
  console.error(error.message || error);
  if (String(error.message || error).includes('DH')) {
    console.error('Eroare DH: actualizeaza itl-bridge (fisierul patch-essp-dh.js) si ruleaza din nou start.bat.');
  }
  console.error('Daca portul e ocupat: inchide Validator Manager, apoi start.bat din nou.');
  process.exit(1);
});
