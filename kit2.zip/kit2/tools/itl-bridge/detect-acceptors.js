'use strict';

const { SspHost } = require('./ssp');
const { openSerialPort, closeSerialPort, listSerialPorts } = require('./serial-util');

const UBA_SYNC = 0xfc;
const UBA_STATUS_REQ = 0x11;
const UBA_ACK = 0x50;
const UBA_IDLE = 0x11;
const UBA_INHIBIT = 0x1a;
const UBA_INITIALIZE = 0x1b;
const UBA_POW_UP = 0x40;

const UBA_CRC_TABLE = [
  0x0000, 0x1189, 0x2312, 0x329b, 0x4624, 0x57ad, 0x6536, 0x74bf,
  0x8c48, 0x9dc1, 0xaf5a, 0xbed3, 0xca6c, 0xdbe5, 0xe97e, 0xf8f7,
  0x1081, 0x0108, 0x3393, 0x221a, 0x56a5, 0x472c, 0x75b7, 0x643e,
  0x9cc9, 0x8d40, 0xbfdb, 0xae52, 0xdaed, 0xcb64, 0xf9ff, 0xe876,
  0x2102, 0x308b, 0x0210, 0x1399, 0x6726, 0x76af, 0x4434, 0x55bd,
  0xad4a, 0xbcc3, 0x8e58, 0x9fd1, 0xeb6e, 0xfae7, 0xc87c, 0xd9f5,
  0x3183, 0x200a, 0x1291, 0x0318, 0x77a7, 0x662e, 0x54b5, 0x453c,
  0xbdcb, 0xac42, 0x9ed9, 0x8f50, 0xfbef, 0xea66, 0xd8fd, 0xc974,
  0x4204, 0x538d, 0x6116, 0x709f, 0x0420, 0x15a9, 0x2732, 0x36bb,
  0xce4c, 0xdfc5, 0xed5e, 0xfcd7, 0x8868, 0x99e1, 0xab7a, 0xbaf3,
  0x5285, 0x430c, 0x7197, 0x601e, 0x14a1, 0x0528, 0x37b3, 0x263a,
  0xdecd, 0xcf44, 0xfddf, 0xec56, 0x98e9, 0x8960, 0xbbfb, 0xaa72,
  0x6306, 0x728f, 0x4014, 0x519d, 0x2522, 0x34ab, 0x0630, 0x17b9,
  0xef4e, 0xfec7, 0xcc5c, 0xddd5, 0xa96a, 0xb8e3, 0x8a78, 0x9bf1,
  0x7387, 0x620e, 0x5095, 0x411c, 0x35a3, 0x242a, 0x16b1, 0x0738,
  0xffcf, 0xee46, 0xdcdd, 0xcd54, 0xb9eb, 0xa862, 0x9af9, 0x8b70,
  0x8408, 0x9581, 0xa71a, 0xb693, 0xc22c, 0xd3a5, 0xe13e, 0xf0b7,
  0x0840, 0x19c9, 0x2b52, 0x3adb, 0x4e64, 0x5fed, 0x6d76, 0x7cff,
  0x9489, 0x8500, 0xb79b, 0xa612, 0xd2ad, 0xc324, 0xf1bf, 0xe036,
  0x18c1, 0x0948, 0x3bd3, 0x2a5a, 0x5ee5, 0x4f6c, 0x7df7, 0x6c7e,
  0xa50a, 0xb483, 0x8618, 0x9791, 0xe32e, 0xf2a7, 0xc03c, 0xd1b5,
  0x2942, 0x38cb, 0x0a50, 0x1bd9, 0x6f66, 0x7eef, 0x4c74, 0x5dfd,
  0xb58b, 0xa402, 0x9699, 0x8710, 0xf3af, 0xe226, 0xd0bd, 0xc134,
  0x39c3, 0x284a, 0x1ad1, 0x0b58, 0x7fe7, 0x6e6e, 0x5cf5, 0x4d7c,
  0xc60c, 0xd785, 0xe51e, 0xf497, 0x8028, 0x91a1, 0xa33a, 0xb2b3,
  0x4a44, 0x5bcd, 0x6956, 0x78df, 0x0c60, 0x1de9, 0x2f72, 0x3efb,
  0xd68d, 0xc704, 0xf59f, 0xe416, 0x90a9, 0x8120, 0xb3bb, 0xa232,
  0x5ac5, 0x4b4c, 0x79d7, 0x685e, 0x1ce1, 0x0d68, 0x3ff3, 0x2e7a,
  0xe70e, 0xf687, 0xc41c, 0xd595, 0xa12a, 0xb0a3, 0x8238, 0x93b1,
  0x6b46, 0x7acf, 0x4854, 0x59dd, 0x2d62, 0x3ceb, 0x0e70, 0x1ff9,
  0xf78f, 0xe606, 0xd49d, 0xc514, 0xb1ab, 0xa022, 0x92b9, 0x8330,
  0x7bc7, 0x6a4e, 0x58d5, 0x495c, 0x3de3, 0x2c6a, 0x1ef1, 0x0f78
];

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function crcKermit(buf) {
  let crc = 0;
  for (let i = 0; i < buf.length; i += 1) {
    crc = (crc >> 8) ^ UBA_CRC_TABLE[(crc ^ buf[i]) & 0xff];
  }
  return Buffer.from([crc & 0xff, (crc >> 8) & 0xff]);
}

function openPort(comPath, options) {
  return openSerialPort(comPath, options);
}

function closePort(port) {
  return closeSerialPort(port);
}

function portMeta(p) {
  return {
    path: p.path,
    manufacturer: p.manufacturer || '',
    friendlyName: p.friendlyName || p.productId || '',
    pnpId: p.pnpId || '',
    vendorId: p.vendorId || '',
    productId: p.productId || '',
    label: [p.path, p.manufacturer, p.friendlyName, p.pnpId].filter(Boolean).join(' — ')
  };
}

function isNoisePort(meta) {
  const blob = [meta.manufacturer, meta.friendlyName, meta.pnpId, meta.path].join(' ').toLowerCase();
  if (/bluetooth|bthmodem|standard serial over bluetooth|com0com|virtual.*null/i.test(blob)) {
    return true;
  }
  if (/communications port|port de comunica|16550|standard port types/.test(blob) && !/usb|ftdi|prolific|ch340|cp210|itl|innovative/.test(blob)) {
    return true;
  }
  return false;
}

function hintScore(meta) {
  const blob = [meta.manufacturer, meta.friendlyName, meta.pnpId].join(' ').toLowerCase();
  let itl = 0;
  let uba = 0;
  if (/innovative|itl|nv9|nv10|nv11|nv200|smart.?payout|bank.?note/i.test(blob)) itl += 40;
  if (/jcm|uba|id-?003|global.?bill/i.test(blob)) uba += 40;
  if (/ftdi|prolific|wch|ch340|silicon.?labs|cp210|usb.?serial|usb.?to.?serial/i.test(blob)) {
    itl += 8;
    uba += 8;
  }
  return { itl, uba };
}

function deviceLabel(type) {
  return type === 'uba' ? 'JCM UBA-10 (ID-003)' : 'ITL eSSP';
}

async function listPorts() {
  const raw = await listSerialPorts();
  return (raw || []).map(portMeta).filter((p) => p.path);
}

function isItlOk(reply) {
  if (!reply || !Array.isArray(reply.data) || !reply.data.length) {
    return false;
  }
  const code = Number(reply.data[0]);
  return code === 0xf0 || code === 0xf8 || code === 0xf5 || code === 0xf1;
}

async function probeItl(comPath, signal) {
  const configs = [
    { stopBits: 2, parity: 'none' },
    { stopBits: 1, parity: 'none' }
  ];
  for (let i = 0; i < configs.length; i += 1) {
    if (isCancelled(signal)) {
      return { ok: false, device_type: 'itl' };
    }
    let port = null;
    try {
      port = await openPort(comPath, {
        baudRate: 9600,
        dataBits: 8,
        stopBits: configs[i].stopBits,
        parity: configs[i].parity
      });
      await sleep(1500);
      if (isCancelled(signal)) {
        await closePort(port);
        return { ok: false, device_type: 'itl' };
      }
      const host = new SspHost(port);
      let reply = null;
      for (let t = 0; t < 5; t += 1) {
        if (isCancelled(signal)) {
          await closePort(port);
          return { ok: false, device_type: 'itl' };
        }
        reply = await host.sync();
        if (isItlOk(reply)) {
          await closePort(port);
          return {
            ok: true,
            device_type: 'itl',
            confidence: Number(reply.data[0]) === 0xf0 ? 95 : 88,
            detail: 'eSSP SYNC 0x' + Number(reply.data[0]).toString(16) + ' (8N' + configs[i].stopBits + ')',
            serial: configs[i]
          };
        }
        await sleep(350);
      }
      await closePort(port);
      port = null;
      await sleep(250);
    } catch (error) {
      await closePort(port);
      await sleep(150);
    }
  }
  return { ok: false, device_type: 'itl' };
}

async function readUbaResponse(port, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let rx = Buffer.alloc(0);

  const readMore = () => new Promise((resolve) => {
    const onData = (chunk) => {
      rx = Buffer.concat([rx, chunk]);
      cleanup();
      resolve(true);
    };
    const timer = setTimeout(() => {
      cleanup();
      resolve(false);
    }, Math.max(40, deadline - Date.now()));
    const cleanup = () => {
      clearTimeout(timer);
      port.removeListener('data', onData);
    };
    port.on('data', onData);
    if (rx.length > 0) {
      cleanup();
      resolve(true);
    }
  });

  while (Date.now() < deadline) {
    if (rx.length < 2) {
      const got = await readMore();
      if (!got && rx.length < 2) {
        return null;
      }
      continue;
    }
    let offset = 0;
    while (offset < rx.length && rx[offset] !== UBA_SYNC) {
      offset += 1;
    }
    if (offset > 0) {
      rx = rx.slice(offset);
    }
    if (rx.length < 2) continue;
    const totalLen = rx[1];
    if (totalLen < 5 || totalLen > 80) {
      rx = rx.slice(1);
      continue;
    }
    if (rx.length < totalLen) {
      const got = await readMore();
      if (!got && rx.length < totalLen) {
        return null;
      }
      continue;
    }
    const frame = rx.slice(0, totalLen);
    const body = frame.slice(0, totalLen - 2);
    const crc = frame.slice(totalLen - 2);
    if (!crc.equals(crcKermit(body))) {
      rx = rx.slice(1);
      continue;
    }
    return { cmd: frame[2], data: frame.slice(3, totalLen - 2) };
  }
  return null;
}

function isCancelled(signal) {
  return !!(signal && signal.cancelled);
}

function isUbaStatus(cmd) {
  if (cmd == null) return false;
  if (cmd === UBA_ACK || cmd === UBA_IDLE || cmd === UBA_INHIBIT || cmd === UBA_INITIALIZE) return true;
  if (cmd === UBA_POW_UP || cmd === 0x41 || cmd === 0x42 || cmd === 0x43 || cmd === 0x44) return true;
  return false;
}

async function probeUba(comPath, signal) {
  const parities = ['even', 'none'];
  for (let i = 0; i < parities.length; i += 1) {
    if (isCancelled(signal)) {
      return { ok: false, device_type: 'uba' };
    }
    let port = null;
    try {
      port = await openPort(comPath, {
        baudRate: 9600,
        dataBits: 8,
        stopBits: 1,
        parity: parities[i]
      });
      await sleep(250);
      if (isCancelled(signal)) {
        await closePort(port);
        return { ok: false, device_type: 'uba' };
      }
      const message = Buffer.from([UBA_SYNC, 5, UBA_STATUS_REQ]);
      const full = Buffer.concat([message, crcKermit(message)]);
      await new Promise((resolve, reject) => {
        port.write(full, (err) => {
          if (err) reject(err);
          else port.drain((e2) => (e2 ? reject(e2) : resolve()));
        });
      });
      const res = await readUbaResponse(port, 900);
      await closePort(port);
      port = null;
      if (res && isUbaStatus(res.cmd)) {
        return {
          ok: true,
          device_type: 'uba',
          confidence: res.cmd === UBA_IDLE || res.cmd === UBA_INHIBIT ? 94 : 85,
          detail: 'ID-003 status 0x' + Number(res.cmd).toString(16) + ' (parity ' + parities[i] + ')',
          serial: { parity: parities[i] }
        };
      }
    } catch (error) {
      await closePort(port);
    }
  }
  return { ok: false, device_type: 'uba' };
}

async function probePort(meta, signal) {
  const hints = hintScore(meta);
  if (isCancelled(signal)) {
    return {
      ok: false,
      com_port: meta.path,
      device_type: null,
      confidence: 0,
      detail: 'Anulat',
      label: meta.label,
      manufacturer: meta.manufacturer,
      friendlyName: meta.friendlyName,
      attempts: []
    };
  }

  const itl = await probeItl(meta.path, signal);
  if (itl.ok) {
    return {
      ok: true,
      com_port: meta.path,
      device_type: 'itl',
      confidence: Math.min(99, Number(itl.confidence || 0) + Math.min(20, hints.itl)),
      detail: itl.detail || '',
      serial: itl.serial || null,
      label: meta.label,
      manufacturer: meta.manufacturer,
      friendlyName: meta.friendlyName
    };
  }

  if (hints.itl >= 40) {
    return {
      ok: false,
      com_port: meta.path,
      device_type: null,
      confidence: 0,
      detail: 'ITL pe acest COM nu a raspuns inca (port ocupat sau reset)',
      label: meta.label,
      manufacturer: meta.manufacturer,
      friendlyName: meta.friendlyName,
      attempts: [itl]
    };
  }

  await sleep(400);
  const uba = await probeUba(meta.path, signal);
  if (uba.ok) {
    return {
      ok: true,
      com_port: meta.path,
      device_type: 'uba',
      confidence: Math.min(99, Number(uba.confidence || 0) + Math.min(20, hints.uba)),
      detail: uba.detail || '',
      serial: uba.serial || null,
      label: meta.label,
      manufacturer: meta.manufacturer,
      friendlyName: meta.friendlyName
    };
  }

  return {
    ok: false,
    com_port: meta.path,
    device_type: null,
    confidence: 0,
    detail: 'Niciun raspuns ITL/UBA',
    label: meta.label,
    manufacturer: meta.manufacturer,
    friendlyName: meta.friendlyName,
    attempts: [itl, uba]
  };
}

async function detectAcceptors(options) {
  const opts = options || {};
  const ports = await listPorts();
  const candidates = ports.filter((p) => !isNoisePort(p)).sort((a, b) => {
    const sa = hintScore(a);
    const sb = hintScore(b);
    return (sb.itl + sb.uba) - (sa.itl + sa.uba);
  });
  const skipped = ports.filter((p) => isNoisePort(p)).map((p) => p.path);
  const found = [];
  const scanned = [];

  for (let i = 0; i < candidates.length; i += 1) {
    if (typeof opts.onProgress === 'function') {
      opts.onProgress(candidates[i], i + 1, candidates.length);
    }
    if (isCancelled(opts.signal)) {
      break;
    }
    const result = await probePort(candidates[i], opts.signal);
    scanned.push(result);
    if (result.ok) {
      found.push(result);
      break;
    }
  }

  found.sort((a, b) => b.confidence - a.confidence);
  const best = found[0] || null;

  return {
    ok: found.length > 0,
    ports: candidates,
    skipped,
    scanned,
    found,
    best,
    summary: best
      ? (deviceLabel(best.device_type) + ' pe ' + best.com_port + ' (' + best.confidence + '%)')
      : 'Niciun acceptor detectat'
  };
}

function printReport(report) {
  console.log('');
  console.log('========================================');
  console.log('  IQWIN — Detectie acceptori');
  console.log('========================================');
  console.log('');
  if (!report.ports.length) {
    console.log('Niciun port COM gasit.');
    console.log('');
    return;
  }
  console.log('Porturi scanate: ' + report.ports.length);
  report.scanned.forEach((row) => {
    if (row.ok) {
      console.log('  [OK] ' + row.com_port + ' → ' + deviceLabel(row.device_type) + ' — ' + row.detail);
    } else {
      console.log('  [--] ' + row.com_port + ' — ' + row.detail);
    }
  });
  if (report.skipped.length) {
    console.log('Ignorate (bluetooth/virtual): ' + report.skipped.join(', '));
  }
  console.log('');
  if (report.best) {
    console.log('Recomandat: ' + report.summary);
  } else {
    console.log('Niciun acceptor gasit. Verifica USB/COM si inchide Validator Manager.');
  }
  console.log('');
}

async function mainCli() {
  const report = await detectAcceptors({
    onProgress: (meta, idx, total) => {
      console.log('Scan ' + idx + '/' + total + ': ' + meta.path + '...');
    }
  });
  printReport(report);
  process.exit(report.ok ? 0 : 2);
}

if (require.main === module) {
  mainCli().catch((error) => {
    console.error('EROARE: ' + (error.message || error));
    process.exit(1);
  });
}

module.exports = {
  listPorts,
  detectAcceptors,
  probePort,
  probeItl,
  probeUba,
  deviceLabel,
  printReport
};
