@echo off
cd /d "%~dp0"
title IQWIN Kit - Stop
if exist bridge.pid (
  set /p BRIDGE_PID=<bridge.pid
  if defined BRIDGE_PID (
    taskkill /F /PID %BRIDGE_PID% >nul 2>nul
  )
  del /f /q bridge.pid >nul 2>nul
)
if exist usb-watch.pid (
  set /p USB_PID=<usb-watch.pid
  if defined USB_PID (
    taskkill /F /PID %USB_PID% >nul 2>nul
  )
  del /f /q usb-watch.pid >nul 2>nul
)
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":17891" ^| findstr "LISTENING"') do (
  taskkill /F /PID %%a >nul 2>nul
)
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Get-CimInstance Win32_Process -Filter \"Name = 'chrome.exe' OR Name = 'msedge.exe'\" | Where-Object { $_.CommandLine -and ($_.CommandLine -like '*chrome-kiosk-profile*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>nul
exit /b 0
