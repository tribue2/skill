'use strict';

const { SerialPort } = require('serialport');

function winComPath(comPath) {
  const raw = String(comPath || '').trim();
  const m = raw.match(/COM(\d{1,3})$/i) || raw.match(/\\\\.\\COM(\d{1,3})$/i);
  if (!m) {
    return raw;
  }
  const n = Number(m[1]);
  if (process.platform === 'win32') {
    return '\\\\.\\COM' + n;
  }
  return 'COM' + n;
}

function openSerialPort(comPath, options) {
  const opts = Object.assign({
    path: winComPath(comPath),
    baudRate: 9600,
    dataBits: 8,
    stopBits: 2,
    parity: 'none',
    autoOpen: false
  }, options || {}, { path: winComPath(comPath) });

  return new Promise((resolve, reject) => {
    const port = new SerialPort(opts);
    port.open((err) => {
      if (err) {
        reject(err);
        return;
      }
      port.set({ dtr: true, rts: true }, () => {
        resolve(port);
      });
    });
  });
}

function closeSerialPort(port) {
  return new Promise((resolve) => {
    if (!port) {
      resolve();
      return;
    }
    if (!port.isOpen) {
      resolve();
      return;
    }
    port.close(() => resolve());
  });
}

async function listSerialPorts() {
  try {
    const ports = await SerialPort.list();
    return ports || [];
  } catch (error) {
    return [];
  }
}

module.exports = {
  SerialPort,
  winComPath,
  openSerialPort,
  closeSerialPort,
  listSerialPorts
};
