@echo off
cd /d "%~dp0"
call "%~dp0stop-kit.bat" %*
