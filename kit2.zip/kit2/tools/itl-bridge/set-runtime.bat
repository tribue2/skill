@echo off
set "IQWIN_NODE="
set "IQWIN_NPM="
if exist "%~dp0runtime\node.exe" (
  set "IQWIN_NODE=%~dp0runtime\node.exe"
  if exist "%~dp0runtime\npm.cmd" set "IQWIN_NPM=%~dp0runtime\npm.cmd"
)
if not defined IQWIN_NODE (
  where node >nul 2>nul
  if not errorlevel 1 set "IQWIN_NODE=node"
)
if not defined IQWIN_NPM (
  where npm >nul 2>nul
  if not errorlevel 1 set "IQWIN_NPM=npm"
)
if not defined IQWIN_NODE (
  echo Lipseste Node.js.
  echo Ruleaza Instaleaza.bat sau kit-ul IQWIN Agent.
  exit /b 1
)
exit /b 0
