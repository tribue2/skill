'use strict';

const STX = 0x7f;
const CMD = {
  RESET: 0x01,
  HOST_PROTOCOL_VERSION: 0x06,
  POLL: 0x07,
  DISABLE: 0x09,
  ENABLE: 0x0a,
  SYNC: 0x11,
  GET_SERIAL_NUMBER: 0x0c,
  SET_INHIBITS: 0x02,
  DISPLAY_ON: 0x03,
  DISPLAY_OFF: 0x04,
  SETUP_REQUEST: 0x05,
  REJECT: 0x08
};

const EVENT = {
  RESET: 0xf1,
  READ: 0xef,
  CREDIT: 0xee,
  REJECTING: 0xed,
  REJECTED: 0xec,
  STACKING: 0xcc,
  STACKED: 0xeb,
  SAFE_JAM: 0xea,
  UNSAFE_JAM: 0xe9,
  DISABLED: 0xe8,
  FRAUD: 0xe6,
  STACKER_FULL: 0xe7,
  CLEARED_FROM_FRONT: 0xe1,
  CLEARED_INTO_CASHBOX: 0xe2,
  CASHBOX_REMOVED: 0xe3,
  CASHBOX_REPLACED: 0xe4
};

function crc16(bytes) {
  let crc = 0xffff;
  for (let i = 0; i < bytes.length; i += 1) {
    crc ^= bytes[i];
    for (let bit = 0; bit < 8; bit += 1) {
      if (crc & 1) {
        crc = (crc >> 1) ^ 0x8408;
      } else {
        crc >>= 1;
      }
    }
  }
  return crc & 0xffff;
}

function buildPacket(seq, dataBytes) {
  const length = dataBytes.length;
  const body = [seq & 0xff, length, ...dataBytes];
  const crc = crc16(body);
  return Buffer.from([STX, ...body, crc & 0xff, (crc >> 8) & 0xff]);
}

function parsePackets(buffer) {
  const packets = [];
  let offset = 0;
  while (offset < buffer.length) {
    if (buffer[offset] !== STX) {
      offset += 1;
      continue;
    }
    if (offset + 3 >= buffer.length) {
      break;
    }
    const length = buffer[offset + 2];
    const total = 1 + 1 + 1 + length + 2;
    if (offset + total > buffer.length) {
      break;
    }
    const frame = buffer.subarray(offset, offset + total);
    const body = frame.subarray(1, frame.length - 2);
    const got = frame[frame.length - 2] | (frame[frame.length - 1] << 8);
    const expect = crc16(body);
    if (got === expect) {
      packets.push({
        seq: frame[1],
        data: Array.from(frame.subarray(3, 3 + length))
      });
      offset += total;
    } else {
      offset += 1;
    }
  }
  return { packets, rest: buffer.subarray(offset) };
}

function extractCredits(pollData, channelMap) {
  const credits = [];
  let i = 0;
  while (i < pollData.length) {
    const code = pollData[i];
    if (code === 0xf0) {
      i += 1;
      continue;
    }
    if (code === EVENT.CREDIT || code === EVENT.READ || code === EVENT.STACKED) {
      const channel = pollData[i + 1] || 0;
      i += 2;
      if (code === EVENT.CREDIT && channel > 0) {
        const amount = Number(channelMap[String(channel)] || channelMap[channel] || 0);
        if (amount > 0) {
          credits.push({ channel, amount });
        }
      }
      continue;
    }
    if (
      code === EVENT.REJECTING ||
      code === EVENT.REJECTED ||
      code === EVENT.STACKING ||
      code === EVENT.DISABLED ||
      code === EVENT.RESET ||
      code === EVENT.SAFE_JAM ||
      code === EVENT.UNSAFE_JAM ||
      code === EVENT.FRAUD ||
      code === EVENT.STACKER_FULL ||
      code === EVENT.CLEARED_FROM_FRONT ||
      code === EVENT.CLEARED_INTO_CASHBOX ||
      code === EVENT.CASHBOX_REMOVED ||
      code === EVENT.CASHBOX_REPLACED
    ) {
      i += 1;
      continue;
    }
    i += 1;
  }
  return credits;
}

function extractCashboxEvents(pollData) {
  const events = [];
  let i = 0;
  while (i < pollData.length) {
    const code = pollData[i];
    if (code === 0xf0) {
      i += 1;
      continue;
    }
    if (code === EVENT.CREDIT || code === EVENT.READ || code === EVENT.STACKED) {
      i += 2;
      continue;
    }
    if (code === EVENT.CASHBOX_REMOVED) {
      events.push('removed');
      i += 1;
      continue;
    }
    if (code === EVENT.CASHBOX_REPLACED) {
      events.push('replaced');
      i += 1;
      continue;
    }
    i += 1;
  }
  return events;
}

class SspHost {
  constructor(port) {
    this.port = port;
    this.seq = 0x00;
    this.rx = Buffer.alloc(0);
    this.port.on('data', (chunk) => {
      this.rx = Buffer.concat([this.rx, chunk]);
    });
  }

  nextSeq() {
    this.seq ^= 0x80;
    return this.seq;
  }

  async sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async drain(ms = 40) {
    await this.sleep(ms);
    const buf = this.rx;
    this.rx = Buffer.alloc(0);
    return buf;
  }

  async sendCommand(dataBytes, waitMs = 250) {
    this.rx = Buffer.alloc(0);
    const packet = buildPacket(this.nextSeq(), dataBytes);
    await new Promise((resolve, reject) => {
      this.port.write(packet, (err) => (err ? reject(err) : resolve()));
    });
    const deadline = Date.now() + waitMs;
    while (Date.now() < deadline) {
      const parsed = parsePackets(this.rx);
      if (parsed.packets.length) {
        this.rx = parsed.rest;
        return parsed.packets[0];
      }
      await this.sleep(20);
    }
    const parsed = parsePackets(this.rx);
    this.rx = parsed.rest;
    return parsed.packets[0] || null;
  }

  async sync() {
    return this.sendCommand([CMD.SYNC], 400);
  }

  async enable() {
    await this.sendCommand([CMD.SET_INHIBITS, 0xff, 0xff], 250);
    try {
      await this.sendCommand([CMD.DISPLAY_ON], 200);
    } catch (error) {}
    return this.sendCommand([CMD.ENABLE], 250);
  }

  async disable() {
    return this.sendCommand([CMD.DISABLE], 120);
  }

  async poll() {
    const reply = await this.sendCommand([CMD.POLL], 80);
    if (!reply || !reply.data || !reply.data.length) {
      return [];
    }
    return reply.data;
  }
}

module.exports = {
  SspHost,
  extractCredits,
  extractCashboxEvents,
  CMD,
  EVENT
};
