'use strict';

const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

const ROOT = __dirname;

function findBrowser() {
  const chrome = [
    path.join(process.env.ProgramFiles || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(process.env['ProgramFiles(x86)'] || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(process.env.LOCALAPPDATA || '', 'Google', 'Chrome', 'Application', 'chrome.exe')
  ];
  const edge = [
    path.join(process.env['ProgramFiles(x86)'] || '', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(process.env.ProgramFiles || '', 'Microsoft', 'Edge', 'Application', 'msedge.exe')
  ];
  for (let i = 0; i < chrome.length; i += 1) {
    if (chrome[i] && fs.existsSync(chrome[i])) {
      return { path: chrome[i], edge: false };
    }
  }
  for (let i = 0; i < edge.length; i += 1) {
    if (edge[i] && fs.existsSync(edge[i])) {
      return { path: edge[i], edge: true };
    }
  }
  return null;
}

function getScreens() {
  const ps = [
    'Add-Type -AssemblyName System.Windows.Forms;',
    '$list = @();',
    'foreach ($s in [System.Windows.Forms.Screen]::AllScreens) {',
    '  $b = $s.Bounds;',
    '  $list += [ordered]@{ primary = [bool]$s.Primary; x = [int]$b.X; y = [int]$b.Y; w = [int]$b.Width; h = [int]$b.Height };',
    '}',
    '($list | ConvertTo-Json -Compress)'
  ].join(' ');

  const result = spawnSync(
    'powershell.exe',
    ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps],
    { encoding: 'utf8', windowsHide: true }
  );

  if (result.status !== 0 || !result.stdout) {
    return [{ primary: true, x: 0, y: 0, w: 1920, h: 1080 }];
  }

  try {
    const parsed = JSON.parse(String(result.stdout).trim());
    const list = Array.isArray(parsed) ? parsed : [parsed];
    return list.map((s) => ({
      primary: !!s.primary,
      x: Number(s.x) || 0,
      y: Number(s.y) || 0,
      w: Number(s.w) || 1920,
      h: Number(s.h) || 1080
    }));
  } catch (error) {
    return [{ primary: true, x: 0, y: 0, w: 1920, h: 1080 }];
  }
}

function killOldKiosk() {
  const ps = [
    "Get-CimInstance Win32_Process -Filter \"Name = 'chrome.exe' OR Name = 'msedge.exe'\" |",
    " Where-Object { $_.CommandLine -and ($_.CommandLine -like '*chrome-kiosk-profile*') } |",
    ' ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }'
  ].join('');
  spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps], {
    windowsHide: true
  });
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function startKiosk(browser, url, screen, dataDir) {
  const args = [
    '--user-data-dir=' + dataDir,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-infobars',
    '--disable-session-crashed-bubble',
    '--disable-restore-session-state',
    '--disable-features=TranslateUI,InfiniteSessionRestore',
    '--autoplay-policy=no-user-gesture-required',
    '--allow-running-insecure-content',
    '--disable-features=TranslateUI,InfiniteSessionRestore,BlockInsecurePrivateNetworkRequests',
    '--window-position=' + screen.x + ',' + screen.y,
    '--window-size=' + screen.w + ',' + screen.h
  ];

  if (browser.edge) {
    args.push('--kiosk', '--edge-kiosk-type=fullscreen', url);
  } else {
    args.push('--kiosk', url);
  }

  const child = spawn(browser.path, args, {
    detached: true,
    stdio: 'ignore',
    windowsHide: false
  });
  if (!child || !child.pid) {
    throw new Error('Nu pot porni browserul kiosk');
  }
  child.unref();
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function launchDual(options) {
  const opts = options || {};
  const gamesUrl = opts.gamesUrl || 'http://127.0.0.1:17891/boot';
  const topUrl = opts.topUrl || 'http://127.0.0.1:17891/boot-top';
  const browser = findBrowser();

  if (!browser) {
    spawnSync('cmd.exe', ['/c', 'start', '', gamesUrl], { windowsHide: true });
    await sleep(1000);
    spawnSync('cmd.exe', ['/c', 'start', '', topUrl], { windowsHide: true });
    return true;
  }

  const profileGames = path.join(ROOT, 'chrome-kiosk-profile-games');
  const profileTop = path.join(ROOT, 'chrome-kiosk-profile-top');
  ensureDir(profileGames);
  ensureDir(profileTop);

  killOldKiosk();
  await sleep(500);

  const screens = getScreens();
  const primary = screens.find((s) => s.primary) || screens[0];
  const secondary = screens.find((s) => !s.primary) || null;

  console.log('Monitoare: ' + screens.length);
  console.log('Jocuri: ' + primary.w + 'x' + primary.h + ' @ ' + primary.x + ',' + primary.y);
  startKiosk(browser, gamesUrl, primary, profileGames);

  await sleep(2000);

  if (secondary) {
    console.log('Ecran info: ' + secondary.w + 'x' + secondary.h + ' @ ' + secondary.x + ',' + secondary.y);
    startKiosk(browser, topUrl, secondary, profileTop);
  } else {
    const fallback = {
      x: primary.x + primary.w,
      y: primary.y,
      w: primary.w,
      h: primary.h
    };
    console.log('Un singur monitor - ecran info offset');
    startKiosk(browser, topUrl, fallback, profileTop);
  }

  console.log('Dual kiosk lansat.');
  return true;
}

module.exports = { launchDual };

if (require.main === module) {
  launchDual({
    gamesUrl: process.argv[2] || 'http://127.0.0.1:17891/boot',
    topUrl: process.argv[3] || 'http://127.0.0.1:17891/boot-top'
  }).then(() => process.exit(0)).catch((error) => {
    console.error(error.message || error);
    process.exit(1);
  });
}
