'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawn, spawnSync } = require('child_process');

const ROOT = __dirname;
const CONFIG_PATH = path.join(ROOT, 'config.json');

function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    return null;
  }
  try {
    const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    if (!cfg || !cfg.server_url || !cfg.terminal_code || !cfg.api_secret) {
      return null;
    }
    return cfg;
  } catch (error) {
    return null;
  }
}

function stopKit() {
  const stopBat = path.join(ROOT, 'stop-kit.bat');
  if (fs.existsSync(stopBat)) {
    spawnSync('cmd.exe', ['/c', stopBat], {
      cwd: ROOT,
      stdio: 'ignore',
      windowsHide: true
    });
  }
}

function startBridge() {
  const child = spawn(process.execPath, [path.join(ROOT, 'bridge.js')], {
    cwd: ROOT,
    detached: true,
    stdio: 'ignore',
    windowsHide: true
  });
  child.unref();
}

function waitForBridge(port, timeoutMs) {
  const started = Date.now();
  return new Promise((resolve) => {
    const tick = () => {
      const req = http.get(
        {
          host: '127.0.0.1',
          port,
          path: '/credentials',
          timeout: 1000
        },
        (res) => {
          res.resume();
          if (res.statusCode === 200) {
            resolve(true);
            return;
          }
          retry();
        }
      );
      req.on('error', retry);
      req.on('timeout', () => {
        req.destroy();
        retry();
      });
    };

    const retry = () => {
      if (Date.now() - started >= timeoutMs) {
        resolve(false);
        return;
      }
      setTimeout(tick, 400);
    };

    tick();
  });
}

function buildBridgeLaunchUrl(cfg, next) {
  const data = {
    ok: true,
    server_url: cfg.server_url,
    terminal_code: cfg.terminal_code,
    api_secret: cfg.api_secret,
    terminal_name: cfg.terminal_name || '',
    com_port: cfg.com_port || '',
    bridge: true
  };
  const token = Buffer.from(JSON.stringify(data), 'utf8').toString('base64');
  const server = String(cfg.server_url || 'https://iqwin.eu').replace(/\/$/, '');
  return server + '/app/bridge-link.php?next=' + encodeURIComponent(next) + '#iqwin=' + encodeURIComponent(token);
}

async function launchDual(port, cfg) {
  const gamesUrl = buildBridgeLaunchUrl(cfg, 'games');
  const topUrl = buildBridgeLaunchUrl(cfg, 'top');
  console.log('Ecran 1: ' + String(cfg.server_url).replace(/\/$/, '') + '/app/index.php');
  console.log('Ecran 2: ' + String(cfg.server_url).replace(/\/$/, '') + '/app/top-display.php');
  try {
    const launcher = require('./launch-dual');
    return await launcher.launchDual({ gamesUrl: gamesUrl, topUrl: topUrl });
  } catch (error) {
    console.error('Lansare dual: ' + (error.message || error));
    return false;
  }
}

function ensureDesktopShortcut() {
  try {
    spawnSync(
      'powershell.exe',
      [
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-Command',
        [
          "$ws = New-Object -ComObject WScript.Shell;",
          "$desktop = [Environment]::GetFolderPath('Desktop');",
          "$shortcut = $ws.CreateShortcut((Join-Path $desktop 'IQWIN Agent.lnk'));",
          "$shortcut.TargetPath = '" + path.join(ROOT, 'start-kit.bat').replace(/'/g, "''") + "';",
          "$shortcut.WorkingDirectory = '" + ROOT.replace(/'/g, "''") + "';",
          '$shortcut.WindowStyle = 1;',
          '$shortcut.Save()'
        ].join(' ')
      ],
      { windowsHide: true }
    );
  } catch (error) {}
}

async function main() {
  const args = process.argv.slice(2);
  const forcePair = args.includes('--pair') || args.includes('--install');
  const skipLaunch = args.includes('--bridge-only');
  const detectOnly = args.includes('--detect');

  console.log('');
  console.log('========================================');
  console.log('  IQWIN Agent');
  console.log('========================================');
  console.log('');

  if (detectOnly) {
    const { detectAcceptors, printReport } = require('./detect-acceptors');
    const report = await detectAcceptors({
      onProgress: (meta, idx, total) => {
        console.log('Scan ' + idx + '/' + total + ': ' + meta.path + '...');
      }
    });
    printReport(report);
    process.exit(report.ok ? 0 : 2);
  }

  let cfg = loadConfig();
  if (forcePair || !cfg) {
    console.log(cfg ? 'Reconfigurare pairing...' : 'Pairing necesar (prima rulare)...');
    console.log('Se deschide fereastra: cod pairing + COM + model acceptor...');
    console.log('');
    try {
      const { runPairUi } = require('./pair-ui');
      cfg = await runPairUi({ serverUrl: 'https://iqwin.eu' });
    } catch (error) {
      console.error('Pairing esuat: ' + (error.message || error));
      process.exit(1);
    }
    if (!cfg || !cfg.terminal_code || !cfg.api_secret) {
      console.error('Config invalid dupa pairing.');
      process.exit(1);
    }
    ensureDesktopShortcut();
    console.log('Pairing OK. Pornesc terminalul...');
    console.log('');
  }

  const port = Math.max(1024, Number(cfg.local_port || 17891));

  console.log('Opresc instante anterioare...');
  stopKit();
  await new Promise((r) => setTimeout(r, 500));

  console.log('Pornesc acceptorul...');
  startBridge();

  console.log('Astept bridge local pe port ' + port + '...');
  const ready = await waitForBridge(port, 30000);
  if (!ready) {
    console.error('Bridge-ul nu a pornit la timp.');
    console.error('Verifica COM / Validator Manager / config.json');
    process.exit(1);
  }

  console.log('Bridge OK.');

  if (skipLaunch) {
    console.log('Mod --bridge-only: fara kiosk.');
    process.exit(0);
  }

  console.log('Deschid dual fullscreen (jocuri + ecran info)...');
  const launched = await launchDual(port, cfg);
  if (!launched) {
    console.error('Lansarea dual a esuat.');
    process.exit(1);
  }

  console.log('');
  console.log('Gata: 2 ecrane fullscreen' + (cfg.acceptor_enabled ? ' + acceptor.' : ' (fara acceptor).'));
  console.log('Oprire: stop-kit.bat');
  console.log('');
  process.exit(0);
}

main().catch((error) => {
  console.error('EROARE: ' + (error.message || error));
  process.exit(1);
});
