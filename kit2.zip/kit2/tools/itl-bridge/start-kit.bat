@echo off
cd /d "%~dp0"
title IQWIN Agent
setlocal EnableExtensions

echo.
echo ========================================
echo   IQWIN Agent
echo   Pairing + acceptor + dual fullscreen
echo ========================================
echo.

call "%~dp0set-runtime.bat"
if errorlevel 1 (
  pause
  exit /b 1
)

if not exist node_modules\@toopago (
  if not exist node_modules\serialport (
    echo Instalez dependentele...
    if defined IQWIN_NPM (
      call "%IQWIN_NPM%" install --no-fund --no-audit
    ) else (
      call npm install --no-fund --no-audit
    )
    if errorlevel 1 (
      echo npm install a esuat.
      pause
      exit /b 1
    )
  )
)

"%IQWIN_NODE%" agent.js %*
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" (
  echo.
  pause
)
endlocal
exit /b %EXITCODE%
