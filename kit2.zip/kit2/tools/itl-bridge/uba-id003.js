'use strict';

const { openSerialPort, closeSerialPort } = require('./serial-util');

const SYNC = 0xfc;
const ACK = 0x50;
const STATUS_REQ = 0x11;
const RESET = 0x40;
const STACK_1 = 0x41;
const STACK_2 = 0x42;
const RETURN = 0x43;
const SET_DENOM = 0xc0;
const SET_SECURITY = 0xc1;
const SET_INHIBIT = 0xc3;
const SET_DIRECTION = 0xc4;
const SET_OPT_FUNC = 0xc5;
const SET_BAR_FUNC = 0xc6;
const SET_BAR_INHIBIT = 0xc7;
const GET_VERSION = 0x88;
const GET_DENOM = 0x80;
const GET_INHIBIT = 0x83;

const IDLE = 0x11;
const ACCEPTING = 0x12;
const ESCROW = 0x13;
const STACKING = 0x14;
const VEND_VALID = 0x15;
const STACKED = 0x16;
const REJECTING = 0x17;
const RETURNING = 0x18;
const HOLDING = 0x19;
const INHIBIT = 0x1a;
const INITIALIZE = 0x1b;

const POW_UP = 0x40;
const POW_UP_BIA = 0x41;
const POW_UP_BIS = 0x42;
const STACKER_FULL = 0x43;
const STACKER_OPEN = 0x44;
const INVALID_COMMAND = 0x4b;

const REJECT_REASONS = {
  0x71: 'inserare oblică',
  0x72: 'senzor magnetic',
  0x73: 'hârtie rămasă în cap',
  0x74: 'compensare senzor',
  0x75: 'transport',
  0x76: 'denominație nerecunoscută (firmware / valută greșită?)',
  0x77: 'pattern foto 1',
  0x78: 'nivel foto',
  0x79: 'bancnotă inhibată (DIP / comandă)',
  0x7b: 'operație',
  0x7c: 'hârtie în stacker',
  0x7d: 'lungime',
  0x7e: 'pattern foto 2',
  0x91: 'dublă / foaie nerecunoscută (vechi) — curăță senzori sau verifică firmware valută',
  0x98: 'foi duble',
  0x9b: 'ticket pe dos'
};

function rejectLedFlashes(code) {
  const n = Number(code);
  if (n >= 0x71 && n <= 0x79) return n - 0x70;
  if (n === 0x7b) return 11;
  if (n === 0x7c) return 12;
  if (n === 0x7d) return 13;
  if (n === 0x7e) return 14;
  if (n === 0x7f) return 15;
  if (n === 0x91 || n === 0x98) return 8;
  return 0;
}

function rejectLabel(code) {
  const n = Number(code);
  const flashes = rejectLedFlashes(n);
  const led = flashes > 0 ? ('LED verde x' + flashes + ' · ') : '';
  if (REJECT_REASONS[n]) {
    return led + '0x' + n.toString(16) + ' — ' + REJECT_REASONS[n];
  }
  return led + '0x' + n.toString(16);
}


const CRC_TABLE = [
  0x0000, 0x1189, 0x2312, 0x329b, 0x4624, 0x57ad, 0x6536, 0x74bf,
  0x8c48, 0x9dc1, 0xaf5a, 0xbed3, 0xca6c, 0xdbe5, 0xe97e, 0xf8f7,
  0x1081, 0x0108, 0x3393, 0x221a, 0x56a5, 0x472c, 0x75b7, 0x643e,
  0x9cc9, 0x8d40, 0xbfdb, 0xae52, 0xdaed, 0xcb64, 0xf9ff, 0xe876,
  0x2102, 0x308b, 0x0210, 0x1399, 0x6726, 0x76af, 0x4434, 0x55bd,
  0xad4a, 0xbcc3, 0x8e58, 0x9fd1, 0xeb6e, 0xfae7, 0xc87c, 0xd9f5,
  0x3183, 0x200a, 0x1291, 0x0318, 0x77a7, 0x662e, 0x54b5, 0x453c,
  0xbdcb, 0xac42, 0x9ed9, 0x8f50, 0xfbef, 0xea66, 0xd8fd, 0xc974,
  0x4204, 0x538d, 0x6116, 0x709f, 0x0420, 0x15a9, 0x2732, 0x36bb,
  0xce4c, 0xdfc5, 0xed5e, 0xfcd7, 0x8868, 0x99e1, 0xab7a, 0xbaf3,
  0x5285, 0x430c, 0x7197, 0x601e, 0x14a1, 0x0528, 0x37b3, 0x263a,
  0xdecd, 0xcf44, 0xfddf, 0xec56, 0x98e9, 0x8960, 0xbbfb, 0xaa72,
  0x6306, 0x728f, 0x4014, 0x519d, 0x2522, 0x34ab, 0x0630, 0x17b9,
  0xef4e, 0xfec7, 0xcc5c, 0xddd5, 0xa96a, 0xb8e3, 0x8a78, 0x9bf1,
  0x7387, 0x620e, 0x5095, 0x411c, 0x35a3, 0x242a, 0x16b1, 0x0738,
  0xffcf, 0xee46, 0xdcdd, 0xcd54, 0xb9eb, 0xa862, 0x9af9, 0x8b70,
  0x8408, 0x9581, 0xa71a, 0xb693, 0xc22c, 0xd3a5, 0xe13e, 0xf0b7,
  0x0840, 0x19c9, 0x2b52, 0x3adb, 0x4e64, 0x5fed, 0x6d76, 0x7cff,
  0x9489, 0x8500, 0xb79b, 0xa612, 0xd2ad, 0xc324, 0xf1bf, 0xe036,
  0x18c1, 0x0948, 0x3bd3, 0x2a5a, 0x5ee5, 0x4f6c, 0x7df7, 0x6c7e,
  0xa50a, 0xb483, 0x8618, 0x9791, 0xe32e, 0xf2a7, 0xc03c, 0xd1b5,
  0x2942, 0x38cb, 0x0a50, 0x1bd9, 0x6f66, 0x7eef, 0x4c74, 0x5dfd,
  0xb58b, 0xa402, 0x9699, 0x8710, 0xf3af, 0xe226, 0xd0bd, 0xc134,
  0x39c3, 0x284a, 0x1ad1, 0x0b58, 0x7fe7, 0x6e6e, 0x5cf5, 0x4d7c,
  0xc60c, 0xd785, 0xe51e, 0xf497, 0x8028, 0x91a1, 0xa33a, 0xb2b3,
  0x4a44, 0x5bcd, 0x6956, 0x78df, 0x0c60, 0x1de9, 0x2f72, 0x3efb,
  0xd68d, 0xc704, 0xf59f, 0xe416, 0x90a9, 0x8120, 0xb3bb, 0xa232,
  0x5ac5, 0x4b4c, 0x79d7, 0x685e, 0x1ce1, 0x0d68, 0x3ff3, 0x2e7a,
  0xe70e, 0xf687, 0xc41c, 0xd595, 0xa12a, 0xb0a3, 0x8238, 0x93b1,
  0x6b46, 0x7acf, 0x4854, 0x59dd, 0x2d62, 0x3ceb, 0x0e70, 0x1ff9,
  0xf78f, 0xe606, 0xd49d, 0xc514, 0xb1ab, 0xa022, 0x92b9, 0x8330,
  0x7bc7, 0x6a4e, 0x58d5, 0x495c, 0x3de3, 0x2c6a, 0x1ef1, 0x0f78
];

function crcKermit(buf) {
  let crc = 0;
  for (let i = 0; i < buf.length; i += 1) {
    crc = (crc >> 8) ^ CRC_TABLE[(crc ^ buf[i]) & 0xff];
  }
  return Buffer.from([crc & 0xff, (crc >> 8) & 0xff]);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function denomToChannel(code) {
  const n = Number(code) & 0xff;
  if (n >= 0x61 && n <= 0x68) {
    return n - 0x60;
  }
  if (n >= 1 && n <= 8) {
    return n;
  }
  return 0;
}

function waitCmdOk(res, command) {
  if (!res || res.cmd == null) return false;
  if (res.cmd === ACK || res.cmd === command) return true;
  if (command === STACK_1 || command === STACK_2) {
    return res.cmd === STACKING || res.cmd === STACKED || res.cmd === VEND_VALID;
  }
  if (command === RETURN) {
    return res.cmd === RETURNING || res.cmd === REJECTING || res.cmd === IDLE;
  }
  if (command === SET_INHIBIT || command === RESET) {
    return res.cmd === IDLE || res.cmd === INITIALIZE || res.cmd === INHIBIT;
  }
  return false;
}

class Id003Link {
  constructor(port) {
    this.port = port;
    this.rx = Buffer.alloc(0);
    this.waiters = [];
    this.port.on('data', (chunk) => this._onData(chunk));
    this.port.on('error', (err) => {
      const waiters = this.waiters.slice();
      this.waiters = [];
      waiters.forEach((w) => w.reject(err));
    });
  }

  _onData(chunk) {
    if (!chunk || !chunk.length) return;
    this.rx = Buffer.concat([this.rx, chunk]);
    this._pump();
  }

  _pump() {
    while (this.waiters.length > 0) {
      const w = this.waiters[0];
      if (this.rx.length < w.size) return;
      const out = this.rx.slice(0, w.size);
      this.rx = this.rx.slice(w.size);
      this.waiters.shift();
      clearTimeout(w.timer);
      w.resolve(out);
    }
  }

  clear() {
    this.rx = Buffer.alloc(0);
  }

  readExact(size, timeoutMs) {
    return new Promise((resolve, reject) => {
      if (this.rx.length >= size) {
        const out = this.rx.slice(0, size);
        this.rx = this.rx.slice(size);
        resolve(out);
        return;
      }
      const waiter = {
        size: size,
        resolve: resolve,
        reject: reject,
        timer: setTimeout(() => {
          const idx = this.waiters.indexOf(waiter);
          if (idx >= 0) this.waiters.splice(idx, 1);
          if (this.rx.length === 0) {
            resolve(null);
            return;
          }
          reject(new Error('Timeout citire ID-003 (' + this.rx.length + '/' + size + ')'));
        }, timeoutMs)
      };
      this.waiters.push(waiter);
    });
  }

  write(buf) {
    return new Promise((resolve, reject) => {
      this.port.write(buf, (err) => {
        if (err) {
          reject(err);
          return;
        }
        this.port.drain((drainErr) => {
          if (drainErr) reject(drainErr);
          else resolve();
        });
      });
    });
  }

  async sendCommand(command, data) {
    const payload = Buffer.isBuffer(data) ? data : Buffer.from(data || []);
    const length = 5 + payload.length;
    const message = Buffer.concat([Buffer.from([SYNC, length, command]), payload]);
    const full = Buffer.concat([message, crcKermit(message)]);
    this.clear();
    await this.write(full);
  }

  async readResponse(timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const left = Math.max(50, deadline - Date.now());
      const start = await this.readExact(1, left);
      if (!start) {
        return { cmd: null, data: Buffer.alloc(0) };
      }
      if (start[0] === 0x00) {
        return { cmd: 0x00, data: Buffer.alloc(0) };
      }
      if (start[0] !== SYNC) {
        continue;
      }

      const left2 = Math.max(50, deadline - Date.now());
      const lenBuf = await this.readExact(1, left2);
      if (!lenBuf) {
        return { cmd: null, data: Buffer.alloc(0) };
      }
      const totalLen = lenBuf[0];
      if (totalLen < 5 || totalLen > 80) {
        continue;
      }
      const dataLen = totalLen - 5;
      const left3 = Math.max(50, deadline - Date.now());
      const rest = await this.readExact(1 + dataLen + 2, left3);
      if (!rest) {
        return { cmd: null, data: Buffer.alloc(0) };
      }
      const cmd = rest[0];
      const data = rest.slice(1, 1 + dataLen);
      const crc = rest.slice(1 + dataLen, 1 + dataLen + 2);
      const body = Buffer.concat([start, lenBuf, rest.slice(0, 1 + dataLen)]);
      if (!crc.equals(crcKermit(body))) {
        continue;
      }
      return { cmd: cmd, data: data };
    }
    return { cmd: null, data: Buffer.alloc(0) };
  }

  async reqStatus(timeoutMs) {
    await this.sendCommand(STATUS_REQ, []);
    return this.readResponse(timeoutMs);
  }
}

function openPort(comPort, parity) {
  return openSerialPort(comPort, {
    baudRate: 9600,
    dataBits: 8,
    stopBits: 1,
    parity: parity || 'even',
    autoOpen: false
  });
}

function closePort(port) {
  return closeSerialPort(port);
}

async function waitAck(link, command, data, timeoutMs, tries) {
  for (let i = 0; i < tries; i += 1) {
    await link.sendCommand(command, data);
    const res = await link.readResponse(timeoutMs);
    if (waitCmdOk(res, command) && res.cmd !== REJECTING) return true;
    if (res.cmd === INVALID_COMMAND) return false;
    await sleep(150);
  }
  return false;
}

async function initialize(link, log, timeoutMs) {
  const steps = [
    [SET_DENOM, Buffer.from([0x00, 0x00])],
    [SET_SECURITY, Buffer.from([0x00, 0x00])],
    [SET_DIRECTION, Buffer.from([0x00])],
    [SET_OPT_FUNC, Buffer.from([0x00, 0x00])],
    [SET_INHIBIT, Buffer.from([0x00])]
  ];
  for (let i = 0; i < steps.length; i += 1) {
    const cmd = steps[i][0];
    const data = steps[i][1];
    await link.sendCommand(cmd, data);
    const res = await link.readResponse(timeoutMs);
    if (res.cmd !== cmd && res.cmd !== ACK) {
      log('UBA init 0x' + cmd.toString(16) + ' → 0x' + Number(res.cmd == null ? -1 : res.cmd).toString(16));
    }
  }

  try {
    await link.sendCommand(SET_BAR_FUNC, Buffer.from([0x01, 0x12]));
    const bar = await link.readResponse(timeoutMs);
    if (bar.cmd === INVALID_COMMAND) {
      log('UBA fara barcode (OK pentru bancnote)');
    } else {
      await link.sendCommand(SET_BAR_INHIBIT, Buffer.from([0x00]));
      await link.readResponse(timeoutMs);
    }
  } catch (e) {}

  for (let i = 0; i < 40; i += 1) {
    const st = await link.reqStatus(timeoutMs);
    if (st.cmd !== INITIALIZE) break;
    await sleep(200);
  }

  await link.sendCommand(SET_INHIBIT, Buffer.from([0x00]));
  await link.readResponse(timeoutMs);

  const ready = await link.reqStatus(timeoutMs);
  if (ready.cmd === IDLE) {
    log('UBA gata: IDLE (accepta bancnote)');
  } else if (ready.cmd === INHIBIT) {
    log('UBA inca INHIBIT dupa init — retrimit enable');
    await waitAck(link, SET_INHIBIT, Buffer.from([0x00]), timeoutMs, 5);
  } else {
    log('UBA status dupa init: 0x' + Number(ready.cmd == null ? -1 : ready.cmd).toString(16));
  }
}

async function forceEnableAll(link, log, timeoutMs) {
  await link.sendCommand(SET_DENOM, Buffer.from([0x00, 0x00]));
  await link.readResponse(timeoutMs);
  await link.sendCommand(SET_DIRECTION, Buffer.from([0x00]));
  await link.readResponse(timeoutMs);
  await link.sendCommand(SET_INHIBIT, Buffer.from([0x00]));
  await link.readResponse(timeoutMs);
  log('UBA re-enable: toate denoms + host ACCEPTA');
}

async function logDeviceConfig(link, log, timeoutMs) {
  try {
    await link.sendCommand(GET_VERSION, []);
    const ver = await link.readResponse(timeoutMs);
    if (ver.data && ver.data.length) {
      const text = ver.data.toString('ascii').replace(/[^\x20-\x7e]/g, '').trim();
      log('UBA firmware: ' + text);
      const cur = text.match(/U\(([A-Z]{3})\)/i);
      if (cur) {
        const code = cur[1].toUpperCase();
        if (code === 'RON' || code === 'ROL' || code === 'ROM') {
          log('Valuta soft: ' + code + ' (OK Romania)');
        } else {
          log('ATENTIE valuta soft: ' + code + ' — foile RON vor fi respinse. Trebuie reflash ROM Romania (AccLoad).');
        }
      } else {
        log('Verifica pe eticheta/firmware daca e soft Romania (RON).');
      }
      if (/20(0\d|1[0-6])/i.test(text)) {
        log('Soft vechi: foile noi (polimer) pot fi respinse — update firmware RON.');
      }
    }
  } catch (e) {}

  try {
    await link.sendCommand(GET_DENOM, []);
    const den = await link.readResponse(timeoutMs);
    if (den.data && den.data.length) {
      const b0 = den.data[0];
      const bits = [];
      let offCount = 0;
      for (let i = 0; i < 8; i += 1) {
        const off = (b0 >> i) & 1;
        if (off) offCount += 1;
        bits.push(('ch' + (i + 1) + '=' + (off ? 'OFF' : 'ON')));
      }
      log('Denom inhibit raw=0x' + b0.toString(16) + ' (' + bits.join(', ') + ')');
      if (offCount >= 7) {
        log('ATENTIE: aproape toate canalele OFF — DIP 1-7 trebuie pe ON (accept), DIP 8 pe OFF (lucru).');
      }
    }
  } catch (e) {}

  try {
    await link.sendCommand(GET_INHIBIT, []);
    const inh = await link.readResponse(timeoutMs);
    if (inh.data && inh.data.length) {
      log('Inhibit host: ' + (inh.data[0] ? 'BLOCT' : 'ACCEPTA'));
    }
  } catch (e) {}

  log('UBA-10-SS checklist: DIP1-7=ON, DIP8=OFF, caseta bagata, soft RON, senzori curati.');
}

async function powerOn(link, log, timeoutMs) {
  let status = null;
  for (let i = 0; i < 25; i += 1) {
    const st = await link.reqStatus(timeoutMs);
    status = st.cmd;
    if (status !== null && status !== 0x00) break;
    await sleep(200);
  }

  if (status == null) {
    throw new Error('UBA nu raspunde pe COM (verifica cablu, alimentare, protocol ID-003)');
  }

  if (status === POW_UP || status === POW_UP_BIA || status === POW_UP_BIS) {
    log('UBA power-up 0x' + status.toString(16));
    await waitAck(link, RESET, [], timeoutMs, 8);
    await sleep(300);
  } else {
    log('UBA status initial: 0x' + status.toString(16));
  }

  let st = await link.reqStatus(timeoutMs);
  if (st.cmd === INHIBIT || st.cmd === POW_UP || st.cmd === POW_UP_BIA || st.cmd === POW_UP_BIS) {
    await waitAck(link, RESET, [], timeoutMs, 8);
    await sleep(200);
  }

  log('UBA initialize (toate canalele ON)...');
  await initialize(link, log, timeoutMs);
  await logDeviceConfig(link, log, timeoutMs);
}

async function openWithParityFallback(comPort, preferredParity, log) {
  const order = preferredParity === 'none'
    ? ['none', 'even']
    : ['even', 'none'];

  let lastError = null;
  for (let i = 0; i < order.length; i += 1) {
    const parity = order[i];
    let port = null;
    try {
      port = await openPort(comPort, parity);
      const link = new Id003Link(port);
      await sleep(120);
      const probe = await link.reqStatus(1500);
      if (probe.cmd != null && probe.cmd !== 0x00) {
        log('Deschis ' + comPort + ' @ 9600 parity=' + parity + ' (ID-003 OK)');
        return { port: port, link: link, parity: parity };
      }
      await closePort(port);
      port = null;
      lastError = new Error('Fara raspuns valid cu parity=' + parity);
    } catch (error) {
      lastError = error;
      if (port) {
        try { await closePort(port); } catch (e) {}
      }
    }
  }
  throw lastError || new Error('Nu pot deschide UBA pe ' + comPort);
}

/**
 * @param {object} cfg
 * @param {{ log: Function, resolveAmount: Function, postMoneyIn: Function, postStackerReset: Function }} hooks
 */
async function runUbaId003(cfg, hooks) {
  const log = hooks.log;
  const timeoutMs = Math.max(800, Number(cfg.uba_timeout_ms || 1500));
  const pollMs = Math.max(120, Number(cfg.poll_ms || 200));
  const stackCmd = String(cfg.uba_stack || '1') === '2' ? STACK_2 : STACK_1;
  const preferredParity = String(cfg.uba_parity || 'even').toLowerCase() === 'none' ? 'none' : 'even';

  log('Dispozitiv: JCM UBA-10-SS (ID-003, 9600 8E1/8N1)');
  log('IMPORTANT: inchide softurile JCM / Validator pe COM.');
  log('DIP pe fata UBA: 1-7 = ON (accept), 8 = OFF (mod lucru).');

  const opened = await openWithParityFallback(cfg.com_port, preferredParity, log);
  const port = opened.port;
  const link = opened.link;

  let pendingChannel = 0;
  let pendingAmount = 0;
  let lastKey = '';
  let lastCashboxResetAt = 0;
  let running = true;

  const shutdown = async () => {
    running = false;
    try {
      await link.sendCommand(SET_INHIBIT, Buffer.from([0x01]));
      await link.readResponse(500);
    } catch (e) {}
    await closePort(port);
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  await powerOn(link, log, timeoutMs);
  log('UBA enable — astept bancnote...');

  while (running) {
    const started = Date.now();
    try {
      const st = await link.reqStatus(timeoutMs);
      const cmd = st.cmd;
      const data = st.data || Buffer.alloc(0);
      const key = String(cmd) + ':' + data.toString('hex');

      if (cmd != null && key !== lastKey) {
        lastKey = key;

        if (cmd === ESCROW) {
          const denom = data[0] || 0;
          const channel = denomToChannel(denom);
          const amount = hooks.resolveAmount(channel, cfg.channels, {});
          pendingChannel = channel;
          pendingAmount = amount;
          log('ESCROW raw=0x' + denom.toString(16) + ' data=' + data.toString('hex') + ' → canal ' + channel);
          if (!(amount > 0)) {
            log('ESCROW canal ' + channel + ' — suma necunoscuta. Verifica channels in config.json (1=1,2=5,3=10,4=50,5=100,6=200,7=500).');
            await waitAck(link, RETURN, [], timeoutMs, 5);
          } else {
            log('ESCROW canal ' + channel + ' = ' + amount + ' RON → stack');
            const stacked = await waitAck(link, stackCmd, [], timeoutMs, 8);
            if (!stacked) {
              log('STACK nu a primit ACK — retrimit');
              await waitAck(link, stackCmd, [], timeoutMs, 5);
            }
          }
        } else if (cmd === ACCEPTING) {
          log('UBA citeste foaia...');
        } else if (cmd === VEND_VALID) {
          await link.sendCommand(ACK, []);
          const channel = pendingChannel;
          const amount = pendingAmount;
          pendingChannel = 0;
          pendingAmount = 0;
          if (amount > 0) {
            log('Bancnota UBA canal ' + channel + ' = ' + amount + ' RON');
            hooks.postMoneyIn(cfg, amount, 'uba_validator').then((result) => {
              const foi = (result.stacker_bills != null)
                ? (' · foi ' + result.stacker_bills + '/' + result.stacker_capacity)
                : '';
              log('IN OK: +' + amount + ' RON → sold ' + result.credits_balance + ' credite' + foi);
            }).catch((error) => {
              log('EROARE IN: ' + (error.message || error));
            });
          }
        } else if (cmd === REJECTING) {
          const why = data[0] != null ? rejectLabel(data[0]) : '?';
          log('Bancnota respinsa (' + why + ')');
          if (data[0] === 0x79) {
            log('Cauza tipica UBA-10-SS: DIP 1-7 pe OFF sau host inhibit. Pune DIP 1-7 pe ON, DIP 8 pe OFF.');
            await forceEnableAll(link, log, timeoutMs);
          } else if (data[0] === 0x76 || data[0] === 0x91) {
            log('Cauza tipica: soft valuta gresit (nu e RON) sau senzori murdari / foaie prea uzata.');
          } else if (data[0] === 0x77 || data[0] === 0x78 || data[0] === 0x7e) {
            log('Curata lentilele senzorilor (sus/jos) pe UBA-10-SS.');
          }
        } else if (cmd === STACKER_FULL) {
          log('Receptor plin (STACKER_FULL)');
        } else if (cmd === STACKER_OPEN) {
          const now = Date.now();
          if (now - lastCashboxResetAt > 5000) {
            lastCashboxResetAt = now;
            log('Caseta scoasa → reset foi');
            try {
              const result = await hooks.postStackerReset(cfg, 'uba_cashbox_removed');
              log('Stacker reset OK: ' + (result.stacker_bills || 0) + '/' + (result.stacker_capacity || 1000));
            } catch (error) {
              log('EROARE reset stacker: ' + (error.message || error));
            }
          }
        } else if (cmd === INHIBIT) {
          log('UBA inhibit — trimit enable');
          await link.sendCommand(SET_INHIBIT, Buffer.from([0x00]));
          await link.readResponse(timeoutMs);
        } else if (cmd === INITIALIZE) {
          log('UBA cere initialize');
          await initialize(link, log, timeoutMs);
        } else if (
          cmd === IDLE || cmd === ACCEPTING || cmd === STACKING ||
          cmd === STACKED || cmd === RETURNING || cmd === HOLDING || cmd === 0x00
        ) {
          // ok
        } else {
          log('UBA status 0x' + Number(cmd).toString(16));
        }
      }
    } catch (error) {
      log('UBA poll: ' + (error.message || error));
      await sleep(400);
    }

    const wait = pollMs - (Date.now() - started);
    if (wait > 0) await sleep(wait);
  }
}

module.exports = { runUbaId003 };
