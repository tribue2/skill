'use strict';

const crypto = require('crypto');

function isPrime(n) {
  if (n < 2n) return false;
  if (n === 2n) return true;
  if (n % 2n === 0n) return false;
  for (let i = 3n; i * i <= n; i += 2n) {
    if (n % i === 0n) return false;
  }
  return true;
}

function randomPrime16() {
  for (;;) {
    let n = BigInt(crypto.randomBytes(2).readUInt16LE(0) | 1);
    if (n < 257n) n += 256n;
    if (n > 65521n) n = 65521n;
    if (isPrime(n)) return n;
  }
}

function int64LE(number) {
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64LE(BigInt(number));
  return Array.from(buf);
}

function patchEsspDh(SspLib) {
  if (!SspLib || !SspLib.prototype || SspLib.prototype.__iqwinDhPatched) {
    return SspLib;
  }

  SspLib.prototype.initEncryption = function initEncryption() {
    this.keys.modulusKey = randomPrime16();
    this.keys.generatorKey = randomPrime16();
    while (this.keys.generatorKey >= this.keys.modulusKey) {
      this.keys.generatorKey = randomPrime16();
      if (this.keys.generatorKey >= this.keys.modulusKey) {
        this.keys.modulusKey = randomPrime16();
      }
    }

    const maxExp = this.keys.modulusKey - 2n;
    let exp = BigInt(crypto.randomBytes(2).readUInt16LE(0));
    this.keys.hostRandom = (exp % maxExp) + 2n;
    this.keys.hostIntKey = this.keys.generatorKey ** this.keys.hostRandom % this.keys.modulusKey;

    return this.exec('SET_GENERATOR', int64LE(this.keys.generatorKey))
      .then(() => this.exec('SET_MODULUS', int64LE(this.keys.modulusKey)))
      .then(() => this.exec('REQUEST_KEY_EXCHANGE', int64LE(this.keys.hostIntKey)))
      .then(() => {
        this.count = 0;
      });
  };

  SspLib.prototype.__iqwinDhPatched = true;
  return SspLib;
}

function patchEsspSerialPort(SspLib) {
  if (!SspLib || !SspLib.prototype || SspLib.prototype.__iqwinSerialPatched) {
    return SspLib;
  }

  SspLib.prototype.open = function open(port, param = {}) {
    return new Promise((resolve, reject) => {
      const serial = require('serialport');
      const SerialPort = serial.SerialPort || serial;
      const { winComPath } = require('./serial-util');
      const options = {
        path: winComPath(port),
        baudRate: param.baudRate || param.baudrate || 9600,
        dataBits: param.dataBits || param.databits || 8,
        stopBits: param.stopBits || param.stopbits || 2,
        parity: param.parity || 'none',
        highWaterMark: param.highWaterMark || 64 * 1024,
        autoOpen: true
      };

      this.port = new SerialPort(options);

      const ESSPProtocolParser = require('@toopago/essp/src/parser');
      const chalk = require('chalk');
      const parser = this.port.pipe(new ESSPProtocolParser({ id: this.id }));
      parser.on('data', (buffer) => {
        if (this.debug) {
          console.log('COM ->', chalk.yellow(buffer.toString('hex')), chalk.green(this.currentCommand));
        }
        this.eventEmitter.emit(this.currentCommand, buffer);
      });

      this.port.on('error', (error) => {
        reject(error);
        this.emit('CLOSE');
      });

      this.port.on('close', (error) => {
        reject(error);
        this.emit('CLOSE');
      });

      this.port.on('open', () => {
        this.port.set({ dtr: true, rts: true }, () => {
          setTimeout(() => {
            resolve();
            this.emit('OPEN');
          }, 1500);
        });
      });
    });
  };

  SspLib.prototype.__iqwinSerialPatched = true;
  return SspLib;
}

function patchEsspKeepEnabled(SspLib) {
  if (!SspLib || !SspLib.prototype || SspLib.prototype.__iqwinKeepEnabled) {
    return SspLib;
  }

  SspLib.prototype.poll = function poll(status) {
    if (status === undefined) {
      status = true;
    }
    if (status) {
      this.polling = true;
      return this.exec('POLL')
        .then((result) => {
          let onlyDisabled = false;
          if (result && result.info) {
            let res = result.info;
            if (!Array.isArray(result.info)) {
              res = [result.info];
            }
            res.forEach((info) => {
              this.emit(info.name, info);
            });
            onlyDisabled = res.length === 1 && res[0] && res[0].name === 'DISABLED';
          }
          if (onlyDisabled && this.enabled) {
            return this.exec('ENABLE').then(() => {
              if (this.polling) {
                this.poll();
              } else {
                this.eventEmitter.emit('POLL_STOP');
              }
            }).catch(() => {
              if (this.polling) {
                this.poll();
              } else {
                this.eventEmitter.emit('POLL_STOP');
              }
            });
          }
          if (this.polling) {
            this.poll();
          } else {
            this.eventEmitter.emit('POLL_STOP');
          }
        });
    }
    if (this.polling !== false) {
      this.polling = false;
      return new Promise((resolve) => {
        this.eventEmitter.once('POLL_STOP', () => {
          resolve();
        });
      });
    }
    return new Promise((resolve) => {
      resolve();
    });
  };

  SspLib.prototype.__iqwinKeepEnabled = true;
  return SspLib;
}

module.exports = { patchEsspDh, patchEsspSerialPort, patchEsspKeepEnabled };
