param(
  [string]$GamesUrl = 'http://127.0.0.1:17891/boot',
  [string]$TopUrl = 'http://127.0.0.1:17891/boot-top'
)

$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$profileGames = Join-Path $root 'chrome-kiosk-profile-games'
$profileTop = Join-Path $root 'chrome-kiosk-profile-top'

foreach ($dir in @($profileGames, $profileTop)) {
  if (-not (Test-Path $dir)) {
    New-Item -ItemType Directory -Path $dir | Out-Null
  }
}

$chromeCandidates = @(
  (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
  (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
  (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
)
$edgeCandidates = @(
  (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
)

$browser = $chromeCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
$isEdge = $false
if (-not $browser) {
  $browser = $edgeCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
  $isEdge = [bool]$browser
}

if (-not $browser) {
  Start-Process $GamesUrl | Out-Null
  Start-Sleep -Seconds 1
  Start-Process $TopUrl | Out-Null
  exit 0
}

Get-CimInstance Win32_Process -Filter "Name = 'chrome.exe' OR Name = 'msedge.exe'" |
  Where-Object {
    $_.CommandLine -and ($_.CommandLine -like '*chrome-kiosk-profile*')
  } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }

Start-Sleep -Milliseconds 500

$screens = [System.Windows.Forms.Screen]::AllScreens
$primary = [System.Windows.Forms.Screen]::PrimaryScreen
$secondary = $screens | Where-Object { -not $_.Primary } | Select-Object -First 1

function Start-IqwinKiosk {
  param(
    [string]$Url,
    [int]$X,
    [int]$Y,
    [int]$W,
    [int]$H,
    [string]$DataDir
  )

  $argList = @(
    "--user-data-dir=$DataDir",
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-infobars',
    '--disable-session-crashed-bubble',
    '--disable-restore-session-state',
    '--disable-features=TranslateUI,InfiniteSessionRestore',
    '--autoplay-policy=no-user-gesture-required',
    "--window-position=$X,$Y",
    "--window-size=$W,$H"
  )

  if ($isEdge) {
    $argList += @('--kiosk', '--edge-kiosk-type=fullscreen', $Url)
  } else {
    $argList += @('--kiosk', $Url)
  }

  Start-Process -FilePath $browser -ArgumentList $argList | Out-Null
}

$pb = $primary.Bounds
Write-Host ('Monitoare: {0}' -f $screens.Count)
Write-Host ('Jocuri pe: {0} ({1}x{2} @ {3},{4})' -f $primary.DeviceName, $pb.Width, $pb.Height, $pb.X, $pb.Y)
Start-IqwinKiosk -Url $GamesUrl -X $pb.X -Y $pb.Y -W $pb.Width -H $pb.Height -DataDir $profileGames

Start-Sleep -Seconds 2

if ($secondary) {
  $sb = $secondary.Bounds
  Write-Host ('Ecran info pe: {0} ({1}x{2} @ {3},{4})' -f $secondary.DeviceName, $sb.Width, $sb.Height, $sb.X, $sb.Y)
  Start-IqwinKiosk -Url $TopUrl -X $sb.X -Y $sb.Y -W $sb.Width -H $sb.Height -DataDir $profileTop
} else {
  $fx = $pb.X + $pb.Width
  Write-Host ('Un singur monitor - ecran info offset la {0},{1}' -f $fx, $pb.Y)
  Start-IqwinKiosk -Url $TopUrl -X $fx -Y $pb.Y -W $pb.Width -H $pb.Height -DataDir $profileTop
}

Write-Host 'Dual kiosk lansat.'
exit 0
