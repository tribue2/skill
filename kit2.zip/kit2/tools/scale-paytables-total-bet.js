#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');

const PAYTABLES = {
    'verga-gold': {
        lines: 5,
        iqwin: 250,
        paytable: {
            scatter: { 5: 80, 4: 8, 3: 1 },
            om: { 5: 100, 4: 50, 3: 10 },
            faraon: { 5: 50, 4: 20, 3: 5 },
            scarabeu: { 5: 20, 4: 5, 3: 2 },
            buburuza: { 5: 20, 4: 5, 3: 2 },
            a: { 5: 15, 4: 3, 3: 1 },
            k: { 5: 15, 4: 3, 3: 1 },
            q: { 5: 10, 4: 2, 3: 1 },
            j: { 5: 10, 4: 2, 3: 1 },
            ten: { 5: 10, 4: 2, 3: 1 },
        },
        js: 'games/verga-gold/assets/verga-gold.js',
        php: 'api/includes/games/verga_gold_engine.php',
    },
    'boss-crown': {
        lines: 5,
        iqwin: 5000,
        paytable: {
            scatter: { 5: 400, 4: 40, 3: 4 },
            om: { 5: 2000, 4: 250, 3: 100 },
            faraon: { 5: 500, 4: 60, 3: 40 },
            scarabeu: { 5: 500, 4: 60, 3: 40 },
            buburuza: { 5: 250, 4: 40, 3: 20 },
            a: { 5: 100, 4: 20, 3: 10 },
            k: { 5: 100, 4: 20, 3: 10 },
            q: { 5: 100, 4: 20, 3: 10 },
            j: { 5: 100, 4: 20, 3: 10 },
        },
        js: 'games/boss-crown/assets/boss-crown.js',
        php: 'api/includes/games/boss_crown_engine.php',
    },
    'intelligent-book': {
        lines: 5,
        iqwin: 5000,
        paytable: {
            zeu: { 5: 2500, 4: 500, 3: 100 },
            coif: { 5: 1000, 4: 400, 3: 40 },
            house: { 5: 750, 4: 100, 3: 30 },
            bug: { 5: 750, 4: 100, 3: 30 },
            vas: { 5: 730, 4: 80, 3: 10 },
            symbo: { 5: 730, 4: 80, 3: 10 },
            a: { 5: 200, 4: 48, 3: 8 },
            k: { 5: 150, 4: 40, 3: 4 },
            q: { 5: 100, 4: 24, 3: 4 },
            j: { 5: 80, 4: 20, 3: 4 },
            ten: { 5: 60, 4: 16, 3: 4 },
        },
        js: 'games/intelligent-book/assets/intelligent-book.js',
        php: 'api/includes/games/intelligent_book_engine.php',
    },
    'logic-and-zeus': {
        lines: 5,
        paytable: {
            zeu: { 5: 2500, 4: 500, 3: 100 },
            rega: { 5: 1000, 4: 400, 3: 40 },
            lup: { 5: 750, 4: 100, 3: 30 },
            vultur: { 5: 750, 4: 100, 3: 30 },
            a: { 5: 150, 4: 40, 3: 4 },
            k: { 5: 150, 4: 40, 3: 4 },
            q: { 5: 100, 4: 24, 3: 4 },
            cupa: { 5: 200, 4: 48, 3: 8 },
            cupa2: { 5: 200, 4: 48, 3: 8 },
        },
        js: 'games/logic-and-zeus/assets/logic-and-zeus.js',
        php: 'api/includes/games/logic_and_zeus_engine.php',
    },
    '40-burn-hot': {
        lines: 10,
        paytable: {
            sapte: { 5: 3000, 4: 200, 3: 50 },
            pepene: { 5: 500, 4: 100, 3: 40 },
            strugure: { 5: 500, 4: 100, 3: 40 },
            clopotel: { 5: 200, 4: 50, 3: 20 },
            pruna: { 5: 100, 4: 30, 3: 10 },
            portocala: { 5: 100, 4: 30, 3: 10 },
            lamaie: { 5: 100, 4: 30, 3: 10 },
            cireasa: { 5: 100, 4: 30, 3: 10 },
        },
        js: 'games/40-burn-hot/assets/forty-burn-hot.js',
        php: 'api/includes/games/forty_burn_hot_engine.php',
    },
    'dodge-bomb': {
        lines: 5,
        paytable: {
            sapte: { 4: 2000, 3: 100 },
            stea: { 4: 300, 3: 25 },
            pepene: { 4: 400, 3: 100 },
            strugure: { 4: 400, 3: 100 },
            pruna: { 4: 200, 3: 50 },
            portocala: { 4: 200, 3: 50 },
            lamaie: { 4: 200, 3: 50 },
            cireasa: { 4: 100, 3: 25, 2: 10 },
        },
        js: 'games/dodge-bomb/assets/dodge-bomb.js',
        php: 'api/includes/games/dodge_bomb_engine.php',
    },
};

function scalePaytable(table, divisor) {
    const out = {};
    for (const [symbol, pays] of Object.entries(table)) {
        out[symbol] = {};
        const counts = Object.keys(pays).map(Number).sort((a, b) => b - a);
        for (const count of counts) {
            const value = pays[count] / divisor;
            out[symbol][count] = Number.isInteger(value) ? value : Math.round(value * 1000) / 1000;
        }
    }
    return out;
}

function formatJsPaytable(table) {
    const lines = ['    const paytable = {'];
    const symbols = Object.keys(table);
    symbols.forEach((symbol, index) => {
        const pays = table[symbol];
        const counts = Object.keys(pays).map(Number).sort((a, b) => b - a);
        const parts = counts.map((count) => `${count}: ${pays[count]}`).join(', ');
        const comma = index < symbols.length - 1 ? ',' : '';
        lines.push(`        ${symbol}: { ${parts} }${comma}`);
    });
    lines.push('    };');
    return lines.join('\n');
}

function formatPhpPaytable(table) {
    const lines = ['    private const PAYTABLE = ['];
    const symbols = Object.keys(table);
    symbols.forEach((symbol, index) => {
        const pays = table[symbol];
        const counts = Object.keys(pays).map(Number).sort((a, b) => b - a);
        const parts = counts.map((count) => `${count} => ${pays[count]}`).join(', ');
        const comma = index < symbols.length - 1 ? ',' : '';
        lines.push(`        '${symbol}' => [${parts}],${comma}`.replace(',,', ','));
    });
    lines.push('    ];');
    return lines.join('\n');
}

function replaceBlock(content, startPattern, endPattern, replacement) {
    const start = content.search(startPattern);
    if (start < 0) throw new Error(`Start pattern not found: ${startPattern}`);
    const endMatch = content.slice(start).match(endPattern);
    if (!endMatch) throw new Error(`End pattern not found: ${endPattern}`);
    const end = start + endMatch.index + endMatch[0].length;
    return content.slice(0, start) + replacement + content.slice(end);
}

function patchJs(filePath, scaled, iqwinScaled) {
    let content = fs.readFileSync(filePath, 'utf8');
    content = replaceBlock(content, /const paytable = \{/, /^\s*\};\s*$/m, formatJsPaytable(scaled) + '\n');
    if (iqwinScaled !== undefined) {
        content = content.replace(/const IQWIN_LINE_PAY = \d+;/, `const IQWIN_LINE_PAY = ${iqwinScaled};`);
    }
    content = content.replace(
        /function calcWinPayout\(multiplier\) \{\s*\n\s*const displayBetPerLine = getCurrentBetBase\(\);\s*\n\s*const payout = roundBet\(displayBetPerLine \* \(Number\(multiplier\) \|\| 0\)\);\s*\n\s*return payout > 0 \? payout : 0;\s*\n\s*\}/,
        'function calcWinPayout(multiplier) {\n        const payout = roundBet(totalBetAmount() * (Number(multiplier) || 0));\n        return payout > 0 ? payout : 0;\n    }'
    );
    fs.writeFileSync(filePath, content, 'utf8');
}

function patchPhpEngine(filePath, scaled, iqwinScaled, options = {}) {
    let content = fs.readFileSync(filePath, 'utf8');
    content = replaceBlock(content, /private const PAYTABLE = \[/, /^\s*\];/m, formatPhpPaytable(scaled));
    if (iqwinScaled !== undefined) {
        content = content.replace(/private const IQWIN_LINE_PAY = \d+;/, `private const IQWIN_LINE_PAY = ${iqwinScaled};`);
    }

    if (!options.alreadyTotalBet) {
        content = content.replace(
            /(\$betPerLine = max\(0\.01, round\(\$betPerLine, 2\)\);)/,
            "$1\n        \$totalBet = round(\$betPerLine * \$lines, 2);"
        );
        content = content.replace(/\$payout = round\(\$betPerLine \* \$multiplier, 2\);/g, '$payout = round($totalBet * $multiplier, 2);');
        content = content.replace(/\$payout = round\(\$betPerLine \* self::IQWIN_LINE_PAY, 2\);/g, '$payout = round($totalBet * self::IQWIN_LINE_PAY, 2);');
        content = content.replace(
            /self::evaluatePayline\(\$board, \$lineRows, \$betPerLine\)/g,
            'self::evaluatePayline($board, $lineRows, $totalBet)'
        );
        content = content.replace(
            /self::evaluatePayline\(\$lineBoard, \$lineRows, \$betPerLine\)/g,
            'self::evaluatePayline($lineBoard, $lineRows, $totalBet)'
        );
        content = content.replace(
            /self::evaluateIqwinLine\(\$board, \$lineRows, \$betPerLine\)/g,
            'self::evaluateIqwinLine($board, $lineRows, $totalBet)'
        );
        content = content.replace(
            /function evaluatePayline\(array \$board, array \$lineRows, float \$betPerLine\)/g,
            'function evaluatePayline(array $board, array $lineRows, float $totalBet)'
        );
        content = content.replace(
            /function evaluateIqwinLine\(array \$board, array \$lineRows, float \$betPerLine\)/g,
            'function evaluateIqwinLine(array $board, array $lineRows, float $totalBet)'
        );
        content = content.replace(
            /self::evaluateStarScatter\(\$board, \$betPerLine\)/g,
            'self::evaluateStarScatter($board, $totalBet)'
        );
        content = content.replace(
            /function evaluateStarScatter\(array \$board, float \$betPerLine\)/g,
            'function evaluateStarScatter(array $board, float $totalBet)'
        );
        content = content.replace(
            /self::evaluatePayline\(\$board, \$lineRows, \$betPerLine, \$index \+ 1\)/g,
            'self::evaluatePayline($board, $lineRows, $totalBet, $index + 1)'
        );
        content = content.replace(
            /function evaluatePayline\(array \$board, array \$lineRows, float \$betPerLine, int \$lineNumber\)/g,
            'function evaluatePayline(array $board, array $lineRows, float $totalBet, int $lineNumber)'
        );
        content = content.replace(
            /self::evaluatePayline\(\$board, \$lineRows, \$betPerLine, \$lines\)/g,
            'self::evaluatePayline($board, $lineRows, $totalBet, $lines)'
        );
        content = content.replace(
            /function evaluatePayline\(array \$board, array \$lineRows, float \$betPerLine, int \$lines\)/g,
            'function evaluatePayline(array $board, array $lineRows, float $totalBet, int $lines)'
        );
    }

    fs.writeFileSync(filePath, content, 'utf8');
}

function patchPhpPaytableOnly(filePath, scaled, iqwinScaled) {
    let content = fs.readFileSync(filePath, 'utf8');
    content = replaceBlock(content, /private const PAYTABLE = \[/, /^\s*\];/m, formatPhpPaytable(scaled));
    if (iqwinScaled !== undefined) {
        content = content.replace(/private const IQWIN_LINE_PAY = \d+;/, `private const IQWIN_LINE_PAY = ${iqwinScaled};`);
    }
    fs.writeFileSync(filePath, content, 'utf8');
}

for (const [name, cfg] of Object.entries(PAYTABLES)) {
    const scaled = scalePaytable(cfg.paytable, cfg.lines);
    const iqwinScaled = cfg.iqwin !== undefined ? cfg.iqwin / cfg.lines : undefined;
    const jsPath = path.join(root, cfg.js);
    const phpPath = path.join(root, cfg.php);
    console.log('Patching', name);
    patchJs(jsPath, scaled, iqwinScaled);
    if (name === 'boss-crown') {
        patchPhpPaytableOnly(phpPath, scaled, iqwinScaled);
    } else {
        patchPhpEngine(phpPath, scaled, iqwinScaled, {
            alreadyTotalBet: name === 'verga-gold',
        });
    }
}

console.log('Done.');
